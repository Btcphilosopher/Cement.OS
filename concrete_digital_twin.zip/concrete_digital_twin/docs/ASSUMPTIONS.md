# Modelling Assumptions & Limitations

This simulator is an **educational / engineering-prototype digital twin**.
Every numeric model listed below is labelled with a data-provenance tag
(see `core/materials.py::DataProvenance`) and none of it should be treated
as a certified structural-design result. This document exists so nothing
here is a hidden assumption.

| Domain | Model | Key assumptions / limitations |
|---|---|---|
| Cement chemistry | Bogue equations (`core/chemistry.py`) | Assumes 4 standard clinker phases only; ignores free lime, alkalis, MgO beyond a coarse cap; can produce small negative phase estimates for non-Portland-like compositions (clamped to 0). |
| Heat of hydration | Literature per-phase ultimate heat coefficients | Generic literature values, not measured for any specific clinker; SCM pozzolanic heat handled as a smaller separate contribution, not co-reacted with clinker phases. |
| Hydration kinetics | Exponential degree-of-hydration model (`curing/hydration.py`) | Lumped (not particle-scale); ultimate degree of hydration from a Powers'-type w/cm relationship; kinetic constants (tau, beta) are illustrative defaults, not calibrated to any specific cement. |
| Water demand | Empirical slump/max-size table (`mix_design/water.py`) | Loosely styled on ACI 211.1 Table 6.3.3 but re-derived as smooth interpolation, not a verbatim reproduction; does not model paste rheology directly. |
| Strength vs w/cm | Abrams'-law-style exponential (`mix_design/cement.py`) | Calibration constants A=97 MPa, B=4.15 are illustrative; MUST be recalibrated against real trial-mix data before using absolute numbers. |
| Strength vs age | CEB-FIP/ACI-209-style exponential (`curing/strength.py`) | `s` coefficient by "cement speed class" is a coarse 3-bucket approximation, not tied to an actual strength class standard. |
| Coarse aggregate proportioning | ACI-211.1-style bulk-volume table (`mix_design/aggregates.py`) | Reproduced as an interpolated table for teaching purposes; real design should use trial batches. |
| Packing density | Deviation-from-Fuller-curve heuristic (`aggregates/grading.py`) | Not a full particle-packing model (no CPM/Toufar-style analysis); relative comparison only. |
| Kiln model | Lumped steady-state mass/energy balance (`cement/kiln.py`) | Not CFD, not dynamic/PID; five temperature zones are illustrative durations, not derived from a specific kiln geometry. |
| Cement mill | Bond work-index relation (`cement/grinding.py`) | Uses an empirical Blaine<->P80 correlation in place of a full population-balance model. |
| Carbon accounting | Emission-factor based (`environment/carbon.py`) | Grid/fuel/transport factors are configurable defaults, not measured; calcination CO2 uses ideal stoichiometry with a configurable calcination degree. |
| Slump & slump loss | Empirical, temperature/time driven (`curing/slump.py`) | Uncertainty band included; admixture compatibility interactions between multiple simultaneous admixtures are NOT modelled (effects are summed/capped). |
| Setting time | Empirical Vicat-style estimate (`curing/setting.py`) | Illustrative baseline (150/240 min at w/cm=0.5, 20°C); not a certified construction prediction. |
| Equipment reliability | Exponential MTBF/MTTR model (`plant/_equipment_base.py`) | Assumes a constant failure rate (memoryless); no wear-out (Weibull) tail modelled beyond a simple linear condition decay. |
| Monte Carlo | Vectorised NumPy sampling (`simulation/monte_carlo.py`) | Uncertain variables assumed independent Gaussian/uniform; no modelled correlation between e.g. water error and temperature. |
| Recipe optimiser | Random search + Pareto non-dominated sort (`optimisation/`) | Feasibility is determined by re-running the full mix-design engine per candidate, so infeasible corners of the search space are naturally excluded rather than explicitly constrained. |

## General principles applied throughout

1. **Units**: all internal calculations use SI base units (kg, m3, Pa, K,
   J, W, s, kgCO2e) via `core/units.py`; conversion to display units
   (tonnes, MPa, kWh, °C, ...) happens only at the presentation layer.
2. **Mass balance discipline**: every stage that transforms a material
   stream (kiln, mill, crusher, screen) is checked with
   `core/balances.py::check_mass_balance` against a relative tolerance.
3. **Provenance labelling**: every material and every simulated output is
   implicitly one of SIMULATED / ESTIMATED / USER_PROVIDED / VALIDATED
   EXPERIMENTAL DATA -- reports should carry this label through to any
   dashboard or export.
4. **No certification claims**: nothing in this codebase asserts
   compliance with a specific national or international concrete/cement
   standard (EN 206, ACI 318, BS 8500, etc.) even where a model is
   *styled* on the shape of a table from such a standard.
