# Architecture

```
concrete_digital_twin/
├── core/          Units, material models, chemistry, thermodynamics, mass balances
├── cement/        Raw materials -> kiln -> clinker -> grinding -> blending
├── aggregates/     Quarry -> crushing -> screening -> grading -> moisture
├── mix_design/       Absolute-volume mix design engine + optimisation
├── production/         Batching plant, mixing, conveyors, truck dispatch
├── curing/               Hydration, temperature, strength, maturity, slump, setting
├── quality/                QC engine, sampling, statistics, SPC control charts
├── plant/                    Physical equipment: silos, mixers, pumps, kilns, storage
├── economics/                  Material/energy/production cost, pricing
├── environment/                   Carbon, energy, emissions, water accounting
├── optimisation/                    SciPy / genetic / multi-objective (Pareto) engines
├── simulation/                        Discrete-event engine, Monte Carlo, scenarios
├── digital_twin/                        Plant state, synthetic sensors, historian (SQLite)
├── dashboard/                              Streamlit control-centre + mix-design UI
├── api/                                      FastAPI endpoints + SQLAlchemy ORM models
├── data/                                       YAML: materials, mixes, plants, scenarios
├── tests/                                        pytest + Hypothesis property tests
├── examples/                                       13 runnable end-to-end scripts
└── reference_plant.py    Shared fictional example plant ("Northshire Concrete Works")
```

## Data flow (the "digital twin" walk-through)

```
RAW MATERIALS (cement.raw_materials)
   │
   ▼
CLINKER CHEMISTRY (core.chemistry: Bogue phases)
   │
   ▼
KILN (cement.kiln) ──► CLINKER (cement.clinker)
   │
   ▼
CEMENT MILL (cement.grinding) ──► CEMENT BLEND (cement.blending)
   │
   ▼                                   AGGREGATES (aggregates.*)
   │                                          │
   └──────────────► MIX DESIGN (mix_design.mix) ◄──────────────┘
                          │
              ┌───────────┼────────────┐
              ▼           ▼            ▼
        OPTIMISATION   BATCHING    ECONOMICS / CARBON
      (optimisation.*) (production.batching)  (economics.*, environment.*)
              │           │
              ▼           ▼
                     MIXING (production.mixing)
                          │
                          ▼
                 TRUCK / DISPATCH (production.dispatch)
                          │
                          ▼
                CURING (curing.hydration/temperature)
                          │
                          ▼
              STRENGTH / MATURITY (curing.strength/maturity)
                          │
                          ▼
                QUALITY CONTROL (quality.qc, control_charts)
                          │
                          ▼
        MONTE CARLO RISK (simulation.monte_carlo) ──► DASHBOARD / API
```

## Key design decisions

* **A single custom unit system** (`core/units.py`) rather than a
  dependency like `pint`, so the "never silently mix kg/tonnes/litres/m3"
  requirement is auditable in ~250 lines with zero external dependency
  risk.
* **Pydantic v2 everywhere data crosses a boundary**: material records,
  mix-design inputs, and the FastAPI request/response schemas are all
  Pydantic models with explicit `Field` constraints, so invalid data
  (negative mass, impossible density, out-of-range temperature) fails
  fast with a clear validation error rather than silently propagating.
* **NumPy-vectorised Monte Carlo**: `simulation/monte_carlo.py` samples
  all uncertain variables as NumPy arrays and evaluates the strength/slump
  formulas across the whole array at once, so 100,000 runs complete in
  well under a second rather than re-invoking the full mix-design engine
  100,000 times.
* **The recipe optimiser routes every candidate through the real mix
  design engine** (`optimisation/optimizer.py`), so infeasible corners of
  the search space (e.g. cementitious + coarse-aggregate + air volumes
  exceeding 1 m3) are naturally rejected rather than needing a separate
  feasibility model.
* **A from-scratch discrete-event engine** (`simulation/discrete_event.py`)
  keeps the event queue and simulation clock fully auditable and
  dependency-free, using a `heapq`-based priority queue keyed on
  simulation time (not wall-clock time).
* **One shared fictional reference plant** (`reference_plant.py`) is used
  by the examples, the dashboard and the API, so a change to a material
  or plant parameter is reflected consistently everywhere.
