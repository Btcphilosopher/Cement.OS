# Quickstart

## 1. Install

Requires Python 3.11+ (developed/tested on 3.11; targets 3.12+ features
where available).

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Run the tests

```bash
pytest concrete_digital_twin/tests -q
```

You should see 86+ tests pass, including Hypothesis property-based tests
(mass balance, mix-mass conservation, carbon composition, moisture
correction).

## 3. Run the examples

Each example is a standalone script; run them in order for a guided tour,
or jump straight to the one you need:

```bash
python concrete_digital_twin/examples/01_material_database.py
python concrete_digital_twin/examples/02_cement_plant_pipeline.py
python concrete_digital_twin/examples/03_aggregate_grading.py
python concrete_digital_twin/examples/04_mix_design.py
python concrete_digital_twin/examples/05_batching_and_mixing.py
python concrete_digital_twin/examples/06_curing_and_strength.py
python concrete_digital_twin/examples/07_quality_control.py
python concrete_digital_twin/examples/08_economics_and_carbon.py
python concrete_digital_twin/examples/09_monte_carlo_risk.py
python concrete_digital_twin/examples/10_optimisation_pareto.py
python concrete_digital_twin/examples/11_full_pipeline_end_to_end.py
python concrete_digital_twin/examples/12_discrete_event_simulation.py
python concrete_digital_twin/examples/13_performance_benchmark.py
```

## 4. Run the dashboard

```bash
streamlit run concrete_digital_twin/dashboard/app.py
```

Opens an interactive control centre with tabs for Mix Design, Recipe
Optimiser, Quality & Monte Carlo, Curing, and Economics & Carbon.

## 5. Run the API

```bash
uvicorn concrete_digital_twin.api.main:app --reload
```

Then visit http://127.0.0.1:8000/docs for interactive Swagger docs.

Quick example:

```bash
curl -X POST http://127.0.0.1:8000/mix-design \
  -H "Content-Type: application/json" \
  -d '{"target_strength_mpa": 35, "slump_mm": 100, "exposure": "XC_carbonation", "max_agg_size_mm": 20, "target_air_content_pct": 2, "scm_fraction_of_binder": 0.2, "concrete_temperature_c": 20}'
```

## 6. Minimal Python usage

```python
from concrete_digital_twin.reference_plant import build_reference_plant
from concrete_digital_twin.mix_design.mix import MixDesignInputs

plant = build_reference_plant()
inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.2)
result = plant.engine.design(inputs)
print(result.summary())
```

## 7. Database

```python
from concrete_digital_twin.api.db import init_db
engine = init_db("sqlite:///concrete_digital_twin.db")   # or a postgresql+psycopg2://... URL
```

---

**Reminder**: every number this simulator produces is SIMULATED or
ESTIMATED. See `docs/ASSUMPTIONS.md` before using any output for a real
engineering decision.
