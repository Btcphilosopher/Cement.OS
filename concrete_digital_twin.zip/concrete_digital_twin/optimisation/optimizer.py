"""
optimisation.optimizer
=========================

High-level recipe optimiser: generates a large candidate population of
mix designs by varying SCM fraction, w/cm (within exposure limits) and
admixture dosage, evaluates cost/carbon/strength/slump for each, filters
to those meeting the user's targets/limits, computes the Pareto frontier,
and returns a ranked Top-N table (section 55) plus a single-mix
recommendation report that NEVER auto-applies changes (section 50).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..economics.material_cost import mix_material_cost_per_m3
from ..environment.carbon import mix_carbon_kgco2e_per_m3
from ..mix_design.cement import exposure_limits
from ..mix_design.mix import MixDesignEngine, MixDesignInputs, MixDesignResult
from .multiobjective import pareto_frontier, select_balanced, select_weighted


@dataclass
class RecipeConstraints:
    max_cost_per_m3: float | None = None
    max_carbon_kgco2e_per_m3: float | None = None
    min_strength_mpa: float | None = None
    min_slump_mm: float | None = None


def generate_candidate_mixes(
    engine: MixDesignEngine,
    base_inputs: MixDesignInputs,
    n_candidates: int = 2000,
    scm_bounds: tuple[float, float] = (0.0, 0.55),
    wcm_delta_bounds: tuple[float, float] = (-0.08, 0.08),
    seed: int | None = 42,
) -> list[dict[str, Any]]:
    """Random search over (scm_fraction, wcm adjustment) generating a large
    candidate population -- vectorised where possible, but each candidate
    still routes through the full absolute-volume mix design engine so
    infeasible combinations are naturally rejected.
    """
    rng = np.random.default_rng(seed)
    _, max_wcm = exposure_limits(base_inputs.exposure)
    base_wcm = base_inputs.wcm_override

    candidates: list[dict[str, Any]] = []
    scm_samples = rng.uniform(scm_bounds[0], scm_bounds[1], n_candidates)
    wcm_delta_samples = rng.uniform(wcm_delta_bounds[0], wcm_delta_bounds[1], n_candidates)

    for scm_frac, wcm_delta in zip(scm_samples, wcm_delta_samples):
        trial_wcm = None
        if base_wcm is not None:
            trial_wcm = min(max_wcm, max(0.25, base_wcm + wcm_delta))
        trial_inputs = base_inputs.model_copy(update={
            "scm_fraction_of_binder": float(scm_frac),
            "wcm_override": trial_wcm,
        })
        try:
            result = engine.design(trial_inputs)
        except ValueError:
            continue

        candidates.append({
            "result": result,
            "scm_fraction": float(scm_frac),
            "wcm_ratio": result.wcm_ratio,
            "strength_mpa": result.predicted_28d_strength_mpa,
            "cost_per_m3": mix_material_cost_per_m3(result, engine),
            "carbon_kgco2e_per_m3": mix_carbon_kgco2e_per_m3(result, engine),
            "cement_kg_m3": result.cement_kg,
        })
    return candidates


def filter_feasible(candidates: list[dict[str, Any]], constraints: RecipeConstraints, target_strength_mpa: float) -> list[dict[str, Any]]:
    feasible = []
    min_strength = constraints.min_strength_mpa or target_strength_mpa
    for c in candidates:
        if c["strength_mpa"] < min_strength * 0.97:
            continue
        if constraints.max_cost_per_m3 is not None and c["cost_per_m3"] > constraints.max_cost_per_m3:
            continue
        if constraints.max_carbon_kgco2e_per_m3 is not None and c["carbon_kgco2e_per_m3"] > constraints.max_carbon_kgco2e_per_m3:
            continue
        feasible.append(c)
    return feasible


@dataclass
class RecipeSearchReport:
    n_generated: int
    n_feasible: int
    feasible: list[dict[str, Any]]
    top_10: list[dict[str, Any]]
    pareto_frontier: list[dict[str, Any]]
    lowest_cost: dict[str, Any] | None
    lowest_carbon: dict[str, Any] | None
    max_strength: dict[str, Any] | None
    balanced: dict[str, Any] | None


def search_recipes(
    engine: MixDesignEngine,
    base_inputs: MixDesignInputs,
    constraints: RecipeConstraints = RecipeConstraints(),
    n_candidates: int = 2000,
    rank_weights: dict[str, float] | None = None,
) -> RecipeSearchReport:
    candidates = generate_candidate_mixes(engine, base_inputs, n_candidates)
    feasible = filter_feasible(candidates, constraints, base_inputs.target_strength_mpa)

    if not feasible:
        return RecipeSearchReport(
            n_generated=len(candidates), n_feasible=0, feasible=[], top_10=[], pareto_frontier=[],
            lowest_cost=None, lowest_carbon=None, max_strength=None, balanced=None,
        )

    weights = rank_weights or {"cost_per_m3": 0.4, "carbon_kgco2e_per_m3": 0.4, "cement_kg_m3": 0.2}
    ranked = sorted(
        feasible,
        key=lambda c: sum(weights.get(k, 0.0) * c[k] for k in weights),
    )
    top_10 = ranked[:10]

    pareto = pareto_frontier(feasible, ["cost_per_m3", "carbon_kgco2e_per_m3"], [True, True])

    lowest_cost = min(feasible, key=lambda c: c["cost_per_m3"])
    lowest_carbon = min(feasible, key=lambda c: c["carbon_kgco2e_per_m3"])
    max_strength = max(feasible, key=lambda c: c["strength_mpa"])
    balanced = select_balanced(feasible, ["cost_per_m3", "carbon_kgco2e_per_m3"], [True, True])

    return RecipeSearchReport(
        n_generated=len(candidates),
        n_feasible=len(feasible),
        feasible=feasible,
        top_10=top_10,
        pareto_frontier=pareto,
        lowest_cost=lowest_cost,
        lowest_carbon=lowest_carbon,
        max_strength=max_strength,
        balanced=balanced,
    )


@dataclass
class MixRecommendation:
    current: dict[str, float]
    recommended: dict[str, float]
    cost_change_per_m3: float
    carbon_change_kgco2e_per_m3: float
    strength_change_mpa: float
    slump_change_mm: float
    rationale: list[str] = field(default_factory=list)

    def apply(self) -> None:
        raise RuntimeError(
            "MixRecommendation.apply() is intentionally not implemented: "
            "recommendations from this engine are NEVER auto-applied. "
            "An operator must review and manually action a recommendation."
        )


def recommend_mix(
    current_result: MixDesignResult,
    engine: MixDesignEngine,
    base_inputs: MixDesignInputs,
    constraints: RecipeConstraints = RecipeConstraints(),
    n_candidates: int = 1000,
) -> MixRecommendation:
    """Compares the current mix to the best (balanced cost/carbon,
    Pareto-optimal) alternative found by search_recipes. Never mutates the
    current mix -- see MixRecommendation.apply()."""
    report = search_recipes(engine, base_inputs, constraints, n_candidates)
    current_cost = mix_material_cost_per_m3(current_result, engine)
    current_carbon = mix_carbon_kgco2e_per_m3(current_result, engine)

    if report.balanced is None:
        raise ValueError("no feasible recommended mix found under the given constraints")

    rec = report.balanced
    rec_result: MixDesignResult = rec["result"]

    rationale = []
    if rec_result.cement_kg < current_result.cement_kg:
        rationale.append(f"Cement content reduced by {current_result.cement_kg - rec_result.cement_kg:.0f} kg/m3 via SCM substitution.")
    if rec_result.scm_kg > current_result.scm_kg:
        rationale.append(f"SCM increased to {rec_result.scm_kg:.0f} kg/m3 to offset clinker carbon.")

    return MixRecommendation(
        current={
            "cement_kg_m3": current_result.cement_kg, "water_kg_m3": current_result.water_kg,
            "strength_mpa": current_result.predicted_28d_strength_mpa, "cost_per_m3": current_cost,
            "carbon_kgco2e_per_m3": current_carbon,
        },
        recommended={
            "cement_kg_m3": rec_result.cement_kg, "scm_kg_m3": rec_result.scm_kg, "water_kg_m3": rec_result.water_kg,
            "strength_mpa": rec_result.predicted_28d_strength_mpa, "cost_per_m3": rec["cost_per_m3"],
            "carbon_kgco2e_per_m3": rec["carbon_kgco2e_per_m3"],
        },
        cost_change_per_m3=rec["cost_per_m3"] - current_cost,
        carbon_change_kgco2e_per_m3=rec["carbon_kgco2e_per_m3"] - current_carbon,
        strength_change_mpa=rec_result.predicted_28d_strength_mpa - current_result.predicted_28d_strength_mpa,
        slump_change_mm=0.0,  # slump held constant by base_inputs.slump_mm in this search
        rationale=rationale,
    )
