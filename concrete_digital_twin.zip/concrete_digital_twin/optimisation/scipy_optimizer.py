"""
optimisation.scipy_optimizer
===============================

Thin, reusable wrappers around SciPy's constrained/unconstrained
minimisers (SLSQP for nonlinear constrained problems, bounded scalar
minimisation for 1-D problems). Higher-level engines (mix_design.optimisation,
optimisation.optimizer) build on these.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.optimize import NonlinearConstraint, minimize


@dataclass
class ConstrainedOptResult:
    x: np.ndarray
    fun: float
    success: bool
    message: str


def minimise_with_constraints(
    objective: Callable[[np.ndarray], float],
    x0: np.ndarray,
    bounds: list[tuple[float, float]],
    inequality_constraints: list[Callable[[np.ndarray], float]] | None = None,
    method: str = "SLSQP",
) -> ConstrainedOptResult:
    """Minimise `objective` subject to `inequality_constraints[i](x) >= 0`
    for each constraint, and box `bounds`."""
    constraints = []
    for c in (inequality_constraints or []):
        constraints.append(NonlinearConstraint(c, 0, np.inf))

    result = minimize(
        objective, x0, method=method, bounds=bounds,
        constraints=constraints if constraints else None,
        options={"maxiter": 200, "ftol": 1e-8},
    )
    return ConstrainedOptResult(x=result.x, fun=float(result.fun), success=bool(result.success), message=str(result.message))
