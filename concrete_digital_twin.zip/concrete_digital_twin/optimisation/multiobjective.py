"""
optimisation.multiobjective
==============================

Pareto-frontier utilities: non-dominated sorting over a set of candidate
solutions described by objective dictionaries (all objectives assumed
"lower is better" -- negate any objective you want to maximise before
calling), plus selection strategies (lowest-cost, lowest-carbon,
max-strength, balanced, custom weights).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class ParetoResult:
    pareto_indices: list[int]
    dominated_indices: list[int]


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    """a dominates b if a is <= b in every objective and < in at least one
    (minimisation convention)."""
    return bool(np.all(a <= b) and np.any(a < b))


def non_dominated_sort(objectives: np.ndarray) -> ParetoResult:
    """objectives: (n_candidates, n_objectives) array, minimisation convention."""
    n = objectives.shape[0]
    pareto = []
    dominated = []
    for i in range(n):
        is_dominated = False
        for j in range(n):
            if i == j:
                continue
            if dominates(objectives[j], objectives[i]):
                is_dominated = True
                break
        (dominated if is_dominated else pareto).append(i)
    return ParetoResult(pareto_indices=pareto, dominated_indices=dominated)


def pareto_frontier(candidates: list[dict[str, Any]], objective_keys: list[str], minimise: list[bool] | None = None) -> list[dict[str, Any]]:
    """Returns the subset of `candidates` that are Pareto-optimal across
    the given objective keys. `minimise[i]=False` flips that objective to
    maximise instead."""
    if not candidates:
        return []
    minimise = minimise or [True] * len(objective_keys)
    if len(minimise) != len(objective_keys):
        raise ValueError("minimise must match objective_keys length")

    matrix = np.array([
        [c[k] if m else -c[k] for k, m in zip(objective_keys, minimise)]
        for c in candidates
    ])
    result = non_dominated_sort(matrix)
    return [candidates[i] for i in result.pareto_indices]


def select_balanced(candidates: list[dict[str, Any]], objective_keys: list[str], minimise: list[bool] | None = None) -> dict[str, Any]:
    """Pick the candidate closest (Euclidean, in normalised objective
    space) to the ideal point (best value achieved in each objective
    among the candidate set)."""
    if not candidates:
        raise ValueError("candidates cannot be empty")
    minimise = minimise or [True] * len(objective_keys)
    matrix = np.array([
        [c[k] if m else -c[k] for k, m in zip(objective_keys, minimise)]
        for c in candidates
    ])
    mins = matrix.min(axis=0)
    maxs = matrix.max(axis=0)
    ranges = np.where(maxs - mins == 0, 1.0, maxs - mins)
    normalised = (matrix - mins) / ranges
    ideal = normalised.min(axis=0)
    distances = np.linalg.norm(normalised - ideal, axis=1)
    return candidates[int(np.argmin(distances))]


def select_weighted(candidates: list[dict[str, Any]], weights: dict[str, float], minimise: dict[str, bool] | None = None) -> dict[str, Any]:
    """Pick the candidate with the lowest weighted-sum score across the
    given objective weights (after min-max normalisation)."""
    if not candidates:
        raise ValueError("candidates cannot be empty")
    keys = list(weights.keys())
    minimise = minimise or {k: True for k in keys}
    matrix = np.array([[c[k] if minimise[k] else -c[k] for k in keys] for c in candidates])
    mins = matrix.min(axis=0)
    maxs = matrix.max(axis=0)
    ranges = np.where(maxs - mins == 0, 1.0, maxs - mins)
    normalised = (matrix - mins) / ranges
    w = np.array([weights[k] for k in keys])
    scores = normalised @ w
    return candidates[int(np.argmin(scores))]
