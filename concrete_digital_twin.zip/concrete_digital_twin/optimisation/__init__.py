"""Optimisation engines: SciPy, genetic algorithm, multi-objective / Pareto."""
