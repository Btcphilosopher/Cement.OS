"""
optimisation.genetic
=======================

A small, dependency-free real-valued genetic algorithm for continuous
optimisation problems where the objective is expensive/non-smooth (e.g.
routed through the full mix-design engine), making gradient-based methods
awkward. Minimises a callable objective over box bounds.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np


@dataclass
class GAResult:
    best_x: np.ndarray
    best_fitness: float
    history_best_fitness: list[float]
    population_final: np.ndarray


def genetic_algorithm(
    objective: Callable[[np.ndarray], float],
    bounds: list[tuple[float, float]],
    population_size: int = 40,
    generations: int = 60,
    mutation_rate: float = 0.15,
    mutation_scale: float = 0.1,
    crossover_rate: float = 0.7,
    elitism: int = 2,
    seed: int | None = None,
) -> GAResult:
    """Minimises `objective` (lower is better) over the given box bounds."""
    if not bounds:
        raise ValueError("bounds cannot be empty")
    rng = np.random.default_rng(seed)
    dim = len(bounds)
    lows = np.array([b[0] for b in bounds])
    highs = np.array([b[1] for b in bounds])
    if np.any(highs <= lows):
        raise ValueError("each bound must have high > low")

    population = rng.uniform(lows, highs, size=(population_size, dim))
    fitness = np.array([objective(ind) for ind in population])
    history_best = [float(np.min(fitness))]

    for _gen in range(generations):
        order = np.argsort(fitness)
        population = population[order]
        fitness = fitness[order]

        new_population = [population[i].copy() for i in range(elitism)]

        while len(new_population) < population_size:
            # Tournament selection
            i1, i2 = rng.integers(0, population_size, size=2)
            parent1 = population[i1] if fitness[i1] < fitness[i2] else population[i2]
            i3, i4 = rng.integers(0, population_size, size=2)
            parent2 = population[i3] if fitness[i3] < fitness[i4] else population[i4]

            if rng.random() < crossover_rate:
                alpha = rng.random(dim)
                child = alpha * parent1 + (1 - alpha) * parent2
            else:
                child = parent1.copy()

            mutate_mask = rng.random(dim) < mutation_rate
            mutation = rng.normal(0, mutation_scale, size=dim) * (highs - lows)
            child = np.where(mutate_mask, child + mutation, child)
            child = np.clip(child, lows, highs)

            new_population.append(child)

        population = np.array(new_population[:population_size])
        fitness = np.array([objective(ind) for ind in population])
        history_best.append(float(np.min(fitness)))

    best_idx = int(np.argmin(fitness))
    return GAResult(
        best_x=population[best_idx],
        best_fitness=float(fitness[best_idx]),
        history_best_fitness=history_best,
        population_final=population,
    )
