"""
dashboard.charts
===================

Plotly chart builders shared by the Streamlit dashboard and usable
standalone (e.g. from examples) for: grading curves, strength curves,
hydration/temperature curves, cost/carbon breakdowns, control charts,
Pareto frontiers, Monte Carlo distributions.
"""

from __future__ import annotations

import numpy as np
import plotly.graph_objects as go

from ..core.materials import ParticleSizeDistribution
from ..quality.control_charts import ControlChartLimits


def grading_curve_figure(curves: dict[str, ParticleSizeDistribution]) -> go.Figure:
    """`curves` maps a label ('actual', 'target', 'optimised', ...) to a PSD."""
    fig = go.Figure()
    for label, psd in curves.items():
        fig.add_trace(go.Scatter(x=psd.sieve_sizes_mm, y=psd.percent_passing, mode="lines+markers", name=label))
    fig.update_xaxes(type="log", title="Sieve size (mm)")
    fig.update_yaxes(title="% Passing", range=[0, 100])
    fig.update_layout(title="Aggregate Grading Curve", template="plotly_white")
    return fig


def strength_curve_figure(ages_days: list[float], strengths_mpa: list[float], target_mpa: float | None = None) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=ages_days, y=strengths_mpa, mode="lines+markers", name="Predicted strength (SIMULATED)"))
    if target_mpa is not None:
        fig.add_hline(y=target_mpa, line_dash="dash", annotation_text="Target strength")
    fig.update_xaxes(title="Age (days)", type="log")
    fig.update_yaxes(title="Compressive strength (MPa)")
    fig.update_layout(title="Strength Development (SIMULATION)", template="plotly_white")
    return fig


def hydration_temperature_figure(time_hours: np.ndarray, temperature_c: np.ndarray, degree_of_hydration: np.ndarray) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=time_hours, y=temperature_c, mode="lines", name="Temperature (°C)", yaxis="y1"))
    fig.add_trace(go.Scatter(x=time_hours, y=degree_of_hydration * 100, mode="lines", name="Degree of hydration (%)", yaxis="y2"))
    fig.update_layout(
        title="Curing Temperature & Hydration (SIMULATION)",
        xaxis=dict(title="Time (hours)"),
        yaxis=dict(title="Temperature (°C)"),
        yaxis2=dict(title="Degree of hydration (%)", overlaying="y", side="right", range=[0, 100]),
        template="plotly_white",
    )
    return fig


def cost_breakdown_figure(breakdown: dict[str, float], title: str = "Cost Breakdown (£/m3)") -> go.Figure:
    labels = list(breakdown.keys())
    values = list(breakdown.values())
    fig = go.Figure(go.Pie(labels=labels, values=values, hole=0.4))
    fig.update_layout(title=title, template="plotly_white")
    return fig


def control_chart_figure(chart: ControlChartLimits, title: str) -> go.Figure:
    fig = go.Figure()
    x = list(range(1, len(chart.subgroup_statistic) + 1))
    fig.add_trace(go.Scatter(x=x, y=chart.subgroup_statistic, mode="lines+markers", name="Value"))
    fig.add_hline(y=chart.center_line, line_color="green", annotation_text="CL")
    fig.add_hline(y=chart.upper_control_limit, line_dash="dash", line_color="red", annotation_text="UCL")
    fig.add_hline(y=chart.lower_control_limit, line_dash="dash", line_color="red", annotation_text="LCL")
    if chart.out_of_control_indices:
        oc_x = [x[i] for i in chart.out_of_control_indices]
        oc_y = [chart.subgroup_statistic[i] for i in chart.out_of_control_indices]
        fig.add_trace(go.Scatter(x=oc_x, y=oc_y, mode="markers", marker=dict(color="red", size=12, symbol="x"), name="Out of control"))
    fig.update_layout(title=title, template="plotly_white")
    return fig


def pareto_frontier_figure(candidates: list[dict], pareto: list[dict], x_key: str = "cost_per_m3", y_key: str = "carbon_kgco2e_per_m3") -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=[c[x_key] for c in candidates], y=[c[y_key] for c in candidates],
        mode="markers", marker=dict(color="lightgray", size=6), name="All candidates",
    ))
    pareto_sorted = sorted(pareto, key=lambda c: c[x_key])
    fig.add_trace(go.Scatter(
        x=[c[x_key] for c in pareto_sorted], y=[c[y_key] for c in pareto_sorted],
        mode="lines+markers", marker=dict(color="crimson", size=10), name="Pareto frontier",
    ))
    fig.update_xaxes(title=x_key)
    fig.update_yaxes(title=y_key)
    fig.update_layout(title="Cost vs Carbon Pareto Frontier", template="plotly_white")
    return fig


def monte_carlo_distribution_figure(values: np.ndarray, target: float | None = None, title: str = "Monte Carlo Distribution") -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=values, nbinsx=60, name="Simulated outcomes"))
    if target is not None:
        fig.add_vline(x=target, line_dash="dash", line_color="red", annotation_text="Target")
    fig.update_layout(title=title, template="plotly_white")
    return fig
