"""
dashboard.app
===============

Interactive industrial dashboard (section 53). Run with:

    streamlit run concrete_digital_twin/dashboard/app.py

Tabs: Control Centre | Mix Design | Recipe Optimiser | Quality & Monte Carlo |
Curing | Economics & Carbon.

All figures shown are SIMULATED / ESTIMATED -- see the disclaimer banner.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow `streamlit run` to work from within the package directory too.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np
import streamlit as st

from concrete_digital_twin.core.chemistry import bogue_phases
from concrete_digital_twin.cement.raw_materials import default_raw_meal_blend
from concrete_digital_twin.curing.hydration import HydrationKineticParams
from concrete_digital_twin.curing.strength import CementSpeedClass, strength_development_curve
from concrete_digital_twin.curing.temperature import CuringRegime, simulate_curing_temperature
from concrete_digital_twin.dashboard.charts import (
    cost_breakdown_figure,
    hydration_temperature_figure,
    monte_carlo_distribution_figure,
    pareto_frontier_figure,
    strength_curve_figure,
)
from concrete_digital_twin.dashboard.controls import mix_design_controls
from concrete_digital_twin.digital_twin.state import PlantState
from concrete_digital_twin.economics.material_cost import material_cost_breakdown, mix_material_cost_per_m3
from concrete_digital_twin.environment.carbon import mix_carbon_kgco2e_per_m3
from concrete_digital_twin.optimisation.optimizer import RecipeConstraints, search_recipes
from concrete_digital_twin.reference_plant import PLANT_CAPACITY_M3_H, PLANT_NAME, build_reference_plant
from concrete_digital_twin.simulation.monte_carlo import UncertaintyConfig, run_monte_carlo

st.set_page_config(page_title="Concrete Digital Twin", layout="wide")

st.title(f"🏭 {PLANT_NAME} — Concrete Production Control Centre")
st.caption(
    "EDUCATIONAL / ENGINEERING-PROTOTYPE SIMULATOR. All figures are SIMULATED or ESTIMATED "
    "and must not be used as certified structural design results."
)


@st.cache_resource
def _plant():
    return build_reference_plant()


plant = _plant()

tabs = st.tabs(["Control Centre", "Mix Design", "Recipe Optimiser", "Quality & Monte Carlo", "Curing", "Economics & Carbon"])

# ----------------------------------------------------------------- Control Centre
with tabs[0]:
    state = PlantState.snapshot(
        cement_silo=plant.batch_plant.cement_silo,
        scm_silo=plant.batch_plant.scm_silo,
        fine_stockpile=plant.batch_plant.fine_agg_stockpile,
        coarse_stockpile=plant.batch_plant.coarse_agg_stockpile,
        water_level_pct=85.0,
        fleet=plant.fleet,
        production_rate_m3_h=PLANT_CAPACITY_M3_H * 0.72,
        cement_tonnes_h=18.4,
        mixer_running=True,
        energy_kwh_per_t=5.2,
        carbon_kgco2e_per_m3=210.0,
        quality_pass=True,
        open_orders=14,
        cost_per_m3=58.30,
    )
    cols = st.columns(5)
    dashboard_dict = state.as_dashboard_dict()
    for i, (label, value) in enumerate(dashboard_dict.items()):
        with cols[i % 5]:
            st.metric(label, value)

    st.subheader("Material Inventory")
    inv_cols = st.columns(4)
    inv_cols[0].metric("Cement Silo", f"{plant.batch_plant.cement_silo.level_pct:.0f}%")
    if plant.batch_plant.scm_silo:
        inv_cols[1].metric("Fly Ash Silo", f"{plant.batch_plant.scm_silo.level_pct:.0f}%")
    inv_cols[2].metric("Fine Aggregate", f"{plant.batch_plant.fine_agg_stockpile.level_pct:.0f}%")
    inv_cols[3].metric("Coarse Aggregate", f"{plant.batch_plant.coarse_agg_stockpile.level_pct:.0f}%")

# ----------------------------------------------------------------- Mix Design
with tabs[1]:
    st.subheader("Mix Design (section 54)")
    inputs = mix_design_controls()
    try:
        result = plant.engine.design(inputs)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Yield", f"{result.yield_m3:.2f} m3")
        c2.metric("Density", f"{result.density_kg_m3:.0f} kg/m3")
        c3.metric("Predicted 28d Strength", f"{result.predicted_28d_strength_mpa:.1f} MPa")
        cost = mix_material_cost_per_m3(result, plant.engine)
        carbon = mix_carbon_kgco2e_per_m3(result, plant.engine)
        c4.metric("Cost", f"£{cost:.2f}/m3")

        st.dataframe({
            "Component": ["Water", "Cement", "SCM", "Fine Aggregate", "Coarse Aggregate", "Admixture"],
            "kg/m3": [result.water_kg, result.cement_kg, result.scm_kg, result.fine_aggregate_kg, result.coarse_aggregate_kg, result.admixture_kg],
        }, hide_index=True)

        if result.notes:
            for note in result.notes:
                st.info(note)

        breakdown = material_cost_breakdown(result, plant.engine)
        st.plotly_chart(cost_breakdown_figure(breakdown), width='stretch')
        st.metric("Embodied Carbon", f"{carbon:.0f} kgCO2e/m3")
    except ValueError as e:
        st.error(f"Mix design infeasible: {e}")

# ----------------------------------------------------------------- Recipe Optimiser
with tabs[2]:
    st.subheader("Recipe Optimiser (section 55)")
    col1, col2, col3 = st.columns(3)
    with col1:
        opt_strength = st.number_input("Target strength (MPa)", 10.0, 80.0, 40.0)
    with col2:
        opt_max_carbon = st.number_input("Max carbon (kgCO2e/m3)", 50.0, 600.0, 300.0)
    with col3:
        opt_max_cost = st.number_input("Max cost (£/m3)", 20.0, 300.0, 90.0)
    n_candidates = st.slider("Number of candidate recipes to search", 100, 20000, 3000, 100)

    if st.button("Run optimiser"):
        base_inputs = inputs.model_copy(update={"target_strength_mpa": opt_strength})
        constraints = RecipeConstraints(max_cost_per_m3=opt_max_cost, max_carbon_kgco2e_per_m3=opt_max_carbon)
        with st.spinner(f"Searching {n_candidates} candidate recipes..."):
            report = search_recipes(plant.engine, base_inputs, constraints, n_candidates=n_candidates)
        st.write(f"Generated {report.n_generated} candidates, {report.n_feasible} feasible.")
        if report.top_10:
            st.dataframe([
                {k: v for k, v in c.items() if k != "result"} for c in report.top_10
            ])
            st.plotly_chart(pareto_frontier_figure(report.feasible, report.pareto_frontier), width='stretch')
        else:
            st.warning("No feasible recipe found under the given constraints.")

# ----------------------------------------------------------------- Quality & Monte Carlo
with tabs[3]:
    st.subheader("Quality Risk — Monte Carlo Simulation (sections 31/32)")
    n_runs = st.select_slider("Number of simulation runs", options=[1000, 10000, 100000], value=10000)
    if st.button("Run Monte Carlo simulation"):
        base_result = plant.engine.design(inputs)
        with st.spinner(f"Running {n_runs} simulations..."):
            mc = run_monte_carlo(base_result, n_runs=n_runs, config=UncertaintyConfig())
        c1, c2, c3 = st.columns(3)
        c1.metric("Mean strength", f"{mc.strength_mean:.1f} MPa")
        c2.metric("P5 strength", f"{mc.strength_p5:.1f} MPa")
        c3.metric("P(strength < target)", f"{mc.prob_strength_below_target*100:.2f}%")
        st.plotly_chart(monte_carlo_distribution_figure(mc.raw_strengths, target=inputs.target_strength_mpa, title="Strength Distribution"), width='stretch')
        st.plotly_chart(monte_carlo_distribution_figure(mc.raw_slumps, target=inputs.slump_mm, title="Arrival Slump Distribution"), width='stretch')
        st.caption("PROBABILISTIC SIMULATION — not a guarantee of field performance.")

# ----------------------------------------------------------------- Curing
with tabs[4]:
    st.subheader("Curing & Strength Development (sections 24-27)")
    speed_class = st.selectbox("Cement speed class", list(CementSpeedClass), format_func=lambda s: s.value)
    curve = strength_development_curve(inputs.target_strength_mpa, speed_class)
    st.plotly_chart(strength_curve_figure(curve.ages_days, curve.strengths_mpa, inputs.target_strength_mpa), width='stretch')

    regime = st.selectbox("Curing regime", list(CuringRegime), format_func=lambda r: r.value)
    blend = default_raw_meal_blend()
    phases = bogue_phases(blend.blended_oxides_ignited_basis())
    t = np.linspace(0, 168, 100)
    base_result = plant.engine.design(inputs)
    temp_history = simulate_curing_temperature(
        t, wcm=base_result.wcm_ratio, phases=phases, cement_content_kg_m3=base_result.cement_kg,
        ambient_temp_c=inputs.concrete_temperature_c, regime=regime, params=HydrationKineticParams(),
    )
    st.plotly_chart(hydration_temperature_figure(t, temp_history.temperature_c, temp_history.degree_of_hydration), width='stretch')

# ----------------------------------------------------------------- Economics & Carbon
with tabs[5]:
    st.subheader("Economics & Carbon (sections 39-42)")
    base_result = plant.engine.design(inputs)
    cost = mix_material_cost_per_m3(base_result, plant.engine)
    carbon = mix_carbon_kgco2e_per_m3(base_result, plant.engine)
    c1, c2 = st.columns(2)
    c1.metric("Cost per m3", f"£{cost:.2f}")
    c2.metric("Carbon per m3", f"{carbon:.0f} kgCO2e")
    breakdown = material_cost_breakdown(base_result, plant.engine)
    st.plotly_chart(cost_breakdown_figure(breakdown), width='stretch')
