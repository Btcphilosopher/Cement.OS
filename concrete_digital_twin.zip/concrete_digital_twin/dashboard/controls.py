"""
dashboard.controls
=====================

Streamlit control-widget helpers for the mix-design screen (section 54):
sliders/selects for target strength, slump, w/c ratio, cement/SCM/sand/
coarse aggregate/admixture/temperature, returning a MixDesignInputs.
"""

from __future__ import annotations

import streamlit as st

from ..mix_design.cement import ExposureClass
from ..mix_design.mix import MixDesignInputs


def mix_design_controls(key_prefix: str = "mix") -> MixDesignInputs:
    col1, col2 = st.columns(2)
    with col1:
        target_strength = st.slider("Target strength (MPa)", 10.0, 80.0, 35.0, 1.0, key=f"{key_prefix}_strength")
        slump = st.slider("Slump (mm)", 0.0, 250.0, 100.0, 5.0, key=f"{key_prefix}_slump")
        max_agg = st.select_slider("Max aggregate size (mm)", options=[9.5, 12.5, 19.0, 20.0, 25.0, 37.5], value=20.0, key=f"{key_prefix}_maxagg")
        air = st.slider("Target air content (%)", 0.0, 8.0, 2.0, 0.5, key=f"{key_prefix}_air")
    with col2:
        exposure = st.selectbox("Exposure class", list(ExposureClass), format_func=lambda e: e.value, key=f"{key_prefix}_exposure")
        scm_fraction = st.slider("SCM fraction of binder", 0.0, 0.6, 0.0, 0.05, key=f"{key_prefix}_scm")
        temperature = st.slider("Concrete temperature (°C)", -5.0, 40.0, 20.0, 1.0, key=f"{key_prefix}_temp")
        wcm_override = st.checkbox("Override w/cm ratio directly", key=f"{key_prefix}_wcm_toggle")
        wcm_value = None
        if wcm_override:
            wcm_value = st.slider("w/cm ratio", 0.25, 0.70, 0.50, 0.01, key=f"{key_prefix}_wcm_value")

    return MixDesignInputs(
        target_strength_mpa=target_strength,
        slump_mm=slump,
        exposure=exposure,
        max_agg_size_mm=max_agg,
        target_air_content_pct=air,
        scm_fraction_of_binder=scm_fraction,
        wcm_override=wcm_value,
        concrete_temperature_c=temperature,
    )
