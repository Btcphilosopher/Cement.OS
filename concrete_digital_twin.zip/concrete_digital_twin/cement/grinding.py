"""
cement.grinding
=================

Simplified cement mill model (Bond work-index based) for converting
clinker + gypsum + SCMs + fillers into finished cement powder.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.balances import check_mass_balance, relative_tolerance_kg


@dataclass
class MillFeed:
    clinker_kg_h: float
    gypsum_kg_h: float
    scm_kg_h: float = 0.0
    filler_kg_h: float = 0.0

    @property
    def total_kg_h(self) -> float:
        return self.clinker_kg_h + self.gypsum_kg_h + self.scm_kg_h + self.filler_kg_h


@dataclass
class MillOutputs:
    cement_kg_h: float
    achieved_blaine_m2_kg: float
    mill_power_kw: float
    specific_energy_kwh_per_t: float
    exit_temp_c: float
    reject_kg_h: float


class CementMill:
    """Ball/vertical-roller mill simplified with the Bond work-index
    relation for specific grinding energy:

        E (kWh/t) = 10 * Wi * (1/sqrt(P80) - 1/sqrt(F80))

    where Wi is the Bond work index (kWh/t), F80/P80 are the 80%-passing
    particle sizes (microns) of feed/product. We invert a simplified
    version of this relation to translate target Blaine fineness into
    specific energy via an empirical Blaine<->P80 correlation, since a
    full particle-population-balance mill model is out of scope here.
    """

    def __init__(
        self,
        bond_work_index_kwh_per_t: float = 15.0,
        feed_p80_microns: float = 15000.0,
        separator_efficiency: float = 0.80,
        mill_capacity_kg_h: float = 100000.0,
    ) -> None:
        if bond_work_index_kwh_per_t <= 0:
            raise ValueError("bond_work_index_kwh_per_t must be positive")
        if not (0.0 < separator_efficiency <= 1.0):
            raise ValueError("separator_efficiency must be within (0,1]")
        self.bond_work_index_kwh_per_t = bond_work_index_kwh_per_t
        self.feed_p80_microns = feed_p80_microns
        self.separator_efficiency = separator_efficiency
        self.mill_capacity_kg_h = mill_capacity_kg_h

    @staticmethod
    def blaine_to_p80_microns(blaine_m2_kg: float) -> float:
        """SIMULATED empirical inverse correlation: higher Blaine (finer
        cement) implies a smaller P80. Calibrated so that Blaine=350
        m2/kg corresponds to roughly P80=20 microns (illustrative only)."""
        if blaine_m2_kg <= 0:
            raise ValueError("blaine_m2_kg must be positive")
        return 7000.0 / blaine_m2_kg

    def simulate(self, feed: MillFeed, target_blaine_m2_kg: float = 380.0) -> MillOutputs:
        if feed.total_kg_h > self.mill_capacity_kg_h:
            raise ValueError(
                f"feed rate {feed.total_kg_h:.0f} kg/h exceeds mill capacity {self.mill_capacity_kg_h:.0f} kg/h"
            )

        p80 = self.blaine_to_p80_microns(target_blaine_m2_kg)
        specific_energy_kwh_per_t = 10.0 * self.bond_work_index_kwh_per_t * (
            1.0 / (p80 ** 0.5) - 1.0 / (self.feed_p80_microns ** 0.5)
        )
        specific_energy_kwh_per_t = max(5.0, specific_energy_kwh_per_t)  # physical floor

        tonnes_per_h = feed.total_kg_h / 1000.0
        mill_power_kw = specific_energy_kwh_per_t * tonnes_per_h

        reject_fraction = 1.0 - self.separator_efficiency
        reject_kg_h = feed.total_kg_h * reject_fraction * 0.05  # small physical reject loss, SIMULATED
        cement_kg_h = feed.total_kg_h - reject_kg_h

        check_mass_balance(
            inputs_kg=feed.total_kg_h,
            outputs_kg=cement_kg_h,
            losses_kg=reject_kg_h,
            tolerance_kg=relative_tolerance_kg(feed.total_kg_h, 0.01),
        )

        # Grinding heat: ~90% of mill power ends up as heat into the material stream (SIMULATED)
        heat_kw = 0.9 * mill_power_kw
        exit_temp_c = 20.0 + heat_kw / max(1.0, tonnes_per_h) * 0.02  # crude proxy, illustrative

        return MillOutputs(
            cement_kg_h=cement_kg_h,
            achieved_blaine_m2_kg=target_blaine_m2_kg,
            mill_power_kw=mill_power_kw,
            specific_energy_kwh_per_t=specific_energy_kwh_per_t,
            exit_temp_c=exit_temp_c,
            reject_kg_h=reject_kg_h,
        )
