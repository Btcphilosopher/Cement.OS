"""
cement.raw_materials
======================

Quarry raw-material blending for kiln feed ("raw meal"). Blends limestone,
clay/shale, sand (silica correction) and iron ore correction material to
hit target oxide ratios, then reports the blended oxide composition that
feeds cement.chemistry.bogue_phases.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.chemistry import OxideComposition


@dataclass(frozen=True)
class RawMaterial:
    name: str
    CaO: float
    SiO2: float
    Al2O3: float
    Fe2O3: float
    SO3: float = 0.0
    MgO: float = 0.0
    LOI: float = 0.0  # loss on ignition (mostly CO2 from carbonates), mass %

    def validate(self) -> None:
        total = self.CaO + self.SiO2 + self.Al2O3 + self.Fe2O3 + self.SO3 + self.MgO + self.LOI
        if not (90.0 <= total <= 101.0):
            raise ValueError(f"{self.name}: oxide+LOI composition sums to {total:.1f}%, expected ~90-101%")


# Representative (SIMULATED / textbook-typical) raw materials.
LIMESTONE = RawMaterial(name="limestone", CaO=52.5, SiO2=3.0, Al2O3=0.8, Fe2O3=0.4, MgO=1.0, LOI=42.0)
CLAY = RawMaterial(name="clay", CaO=3.0, SiO2=58.0, Al2O3=18.0, Fe2O3=7.0, MgO=2.5, LOI=9.0)
SAND_CORRECTION = RawMaterial(name="silica_sand", CaO=0.5, SiO2=96.0, Al2O3=1.5, Fe2O3=0.8, LOI=0.5)
IRON_ORE_CORRECTION = RawMaterial(name="iron_ore", CaO=1.0, SiO2=8.0, Al2O3=4.0, Fe2O3=82.0, LOI=3.0)


@dataclass
class RawMealBlend:
    """A quarry blend defined by mass fractions (must sum to 1.0)."""

    components: dict[RawMaterial, float]

    def __post_init__(self) -> None:
        total = sum(self.components.values())
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"raw meal mass fractions must sum to 1.0, got {total:.4f}")
        for material in self.components:
            material.validate()

    def blended_oxides_ignited_basis(self) -> OxideComposition:
        """Blend oxide composition on an *ignited* (LOI-free, i.e.
        post-calcination) basis, which is what feeds the Bogue equations
        for clinker (the raw meal loses CO2/H2O in the kiln before clinker
        forms).
        """
        def blended(attr: str) -> float:
            raw = sum(getattr(m, attr) * frac for m, frac in self.components.items())
            return raw

        loi = blended("LOI")
        ignited_mass_fraction = 1.0 - loi / 100.0
        if ignited_mass_fraction <= 0:
            raise ValueError("raw meal LOI implausibly high (>=100%)")

        def ignited(attr: str) -> float:
            return blended(attr) / ignited_mass_fraction

        return OxideComposition(
            CaO=ignited("CaO"),
            SiO2=ignited("SiO2"),
            Al2O3=ignited("Al2O3"),
            Fe2O3=ignited("Fe2O3"),
            SO3=ignited("SO3"),
            MgO=ignited("MgO"),
        )

    def loi_pct(self) -> float:
        return sum(m.LOI * frac for m, frac in self.components.items())


def default_raw_meal_blend() -> RawMealBlend:
    """A SIMULATED, illustrative quarry blend tuned (by grid search against
    LSF~95 / SM~2.5 / AM~1.6 targets) to give a 'reasonable OPC-like'
    clinker composition (~66% C3S, ~12% C2S, ~9% C3A, ~11% C4AF). Real
    plants determine this via daily QC/XRF and a raw-mix design."""
    return RawMealBlend(
        components={
            LIMESTONE: 0.810,
            CLAY: 0.155,
            SAND_CORRECTION: 0.025,
            IRON_ORE_CORRECTION: 0.010,
        }
    )


def lime_saturation_factor(ox: OxideComposition) -> float:
    """LSF = 100 * CaO / (2.8*SiO2 + 1.65*Al2O3 + 0.35*Fe2O3).
    Typical Portland clinker target: 92-98."""
    denom = 2.8 * ox.SiO2 + 1.65 * ox.Al2O3 + 0.35 * ox.Fe2O3
    if denom <= 0:
        raise ValueError("degenerate oxide composition for LSF")
    return 100.0 * ox.CaO / denom


def silica_modulus(ox: OxideComposition) -> float:
    """SM = SiO2 / (Al2O3 + Fe2O3). Typical: 2.0-3.0."""
    denom = ox.Al2O3 + ox.Fe2O3
    if denom <= 0:
        raise ValueError("degenerate oxide composition for silica modulus")
    return ox.SiO2 / denom


def alumina_modulus(ox: OxideComposition) -> float:
    """AM = Al2O3 / Fe2O3. Typical: 1.0-2.5."""
    if ox.Fe2O3 <= 0:
        raise ValueError("Fe2O3 must be > 0 for alumina modulus")
    return ox.Al2O3 / ox.Fe2O3
