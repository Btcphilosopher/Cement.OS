"""
cement.kiln
============

Simplified rotary kiln + preheater/precalciner simulator.

Models a steady-state pass of raw meal through five temperature zones
(preheating, calcination, transition, sintering, cooling), tracking mass
flow, calcination chemistry (CaCO3 -> CaO + CO2), fuel/energy consumption
and CO2 emissions.

This is a lumped, steady-state process model (not CFD, not dynamic PID
control). It is suitable for mass/energy/carbon accounting and scenario
comparison, not for real kiln control-loop design.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from ..core.balances import check_mass_balance, relative_tolerance_kg
from ..core.chemistry import OxideComposition
from ..core.thermodynamics import SPECIFIC_HEAT_J_PER_KGK, sensible_heat_j

# Molar masses (g/mol)
M_CACO3 = 100.09
M_CAO = 56.08
M_CO2 = 44.01

# Heat of calcination reaction CaCO3 -> CaO + CO2, kJ/kg CaCO3 (endothermic)
CALCINATION_ENTHALPY_KJ_PER_KG_CACO3 = 1780.0

# Typical fuel lower heating values, MJ/kg (SIMULATED representative values)
FUEL_LHV_MJ_PER_KG = {
    "coal": 25.0,
    "petcoke": 32.0,
    "natural_gas": 47.0,  # MJ/kg (~50 MJ/kg typical, plant-dependent)
    "alternative_fuel": 18.0,  # e.g. RDF/tyres blend, highly variable in reality
}

# Fuel-specific CO2 emission factors, kg CO2 / kg fuel (SIMULATED, indicative)
FUEL_CO2_KG_PER_KG = {
    "coal": 2.42,
    "petcoke": 3.40,
    "natural_gas": 2.75,
    "alternative_fuel": 1.60,  # lower net-CO2 credit assumption for biogenic/waste content
}


class KilnZone(str, Enum):
    PREHEATING = "preheating"
    CALCINATION = "calcination"
    TRANSITION = "transition"
    SINTERING = "sintering"
    COOLING = "cooling"


@dataclass(frozen=True)
class KilnZoneProfile:
    zone: KilnZone
    entry_temp_c: float
    exit_temp_c: float
    residence_time_min: float


DEFAULT_ZONE_PROFILE: tuple[KilnZoneProfile, ...] = (
    KilnZoneProfile(KilnZone.PREHEATING, 60, 800, 30.0),
    KilnZoneProfile(KilnZone.CALCINATION, 800, 900, 15.0),
    KilnZoneProfile(KilnZone.TRANSITION, 900, 1250, 8.0),
    KilnZoneProfile(KilnZone.SINTERING, 1250, 1450, 12.0),
    KilnZoneProfile(KilnZone.COOLING, 1450, 100, 20.0),
)


@dataclass
class KilnInputs:
    raw_meal_feed_kg_h: float
    caco3_fraction_of_raw_meal: float  # mass fraction of CaCO3 in the raw meal (pre-calcination)
    fuel_type: str = "coal"
    fuel_feed_kg_h: float = 0.0
    thermal_efficiency: float = 0.62  # SIMULATED overall thermal efficiency (0-1)
    calcination_degree_target: float = 0.95  # fraction of CaCO3 actually decomposed
    kiln_speed_rpm: float = 3.5
    excess_air_ratio: float = 1.15  # >1 = excess combustion air
    ambient_temp_c: float = 20.0

    def __post_init__(self) -> None:
        if self.raw_meal_feed_kg_h <= 0:
            raise ValueError("raw_meal_feed_kg_h must be positive")
        if not (0.0 <= self.caco3_fraction_of_raw_meal <= 1.0):
            raise ValueError("caco3_fraction_of_raw_meal must be within [0,1]")
        if self.fuel_type not in FUEL_LHV_MJ_PER_KG:
            raise ValueError(f"unknown fuel_type '{self.fuel_type}'")
        if not (0.0 < self.thermal_efficiency <= 1.0):
            raise ValueError("thermal_efficiency must be within (0,1]")
        if not (0.0 <= self.calcination_degree_target <= 1.0):
            raise ValueError("calcination_degree_target must be within [0,1]")


@dataclass
class KilnOutputs:
    clinker_kg_h: float
    co2_calcination_kg_h: float
    co2_fuel_kg_h: float
    co2_total_kg_h: float
    dust_kg_h: float
    heat_loss_mj_h: float
    energy_required_mj_h: float
    fuel_required_kg_h: float
    specific_energy_mj_per_t_clinker: float
    mass_balance_ok: bool
    zone_profile: tuple[KilnZoneProfile, ...] = field(default_factory=lambda: DEFAULT_ZONE_PROFILE)


class RotaryKiln:
    """Simplified rotary kiln + precalciner steady-state simulator."""

    def __init__(self, zone_profile: tuple[KilnZoneProfile, ...] = DEFAULT_ZONE_PROFILE) -> None:
        self.zone_profile = zone_profile

    def total_residence_time_min(self) -> float:
        return sum(z.residence_time_min for z in self.zone_profile)

    def simulate(self, inputs: KilnInputs) -> KilnOutputs:
        feed = inputs.raw_meal_feed_kg_h
        caco3_kg_h = feed * inputs.caco3_fraction_of_raw_meal
        caco3_decomposed_kg_h = caco3_kg_h * inputs.calcination_degree_target

        # Stoichiometry: CaCO3 -> CaO + CO2
        cao_produced_kg_h = caco3_decomposed_kg_h * (M_CAO / M_CACO3)
        co2_calcination_kg_h = caco3_decomposed_kg_h * (M_CO2 / M_CACO3)

        # Mass balance: raw meal in = clinker out + CO2 released + dust losses
        dust_fraction = 0.01  # 1% dust carryover, SIMULATED
        dust_kg_h = feed * dust_fraction
        clinker_kg_h = feed - co2_calcination_kg_h - dust_kg_h

        check_mass_balance(
            inputs_kg=feed,
            outputs_kg=clinker_kg_h + co2_calcination_kg_h,
            losses_kg=dust_kg_h,
            tolerance_kg=relative_tolerance_kg(feed, relative_pct=0.01),
        )

        # Energy: calcination heat + sensible heat to raise raw meal from
        # ambient to sintering exit temperature + heat losses.
        calcination_heat_mj_h = (
            caco3_decomposed_kg_h * CALCINATION_ENTHALPY_KJ_PER_KG_CACO3 / 1000.0
        )
        sintering_exit_c = self.zone_profile[3].exit_temp_c
        sensible_heat_mj_h = sensible_heat_j(
            mass_kg=feed,
            specific_heat_j_per_kgk=SPECIFIC_HEAT_J_PER_KGK["raw_meal"],
            delta_t_k=(sintering_exit_c - inputs.ambient_temp_c),
        ) / 1e6

        theoretical_energy_mj_h = calcination_heat_mj_h + sensible_heat_mj_h
        energy_required_mj_h = theoretical_energy_mj_h / inputs.thermal_efficiency
        heat_loss_mj_h = energy_required_mj_h - theoretical_energy_mj_h

        lhv = FUEL_LHV_MJ_PER_KG[inputs.fuel_type]
        fuel_required_kg_h = energy_required_mj_h / lhv
        co2_fuel_kg_h = fuel_required_kg_h * FUEL_CO2_KG_PER_KG[inputs.fuel_type]

        co2_total_kg_h = co2_calcination_kg_h + co2_fuel_kg_h
        specific_energy = energy_required_mj_h / (clinker_kg_h / 1000.0) if clinker_kg_h > 0 else float("nan")

        return KilnOutputs(
            clinker_kg_h=clinker_kg_h,
            co2_calcination_kg_h=co2_calcination_kg_h,
            co2_fuel_kg_h=co2_fuel_kg_h,
            co2_total_kg_h=co2_total_kg_h,
            dust_kg_h=dust_kg_h,
            heat_loss_mj_h=heat_loss_mj_h,
            energy_required_mj_h=energy_required_mj_h,
            fuel_required_kg_h=fuel_required_kg_h,
            specific_energy_mj_per_t_clinker=specific_energy,
            mass_balance_ok=True,
            zone_profile=self.zone_profile,
        )
