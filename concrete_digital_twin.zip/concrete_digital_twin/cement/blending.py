"""
cement.blending
=================

Combines clinker + gypsum + SCMs + fillers into a finished :class:`Cement`
material record, deriving density, reactivity and water-demand properties
from the blend composition and cement.chemistry outputs.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.chemistry import ClinkerPhases, water_demand_ml_per_100g
from ..core.materials import Cement, CementClass, DataProvenance, SCM

# SIMULATED relative reactivity of SCMs vs clinker over 28d (dimensionless).
_SCM_REACTIVITY_28D = {
    "ground granulated blast furnace slag": 0.70,
    "fly ash": 0.45,
    "silica fume": 1.10,
    "natural pozzolan": 0.40,
    "calcined clay": 0.65,
    "limestone filler": 0.05,
}


@dataclass
class BlendComponent:
    """A component of a cement blend by mass fraction of the total cement."""

    name: str
    mass_fraction: float
    density_kg_m3: float
    reactivity: float  # 0-1+ relative to clinker


@dataclass
class CementBlend:
    clinker_fraction: float
    gypsum_fraction: float
    scm: SCM | None = None
    scm_fraction: float = 0.0
    filler_fraction: float = 0.0

    def __post_init__(self) -> None:
        total = self.clinker_fraction + self.gypsum_fraction + self.scm_fraction + self.filler_fraction
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"cement blend fractions must sum to 1.0, got {total:.4f}")
        if self.scm_fraction > 0 and self.scm is None:
            raise ValueError("scm_fraction > 0 requires an scm material")

    def blended_density_kg_m3(self, clinker_density_kg_m3: float = 3150.0, gypsum_density_kg_m3: float = 2320.0, filler_density_kg_m3: float = 2710.0) -> float:
        """Volume-weighted (via 1/rho harmonic-style rule of mixtures for
        bulk cement density -- standard approach for composite densities
        by mass fraction)."""
        inv_density = self.clinker_fraction / clinker_density_kg_m3
        inv_density += self.gypsum_fraction / gypsum_density_kg_m3
        inv_density += self.filler_fraction / filler_density_kg_m3
        if self.scm is not None and self.scm_fraction > 0:
            inv_density += self.scm_fraction / self.scm.density_kg_m3
        return 1.0 / inv_density

    def clinker_factor(self) -> float:
        return self.clinker_fraction

    def cement_class(self) -> CementClass:
        if self.scm is None or self.scm_fraction == 0:
            if self.filler_fraction > 0.05:
                return CementClass.PLC
            return CementClass.OPC
        scm_type = self.scm.scm_type.value
        if "slag" in scm_type:
            return CementClass.BFSC
        if "fly ash" in scm_type:
            return CementClass.FLYASH
        return CementClass.POZZOLANIC


def build_cement(
    blend: CementBlend,
    phases: ClinkerPhases,
    blaine_m2_kg: float,
    cost_per_tonne: float,
    clinker_co2_kg_per_t: float,
    scm_co2_kg_per_t: float = 5.0,
    gypsum_co2_kg_per_t: float = 10.0,
    filler_co2_kg_per_t: float = 5.0,
    name: str = "Blended Cement",
    supplier: str = "Northshire Cement Works",
) -> Cement:
    """Assemble a finished :class:`Cement` material record from a blend."""

    density = blend.blended_density_kg_m3()
    specific_gravity = density / 1000.0

    water_demand_clinker = water_demand_ml_per_100g(phases, blaine_m2_kg)
    scm_reactivity = 0.0
    if blend.scm is not None and blend.scm_fraction > 0:
        scm_reactivity = _SCM_REACTIVITY_28D.get(blend.scm.scm_type.value, 0.5)
    # Water demand factor: SCM generally reduces water demand slightly for
    # slag/fly ash (ball-bearing effect) but increases it for silica fume;
    # blended with clinker-only demand as a simple weighted approximation.
    scm_water_multiplier = {
        "ground granulated blast furnace slag": 0.97,
        "fly ash": 0.93,
        "silica fume": 1.25,
        "natural pozzolan": 1.05,
        "calcined clay": 1.10,
        "limestone filler": 1.0,
    }
    water_multiplier = 1.0
    if blend.scm is not None and blend.scm_fraction > 0:
        m = scm_water_multiplier.get(blend.scm.scm_type.value, 1.0)
        water_multiplier = (1 - blend.scm_fraction) * 1.0 + blend.scm_fraction * m

    reactivity_index = blend.clinker_fraction * 1.0 + blend.scm_fraction * scm_reactivity + blend.filler_fraction * 0.05

    embodied_carbon = (
        blend.clinker_fraction * clinker_co2_kg_per_t
        + blend.gypsum_fraction * gypsum_co2_kg_per_t
        + blend.scm_fraction * scm_co2_kg_per_t
        + blend.filler_fraction * filler_co2_kg_per_t
    )

    return Cement(
        name=name,
        supplier=supplier,
        cost_per_tonne=cost_per_tonne,
        embodied_carbon_kgco2e_per_tonne=embodied_carbon,
        data_provenance=DataProvenance.SIMULATED,
        density_kg_m3=density,
        specific_gravity=specific_gravity,
        blaine_fineness_m2_kg=blaine_m2_kg,
        reactivity_index=reactivity_index,
        water_demand_factor=water_demand_clinker / 24.0 * water_multiplier,
        cement_class=blend.cement_class(),
        clinker_factor=blend.clinker_factor(),
    )
