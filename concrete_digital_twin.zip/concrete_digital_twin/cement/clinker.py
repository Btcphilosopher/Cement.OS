"""
cement.clinker
================

Tracks a batch/stream of clinker: phase composition, mass, temperature,
a simple 0-100 "quality index", specific energy and carbon intensity.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.chemistry import ClinkerPhases, chemistry_strength_index


@dataclass
class ClinkerBatch:
    mass_kg: float
    phases: ClinkerPhases
    exit_temp_c: float
    specific_energy_mj_per_t: float
    co2_kg_per_t: float

    def __post_init__(self) -> None:
        if self.mass_kg < 0:
            raise ValueError("mass_kg cannot be negative")

    @property
    def quality_index(self) -> float:
        """SIMULATED 0-100 quality index combining phase balance and
        free-lime-style penalty proxy (here approximated via total
        silicates share, since free lime isn't tracked explicitly)."""
        strength_idx = chemistry_strength_index(self.phases)
        silicate_share = self.phases.total_silicates / 100.0
        raw_score = 0.6 * strength_idx + 0.4 * silicate_share
        return max(0.0, min(100.0, raw_score * 100.0 / 1.05))

    def clinker_factor_carbon_kgco2e_per_t_cement(self, clinker_factor: float) -> float:
        """CO2 intensity attributable to the clinker fraction of a cement,
        scaled by clinker_factor (mass fraction of clinker in cement)."""
        if not (0.0 <= clinker_factor <= 1.0):
            raise ValueError("clinker_factor must be within [0,1]")
        return self.co2_kg_per_t * clinker_factor
