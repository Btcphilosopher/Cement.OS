"""Cement production: raw materials -> kiln -> clinker -> grinding -> blending."""
