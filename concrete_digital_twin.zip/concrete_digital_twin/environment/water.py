"""
environment.water
====================

Process/mix/wash water tracking and recycling balance, reported as
litres/tonne cement and litres/m3 concrete.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.balances import check_mass_balance, relative_tolerance_kg

WATER_DENSITY_KG_PER_L = 1.0


@dataclass
class WaterBalance:
    process_water_l: float
    mix_water_l: float
    wash_water_l: float
    recycled_water_l: float
    evaporation_l: float

    @property
    def total_intake_l(self) -> float:
        return self.process_water_l + self.mix_water_l + self.wash_water_l

    @property
    def net_fresh_water_demand_l(self) -> float:
        return max(0.0, self.total_intake_l - self.recycled_water_l)

    def check(self) -> None:
        """Water balance: intake = consumed (mix) + evaporated + recycled + discharge.
        We treat 'discharge' implicitly as whatever isn't accounted for, and
        assert it is non-negative (i.e. recycling + evaporation can't exceed intake)."""
        accounted = self.recycled_water_l + self.evaporation_l
        check_mass_balance(
            inputs_kg=self.total_intake_l * WATER_DENSITY_KG_PER_L,
            outputs_kg=self.mix_water_l * WATER_DENSITY_KG_PER_L,
            losses_kg=max(0.0, accounted - self.mix_water_l) * WATER_DENSITY_KG_PER_L + 1e-9,
            tolerance_kg=relative_tolerance_kg(self.total_intake_l, 5.0),
            raise_on_fail=False,
        )


def litres_per_tonne_cement(balance: WaterBalance, cement_tonnes: float) -> float:
    if cement_tonnes <= 0:
        raise ValueError("cement_tonnes must be positive")
    return balance.net_fresh_water_demand_l / cement_tonnes


def litres_per_m3_concrete(mix_water_l: float, wash_water_l: float, volume_m3: float) -> float:
    if volume_m3 <= 0:
        raise ValueError("volume_m3 must be positive")
    return (mix_water_l + wash_water_l) / volume_m3
