"""Environmental accounting: carbon, energy, emissions, water."""
