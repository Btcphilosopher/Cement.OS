"""
environment.carbon
=====================

Carbon (CO2e) accounting across the plant: calcination, fuel combustion,
electricity, transport and raw-material embodied carbon, rolled up to
kgCO2e/tonne clinker, kgCO2e/tonne cement and kgCO2e/m3 concrete.

Grid emission factors and transport factors are configurable so scenarios
(low-carbon electricity, alternative fuel, etc.) can be compared -- see
environment.emissions and the "carbon optimisation" examples.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # avoid a runtime circular import with mix_design
    from ..mix_design.mix import MixDesignEngine, MixDesignResult


# Configurable grid emission factor, kg CO2e / kWh. SIMULATED default
# (illustrative UK-grid-like figure); override per plant/scenario.
DEFAULT_GRID_EMISSION_FACTOR_KGCO2E_PER_KWH = 0.20

# Transport CO2 factor, kg CO2e per tonne-km (typical rigid diesel truck,
# SIMULATED/illustrative).
DEFAULT_TRANSPORT_KGCO2E_PER_TONNE_KM = 0.10


@dataclass
class CarbonBreakdown:
    calcination_kgco2e: float
    fuel_kgco2e: float
    electricity_kgco2e: float
    transport_kgco2e: float
    raw_material_kgco2e: float

    @property
    def total_kgco2e(self) -> float:
        return (
            self.calcination_kgco2e
            + self.fuel_kgco2e
            + self.electricity_kgco2e
            + self.transport_kgco2e
            + self.raw_material_kgco2e
        )


def clinker_carbon_breakdown(
    co2_calcination_kg_h: float,
    co2_fuel_kg_h: float,
    clinker_kg_h: float,
    mill_power_kw: float = 0.0,
    grid_factor_kgco2e_per_kwh: float = DEFAULT_GRID_EMISSION_FACTOR_KGCO2E_PER_KWH,
    raw_material_transport_kgco2e_h: float = 0.0,
) -> CarbonBreakdown:
    """Per-hour carbon breakdown from a kiln simulation, normalised later
    to per-tonne-clinker by the caller (divide by clinker_kg_h/1000)."""
    if clinker_kg_h <= 0:
        raise ValueError("clinker_kg_h must be positive")
    electricity_kgco2e_h = mill_power_kw * grid_factor_kgco2e_per_kwh
    return CarbonBreakdown(
        calcination_kgco2e=co2_calcination_kg_h,
        fuel_kgco2e=co2_fuel_kg_h,
        electricity_kgco2e=electricity_kgco2e_h,
        transport_kgco2e=raw_material_transport_kgco2e_h,
        raw_material_kgco2e=0.0,
    )


def kgco2e_per_tonne_clinker(breakdown: CarbonBreakdown, clinker_kg_h: float) -> float:
    if clinker_kg_h <= 0:
        raise ValueError("clinker_kg_h must be positive")
    return breakdown.total_kgco2e / (clinker_kg_h / 1000.0)


def kgco2e_per_tonne_cement(clinker_co2_per_t: float, clinker_factor: float, grinding_kwh_per_t: float, grid_factor: float = DEFAULT_GRID_EMISSION_FACTOR_KGCO2E_PER_KWH, scm_co2_per_t: float = 5.0, scm_fraction: float = 0.0) -> float:
    """Roll clinker carbon (scaled by clinker factor) + grinding
    electricity + SCM embodied carbon up to a per-tonne-cement figure."""
    if not (0.0 <= clinker_factor <= 1.0):
        raise ValueError("clinker_factor must be within [0,1]")
    clinker_share = clinker_co2_per_t * clinker_factor
    grinding_share = grinding_kwh_per_t * grid_factor
    scm_share = scm_co2_per_t * scm_fraction
    return clinker_share + grinding_share + scm_share


def transport_carbon_kgco2e(mass_tonnes: float, distance_km: float, factor_kgco2e_per_tonne_km: float = DEFAULT_TRANSPORT_KGCO2E_PER_TONNE_KM) -> float:
    if mass_tonnes < 0 or distance_km < 0:
        raise ValueError("mass_tonnes and distance_km cannot be negative")
    return mass_tonnes * distance_km * factor_kgco2e_per_tonne_km


def mix_carbon_kgco2e_per_m3(
    result: "MixDesignResult",
    engine: "MixDesignEngine",
    transport_km: float = 0.0,
    truck_capacity_m3: float = 6.0,
    transport_factor_kgco2e_per_tonne_km: float = DEFAULT_TRANSPORT_KGCO2E_PER_TONNE_KM,
) -> float:
    """Embodied carbon per m3 of a designed concrete mix: sum of
    (material mass * material embodied-carbon factor) for cement, SCM,
    fine/coarse aggregate and admixture, plus optional delivery transport.
    """
    cement_co2 = (result.cement_kg / 1000.0) * engine.cement.embodied_carbon_kgco2e_per_tonne
    scm_co2 = 0.0
    if engine.scm is not None and result.scm_kg > 0:
        scm_co2 = (result.scm_kg / 1000.0) * engine.scm.embodied_carbon_kgco2e_per_tonne
    fine_co2 = (result.fine_aggregate_kg / 1000.0) * engine.fine_aggregate.embodied_carbon_kgco2e_per_tonne
    coarse_co2 = (result.coarse_aggregate_kg / 1000.0) * engine.coarse_aggregate.embodied_carbon_kgco2e_per_tonne
    admixture_co2 = 0.0
    for dose in engine.admixture_doses:
        binder_kg = result.cement_kg + result.scm_kg
        admixture_co2 += (dose.mass_kg(binder_kg) / 1000.0) * dose.admixture.embodied_carbon_kgco2e_per_tonne

    transport_co2 = 0.0
    if transport_km > 0:
        mass_tonnes = result.total_mass_kg / 1000.0
        transport_co2 = transport_carbon_kgco2e(mass_tonnes, transport_km, transport_factor_kgco2e_per_tonne_km)

    return cement_co2 + scm_co2 + fine_co2 + coarse_co2 + admixture_co2 + transport_co2


@dataclass
class CarbonScenarioComparison:
    baseline_kgco2e_per_m3: float
    optimised_kgco2e_per_m3: float

    @property
    def reduction_kgco2e_per_m3(self) -> float:
        return self.baseline_kgco2e_per_m3 - self.optimised_kgco2e_per_m3

    @property
    def reduction_pct(self) -> float:
        if self.baseline_kgco2e_per_m3 == 0:
            return 0.0
        return 100.0 * self.reduction_kgco2e_per_m3 / self.baseline_kgco2e_per_m3
