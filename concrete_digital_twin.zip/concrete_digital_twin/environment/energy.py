"""
environment.energy
=====================

Energy intensity roll-ups: kWh/tonne cement, kWh/m3 concrete, MJ/tonne
clinker, MJ/tonne cement, tracking electricity, fuel and recovered/waste
heat separately.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EnergyStreams:
    electricity_kwh: float = 0.0
    natural_gas_mj: float = 0.0
    coal_mj: float = 0.0
    alternative_fuel_mj: float = 0.0
    waste_heat_recovered_mj: float = 0.0

    @property
    def total_fuel_mj(self) -> float:
        return self.natural_gas_mj + self.coal_mj + self.alternative_fuel_mj

    @property
    def total_primary_energy_mj(self) -> float:
        return self.total_fuel_mj + self.electricity_kwh * 3.6

    @property
    def net_energy_mj(self) -> float:
        return self.total_primary_energy_mj - self.waste_heat_recovered_mj


def kwh_per_tonne_cement(mill_kwh: float, other_electrical_kwh: float, cement_tonnes: float) -> float:
    if cement_tonnes <= 0:
        raise ValueError("cement_tonnes must be positive")
    return (mill_kwh + other_electrical_kwh) / cement_tonnes


def kwh_per_m3_concrete(batching_kwh: float, mixing_kwh: float, transport_kwh: float, volume_m3: float) -> float:
    if volume_m3 <= 0:
        raise ValueError("volume_m3 must be positive")
    return (batching_kwh + mixing_kwh + transport_kwh) / volume_m3


def mj_per_tonne_clinker(streams: EnergyStreams, clinker_tonnes: float) -> float:
    if clinker_tonnes <= 0:
        raise ValueError("clinker_tonnes must be positive")
    return streams.total_primary_energy_mj / clinker_tonnes


def mj_per_tonne_cement(streams: EnergyStreams, cement_tonnes: float) -> float:
    if cement_tonnes <= 0:
        raise ValueError("cement_tonnes must be positive")
    return streams.total_primary_energy_mj / cement_tonnes
