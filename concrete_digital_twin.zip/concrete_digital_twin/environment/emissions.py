"""
environment.emissions
========================

Non-CO2 stack emissions (dust, NOx, SO2) as SIMPLIFIED emission-factor
estimates driven by fuel consumption and kiln operating conditions. These
are indicative teaching-level figures, not a substitute for continuous
emissions monitoring (CEMS) data or a regulatory compliance model.
"""

from __future__ import annotations

from dataclasses import dataclass

# kg pollutant per tonne of fuel burned, SIMULATED indicative factors.
_EMISSION_FACTORS_KG_PER_T_FUEL = {
    "coal": {"dust": 0.40, "NOx": 3.5, "SO2": 8.0},
    "petcoke": {"dust": 0.35, "NOx": 3.0, "SO2": 12.0},
    "natural_gas": {"dust": 0.02, "NOx": 2.0, "SO2": 0.05},
    "alternative_fuel": {"dust": 0.50, "NOx": 2.5, "SO2": 3.0},
}


@dataclass
class StackEmissions:
    dust_kg: float
    nox_kg: float
    so2_kg: float


def estimate_stack_emissions(fuel_type: str, fuel_kg: float, abatement_efficiency: float = 0.98) -> StackEmissions:
    if fuel_type not in _EMISSION_FACTORS_KG_PER_T_FUEL:
        raise ValueError(f"unknown fuel_type '{fuel_type}'")
    if not (0.0 <= abatement_efficiency <= 1.0):
        raise ValueError("abatement_efficiency must be within [0,1]")
    factors = _EMISSION_FACTORS_KG_PER_T_FUEL[fuel_type]
    fuel_t = fuel_kg / 1000.0
    retained = 1.0 - abatement_efficiency
    return StackEmissions(
        dust_kg=factors["dust"] * fuel_t * retained,
        nox_kg=factors["NOx"] * fuel_t,  # NOx abatement (SCR/SNCR) not modelled here
        so2_kg=factors["SO2"] * fuel_t * retained,
    )
