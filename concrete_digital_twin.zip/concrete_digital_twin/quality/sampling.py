"""
quality.sampling
===================

Synthetic test-sample generator: batch -> slump sample -> air sample ->
density sample -> 7-day / 28-day strength samples, with a stored sample
history (a simple in-memory "lab register").
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
import random


@dataclass
class Sample:
    sample_id: str
    batch_id: str
    test_type: str
    sample_time: datetime
    result_time: datetime
    value: float
    unit: str


@dataclass
class SampleHistory:
    samples: list[Sample] = field(default_factory=list)

    def add(self, sample: Sample) -> None:
        self.samples.append(sample)

    def by_test_type(self, test_type: str) -> list[Sample]:
        return [s for s in self.samples if s.test_type == test_type]

    def values(self, test_type: str) -> list[float]:
        return [s.value for s in self.by_test_type(test_type)]


def generate_batch_samples(
    batch_id: str,
    batch_time: datetime,
    target_slump_mm: float,
    target_air_pct: float,
    target_density_kg_m3: float,
    target_strength_7d_mpa: float,
    target_strength_28d_mpa: float,
    rng: random.Random | None = None,
    slump_std_mm: float = 12.0,
    air_std_pct: float = 0.4,
    density_std_kg_m3: float = 15.0,
    strength_cov: float = 0.08,
) -> list[Sample]:
    """Generate a realistic-looking set of QC samples for one batch with
    Gaussian process/test variability around the design targets."""
    rng = rng or random.Random()
    samples = []

    samples.append(Sample(
        sample_id=f"{batch_id}-SLUMP", batch_id=batch_id, test_type="slump",
        sample_time=batch_time, result_time=batch_time,
        value=max(0.0, rng.gauss(target_slump_mm, slump_std_mm)), unit="mm",
    ))
    samples.append(Sample(
        sample_id=f"{batch_id}-AIR", batch_id=batch_id, test_type="air_content",
        sample_time=batch_time, result_time=batch_time,
        value=max(0.0, rng.gauss(target_air_pct, air_std_pct)), unit="%",
    ))
    samples.append(Sample(
        sample_id=f"{batch_id}-DENSITY", batch_id=batch_id, test_type="density",
        sample_time=batch_time, result_time=batch_time,
        value=max(0.0, rng.gauss(target_density_kg_m3, density_std_kg_m3)), unit="kg/m3",
    ))
    samples.append(Sample(
        sample_id=f"{batch_id}-7D", batch_id=batch_id, test_type="strength_7d",
        sample_time=batch_time, result_time=batch_time + timedelta(days=7),
        value=max(0.0, rng.gauss(target_strength_7d_mpa, target_strength_7d_mpa * strength_cov)), unit="MPa",
    ))
    samples.append(Sample(
        sample_id=f"{batch_id}-28D", batch_id=batch_id, test_type="strength_28d",
        sample_time=batch_time, result_time=batch_time + timedelta(days=28),
        value=max(0.0, rng.gauss(target_strength_28d_mpa, target_strength_28d_mpa * strength_cov)), unit="MPa",
    ))
    return samples
