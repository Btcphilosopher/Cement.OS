"""
quality.control_charts
=========================

Standard SPC control charts: X-bar/R, X-bar/S, individuals/moving-range.
Constants (A2, D3, D4, d2, etc.) are the standard Shewhart control-chart
constants.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# Standard Shewhart control chart constants by subgroup size n (2-10).
_A2 = {2: 1.880, 3: 1.023, 4: 0.729, 5: 0.577, 6: 0.483, 7: 0.419, 8: 0.373, 9: 0.337, 10: 0.308}
_D3 = {2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0.076, 8: 0.136, 9: 0.184, 10: 0.223}
_D4 = {2: 3.267, 3: 2.574, 4: 2.282, 5: 2.114, 6: 2.004, 7: 1.924, 8: 1.864, 9: 1.816, 10: 1.777}
_A3 = {2: 2.659, 3: 1.954, 4: 1.628, 5: 1.427, 6: 1.287, 7: 1.182, 8: 1.099, 9: 1.032, 10: 0.975}
_B3 = {2: 0, 3: 0, 4: 0, 5: 0, 6: 0.030, 7: 0.118, 8: 0.185, 9: 0.239, 10: 0.284}
_B4 = {2: 3.267, 3: 2.568, 4: 2.266, 5: 2.089, 6: 1.970, 7: 1.882, 8: 1.815, 9: 1.761, 10: 1.716}
_D2_INDIVIDUALS = 1.128  # for moving range of size 2


@dataclass
class ControlChartLimits:
    center_line: float
    upper_control_limit: float
    lower_control_limit: float
    subgroup_statistic: list[float]
    out_of_control_indices: list[int]
    spec_lower: float | None = None
    spec_upper: float | None = None


def _out_of_control(values: list[float], ucl: float, lcl: float) -> list[int]:
    return [i for i, v in enumerate(values) if v > ucl or v < lcl]


def xbar_r_chart(subgroups: list[list[float]], spec_lower: float | None = None, spec_upper: float | None = None) -> tuple[ControlChartLimits, ControlChartLimits]:
    """Returns (xbar_chart, r_chart)."""
    if not subgroups:
        raise ValueError("subgroups cannot be empty")
    n = len(subgroups[0])
    if n < 2 or n > 10:
        raise ValueError("subgroup size must be within [2, 10] for standard constants")
    if any(len(g) != n for g in subgroups):
        raise ValueError("all subgroups must have the same size")

    means = [float(np.mean(g)) for g in subgroups]
    ranges = [float(np.max(g) - np.min(g)) for g in subgroups]

    xbar_bar = float(np.mean(means))
    r_bar = float(np.mean(ranges))

    a2, d3, d4 = _A2[n], _D3[n], _D4[n]

    xbar_ucl = xbar_bar + a2 * r_bar
    xbar_lcl = xbar_bar - a2 * r_bar
    r_ucl = d4 * r_bar
    r_lcl = d3 * r_bar

    xbar_chart = ControlChartLimits(
        center_line=xbar_bar, upper_control_limit=xbar_ucl, lower_control_limit=xbar_lcl,
        subgroup_statistic=means, out_of_control_indices=_out_of_control(means, xbar_ucl, xbar_lcl),
        spec_lower=spec_lower, spec_upper=spec_upper,
    )
    r_chart = ControlChartLimits(
        center_line=r_bar, upper_control_limit=r_ucl, lower_control_limit=r_lcl,
        subgroup_statistic=ranges, out_of_control_indices=_out_of_control(ranges, r_ucl, r_lcl),
    )
    return xbar_chart, r_chart


def xbar_s_chart(subgroups: list[list[float]]) -> tuple[ControlChartLimits, ControlChartLimits]:
    n = len(subgroups[0])
    if n < 2 or n > 10:
        raise ValueError("subgroup size must be within [2, 10] for standard constants")
    means = [float(np.mean(g)) for g in subgroups]
    stds = [float(np.std(g, ddof=1)) for g in subgroups]

    xbar_bar = float(np.mean(means))
    s_bar = float(np.mean(stds))
    a3, b3, b4 = _A3[n], _B3[n], _B4[n]

    xbar_chart = ControlChartLimits(
        center_line=xbar_bar, upper_control_limit=xbar_bar + a3 * s_bar, lower_control_limit=xbar_bar - a3 * s_bar,
        subgroup_statistic=means, out_of_control_indices=_out_of_control(means, xbar_bar + a3 * s_bar, xbar_bar - a3 * s_bar),
    )
    s_chart = ControlChartLimits(
        center_line=s_bar, upper_control_limit=b4 * s_bar, lower_control_limit=b3 * s_bar,
        subgroup_statistic=stds, out_of_control_indices=_out_of_control(stds, b4 * s_bar, b3 * s_bar),
    )
    return xbar_chart, s_chart


def individuals_moving_range_chart(values: list[float]) -> tuple[ControlChartLimits, ControlChartLimits]:
    if len(values) < 2:
        raise ValueError("need at least 2 individual values")
    mr = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
    mr_bar = float(np.mean(mr))
    x_bar = float(np.mean(values))

    i_ucl = x_bar + 2.66 * mr_bar
    i_lcl = x_bar - 2.66 * mr_bar
    mr_ucl = 3.267 * mr_bar

    i_chart = ControlChartLimits(
        center_line=x_bar, upper_control_limit=i_ucl, lower_control_limit=i_lcl,
        subgroup_statistic=list(values), out_of_control_indices=_out_of_control(values, i_ucl, i_lcl),
    )
    mr_chart = ControlChartLimits(
        center_line=mr_bar, upper_control_limit=mr_ucl, lower_control_limit=0.0,
        subgroup_statistic=mr, out_of_control_indices=_out_of_control(mr, mr_ucl, 0.0),
    )
    return i_chart, mr_chart
