"""Quality control: QC engine, sampling, statistics, control charts."""
