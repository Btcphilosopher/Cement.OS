"""
quality.qc
============

Quality-control engine: compares batch/sample results against
specification limits (slump, air, density, strength, w/cm, cement
content, aggregate grading) and rolls up PASS/FAIL with SPC statistics.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .sampling import Sample, SampleHistory
from .statistics import process_capability_cpk, proportion_out_of_spec, summary_stats


@dataclass
class QCSpec:
    test_type: str
    lower_spec: float | None = None
    upper_spec: float | None = None
    unit: str = ""


@dataclass
class QCResult:
    test_type: str
    passed: bool
    n_samples: int
    mean: float
    std: float
    cpk: float | None
    pct_out_of_spec: float
    failing_sample_ids: list[str] = field(default_factory=list)


class QualityControlEngine:
    def __init__(self, specs: list[QCSpec]) -> None:
        self.specs = {s.test_type: s for s in specs}

    def evaluate(self, history: SampleHistory) -> list[QCResult]:
        results = []
        for test_type, spec in self.specs.items():
            samples = history.by_test_type(test_type)
            if not samples:
                continue
            values = [s.value for s in samples]
            stats = summary_stats(values)
            cpk = None
            if spec.lower_spec is not None or spec.upper_spec is not None:
                cpk = process_capability_cpk(values, spec.lower_spec, spec.upper_spec)
            pct_out = proportion_out_of_spec(values, spec.lower_spec, spec.upper_spec) if (spec.lower_spec or spec.upper_spec) else 0.0
            failing = [
                s.sample_id for s in samples
                if (spec.lower_spec is not None and s.value < spec.lower_spec)
                or (spec.upper_spec is not None and s.value > spec.upper_spec)
            ]
            results.append(QCResult(
                test_type=test_type,
                passed=len(failing) == 0,
                n_samples=stats.n,
                mean=stats.mean,
                std=stats.std,
                cpk=cpk,
                pct_out_of_spec=pct_out,
                failing_sample_ids=failing,
            ))
        return results

    def overall_pass(self, history: SampleHistory) -> bool:
        return all(r.passed for r in self.evaluate(history))


def default_concrete_qc_specs(
    target_slump_mm: float,
    target_air_pct: float,
    target_density_kg_m3: float,
    target_strength_28d_mpa: float,
    slump_tolerance_mm: float = 25.0,
    air_tolerance_pct: float = 1.5,
    density_tolerance_pct: float = 2.0,
) -> list[QCSpec]:
    return [
        QCSpec("slump", target_slump_mm - slump_tolerance_mm, target_slump_mm + slump_tolerance_mm, "mm"),
        QCSpec("air_content", max(0.0, target_air_pct - air_tolerance_pct), target_air_pct + air_tolerance_pct, "%"),
        QCSpec("density", target_density_kg_m3 * (1 - density_tolerance_pct / 100), target_density_kg_m3 * (1 + density_tolerance_pct / 100), "kg/m3"),
        QCSpec("strength_28d", target_strength_28d_mpa, None, "MPa"),
    ]
