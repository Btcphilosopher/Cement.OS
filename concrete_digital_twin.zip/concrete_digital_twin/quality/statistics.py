"""quality.statistics — summary statistics and process capability indices."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SummaryStats:
    n: int
    mean: float
    std: float
    minimum: float
    maximum: float
    median: float


def summary_stats(values: list[float]) -> SummaryStats:
    if not values:
        raise ValueError("values cannot be empty")
    arr = np.asarray(values, dtype=float)
    return SummaryStats(
        n=len(arr),
        mean=float(np.mean(arr)),
        std=float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0,
        minimum=float(np.min(arr)),
        maximum=float(np.max(arr)),
        median=float(np.median(arr)),
    )


def process_capability_cpk(values: list[float], lower_spec: float | None, upper_spec: float | None) -> float:
    """Cpk = min( (USL - mean)/(3*std), (mean - LSL)/(3*std) ), using
    whichever spec limits are supplied. A one-sided spec (e.g. strength
    only has a lower limit) uses only that side."""
    stats = summary_stats(values)
    if stats.std == 0:
        return float("inf")
    candidates = []
    if upper_spec is not None:
        candidates.append((upper_spec - stats.mean) / (3 * stats.std))
    if lower_spec is not None:
        candidates.append((stats.mean - lower_spec) / (3 * stats.std))
    if not candidates:
        raise ValueError("at least one of lower_spec/upper_spec must be provided")
    return min(candidates)


def proportion_out_of_spec(values: list[float], lower_spec: float | None, upper_spec: float | None) -> float:
    arr = np.asarray(values, dtype=float)
    mask = np.zeros_like(arr, dtype=bool)
    if lower_spec is not None:
        mask |= arr < lower_spec
    if upper_spec is not None:
        mask |= arr > upper_spec
    return float(np.mean(mask)) * 100.0
