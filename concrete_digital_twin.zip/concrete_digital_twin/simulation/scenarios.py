"""
simulation.scenarios
=======================

Named operating scenarios (section 47) that apply a coherent bundle of
parameter overrides -- e.g. HOT_WEATHER bumps ambient/concrete
temperature and reduces slump retention; CEMENT_SHORTAGE reduces silo
levels; HIGH_ENERGY_PRICE raises energy tariffs. Scenarios are pure data
+ an `apply()` that mutates a provided context dict, so they compose with
the Monte Carlo, discrete-event and mix-design engines without those
engines needing scenario-specific branches.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable


class ScenarioName(str, Enum):
    NORMAL_PRODUCTION = "normal_production"
    HIGH_DEMAND = "high_demand"
    LOW_DEMAND = "low_demand"
    CEMENT_SHORTAGE = "cement_shortage"
    AGGREGATE_SHORTAGE = "aggregate_shortage"
    HIGH_ENERGY_PRICE = "high_energy_price"
    LOW_ENERGY_PRICE = "low_energy_price"
    HOT_WEATHER = "hot_weather"
    COLD_WEATHER = "cold_weather"
    HIGH_MOISTURE = "high_moisture"
    PLANT_FAILURE = "plant_failure"
    TRUCK_SHORTAGE = "truck_shortage"
    LOW_CARBON_OPERATION = "low_carbon_operation"


@dataclass
class Scenario:
    name: ScenarioName
    description: str
    overrides: dict[str, Any] = field(default_factory=dict)
    apply_fn: Callable[[dict[str, Any]], dict[str, Any]] | None = None

    def apply(self, context: dict[str, Any]) -> dict[str, Any]:
        new_context = dict(context)
        new_context.update(self.overrides)
        if self.apply_fn is not None:
            new_context = self.apply_fn(new_context)
        return new_context


SCENARIOS: dict[ScenarioName, Scenario] = {
    ScenarioName.NORMAL_PRODUCTION: Scenario(
        ScenarioName.NORMAL_PRODUCTION, "Baseline operating conditions.", {},
    ),
    ScenarioName.HIGH_DEMAND: Scenario(
        ScenarioName.HIGH_DEMAND, "Order book above nameplate capacity; trucks and mixer at max utilisation.",
        {"demand_multiplier": 1.4, "truck_availability_pct": 0.95},
    ),
    ScenarioName.LOW_DEMAND: Scenario(
        ScenarioName.LOW_DEMAND, "Order book well below capacity.",
        {"demand_multiplier": 0.5, "truck_availability_pct": 1.0},
    ),
    ScenarioName.CEMENT_SHORTAGE: Scenario(
        ScenarioName.CEMENT_SHORTAGE, "Cement silo delivery delayed; available stock reduced.",
        {"cement_silo_level_multiplier": 0.15},
    ),
    ScenarioName.AGGREGATE_SHORTAGE: Scenario(
        ScenarioName.AGGREGATE_SHORTAGE, "Aggregate stockpile delivery delayed.",
        {"aggregate_stockpile_level_multiplier": 0.2},
    ),
    ScenarioName.HIGH_ENERGY_PRICE: Scenario(
        ScenarioName.HIGH_ENERGY_PRICE, "Electricity/fuel tariffs spike.",
        {"electricity_price_multiplier": 1.8, "fuel_price_multiplier": 1.5},
    ),
    ScenarioName.LOW_ENERGY_PRICE: Scenario(
        ScenarioName.LOW_ENERGY_PRICE, "Off-peak / low tariff period.",
        {"electricity_price_multiplier": 0.6, "fuel_price_multiplier": 0.85},
    ),
    ScenarioName.HOT_WEATHER: Scenario(
        ScenarioName.HOT_WEATHER, "High ambient temperature: faster slump loss, faster setting, higher water demand.",
        {"ambient_temp_c": 35.0, "slump_loss_rate_multiplier": 1.6},
    ),
    ScenarioName.COLD_WEATHER: Scenario(
        ScenarioName.COLD_WEATHER, "Low ambient temperature: slower strength gain, longer setting.",
        {"ambient_temp_c": 2.0, "strength_gain_multiplier": 0.7},
    ),
    ScenarioName.HIGH_MOISTURE: Scenario(
        ScenarioName.HIGH_MOISTURE, "Aggregates significantly wetter than SSD (e.g. after heavy rain).",
        {"aggregate_moisture_delta_pct": 4.0},
    ),
    ScenarioName.PLANT_FAILURE: Scenario(
        ScenarioName.PLANT_FAILURE, "A major piece of equipment (mixer/kiln/crusher) is down.",
        {"equipment_forced_down": True, "capacity_multiplier": 0.4},
    ),
    ScenarioName.TRUCK_SHORTAGE: Scenario(
        ScenarioName.TRUCK_SHORTAGE, "Reduced fleet availability (breakdowns / driver shortage).",
        {"truck_availability_pct": 0.5},
    ),
    ScenarioName.LOW_CARBON_OPERATION: Scenario(
        ScenarioName.LOW_CARBON_OPERATION, "Low clinker factor + renewable grid + alternative fuel mix.",
        {"grid_emission_factor_kgco2e_per_kwh": 0.05, "clinker_factor_target": 0.65, "fuel_type": "alternative_fuel"},
    ),
}


def get_scenario(name: ScenarioName) -> Scenario:
    return SCENARIOS[name]
