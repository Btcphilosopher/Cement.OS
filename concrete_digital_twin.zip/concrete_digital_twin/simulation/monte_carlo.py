"""
simulation.monte_carlo
=========================

Vectorised (NumPy) Monte Carlo uncertainty simulation for a designed mix:
propagates cement-strength variability, aggregate moisture uncertainty,
water/admixture dosing error, temperature variability, batch-scale error
and transport-time variability through the strength/slump models to
produce distributions (mean/median/std/P5/P50/P95) and quality-risk
probabilities (section 31 & 32).

All results are explicitly PROBABILISTIC SIMULATIONS, not guarantees.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from ..curing.slump import estimate_initial_slump_mm, slump_loss_over_time
from ..mix_design.cement import strength_for_wcm

if TYPE_CHECKING:
    from ..mix_design.mix import MixDesignResult


@dataclass
class UncertaintyConfig:
    cement_strength_cov: float = 0.08          # coefficient of variation on strength multiplier
    water_dosing_error_std_pct: float = 1.5    # % std on actual water vs target
    cement_dosing_error_std_pct: float = 1.0   # % std on actual cement vs target
    admixture_dosage_error_std_pct: float = 5.0
    temperature_std_c: float = 4.0
    transport_time_mean_min: float = 45.0
    transport_time_std_min: float = 12.0
    batch_scale_error_std_pct: float = 1.0


@dataclass
class MonteCarloResult:
    n_runs: int
    strength_mean: float
    strength_median: float
    strength_std: float
    strength_p5: float
    strength_p50: float
    strength_p95: float
    slump_mean: float
    slump_p5: float
    slump_p95: float
    prob_strength_below_target: float
    prob_slump_below_min: float
    prob_slump_above_max: float
    prob_wcm_above_limit: float
    prob_temperature_above_limit: float
    prob_batch_mass_out_of_tolerance: float
    raw_strengths: np.ndarray = field(repr=False)
    raw_slumps: np.ndarray = field(repr=False)


def run_monte_carlo(
    mix: "MixDesignResult",
    n_runs: int = 10000,
    config: UncertaintyConfig = UncertaintyConfig(),
    target_strength_mpa: float | None = None,
    min_slump_mm: float | None = None,
    max_slump_mm: float | None = None,
    wcm_limit: float | None = None,
    temperature_limit_c: float = 32.0,
    batch_mass_tolerance_pct: float = 3.0,
    seed: int | None = None,
) -> MonteCarloResult:
    if n_runs <= 0:
        raise ValueError("n_runs must be positive")
    rng = np.random.default_rng(seed)

    target_strength_mpa = target_strength_mpa or mix.inputs.target_strength_mpa
    min_slump_mm = min_slump_mm if min_slump_mm is not None else max(0.0, mix.inputs.slump_mm - 25.0)
    max_slump_mm = max_slump_mm if max_slump_mm is not None else mix.inputs.slump_mm + 25.0
    wcm_limit = wcm_limit or mix.wcm_ratio * 1.15

    water_err = rng.normal(0, config.water_dosing_error_std_pct / 100.0, n_runs)
    cement_err = rng.normal(0, config.cement_dosing_error_std_pct / 100.0, n_runs)
    strength_mult = np.clip(rng.normal(1.0, config.cement_strength_cov, n_runs), 0.3, 1.8)
    temperature = rng.normal(mix.inputs.concrete_temperature_c, config.temperature_std_c, n_runs)
    transport_time = np.clip(rng.normal(config.transport_time_mean_min, config.transport_time_std_min, n_runs), 0, None)
    scale_error = rng.normal(0, config.batch_scale_error_std_pct / 100.0, n_runs)

    water_actual = mix.water_kg * (1 + water_err)
    binder_target = mix.cement_kg + mix.scm_kg
    binder_actual = binder_target * (1 + cement_err)
    wcm_actual = np.where(binder_actual > 0, water_actual / binder_actual, mix.wcm_ratio)

    strengths = strength_for_wcm(wcm_actual) * strength_mult

    initial_slumps = np.array([
        estimate_initial_slump_mm(
            water_kg_m3=float(w), cement_kg_m3=float(binder_actual[i]), wcm=float(wcm_actual[i]),
            temperature_c=float(temperature[i]),
        ).slump_mm
        for i, w in enumerate(water_actual)
    ])
    arrival_slumps = slump_loss_over_time(initial_slumps, transport_time, temperature_c=float(np.mean(temperature)))

    total_mass_error_pct = np.abs(scale_error) * 100.0

    return MonteCarloResult(
        n_runs=n_runs,
        strength_mean=float(np.mean(strengths)),
        strength_median=float(np.median(strengths)),
        strength_std=float(np.std(strengths)),
        strength_p5=float(np.percentile(strengths, 5)),
        strength_p50=float(np.percentile(strengths, 50)),
        strength_p95=float(np.percentile(strengths, 95)),
        slump_mean=float(np.mean(arrival_slumps)),
        slump_p5=float(np.percentile(arrival_slumps, 5)),
        slump_p95=float(np.percentile(arrival_slumps, 95)),
        prob_strength_below_target=float(np.mean(strengths < target_strength_mpa)),
        prob_slump_below_min=float(np.mean(arrival_slumps < min_slump_mm)),
        prob_slump_above_max=float(np.mean(arrival_slumps > max_slump_mm)),
        prob_wcm_above_limit=float(np.mean(wcm_actual > wcm_limit)),
        prob_temperature_above_limit=float(np.mean(temperature > temperature_limit_c)),
        prob_batch_mass_out_of_tolerance=float(np.mean(total_mass_error_pct > batch_mass_tolerance_pct)),
        raw_strengths=strengths,
        raw_slumps=arrival_slumps,
    )
