"""
simulation.discrete_event
============================

A minimal discrete-event simulation (DES) engine using a heapq priority
queue keyed on SIMULATION time (independent of wall-clock time), modelling
the plant-level event sequence: raw material arrival, batch start/complete,
mixer start/complete, truck arrival/loaded/departure/return, equipment
failure, maintenance, lab test.

This is intentionally a compact from-scratch DES core (no external
dependency) so the event model and its ordering guarantees are fully
auditable.
"""

from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable


class EventType(str, Enum):
    RAW_MATERIAL_ARRIVAL = "raw_material_arrival"
    BATCH_START = "batch_start"
    BATCH_COMPLETE = "batch_complete"
    MIXER_START = "mixer_start"
    MIXER_COMPLETE = "mixer_complete"
    TRUCK_ARRIVAL = "truck_arrival"
    TRUCK_LOADED = "truck_loaded"
    TRUCK_DEPARTURE = "truck_departure"
    TRUCK_RETURN = "truck_return"
    EQUIPMENT_FAILURE = "equipment_failure"
    MAINTENANCE = "maintenance"
    LAB_TEST = "lab_test"


@dataclass(order=True)
class _QueuedEvent:
    sim_time: float
    seq: int
    event_type: EventType = field(compare=False)
    payload: dict = field(compare=False, default_factory=dict)


@dataclass
class EventLogEntry:
    sim_time: float
    event_type: EventType
    payload: dict


class DiscreteEventSimulation:
    """Simulation clock + event queue + handler dispatch. `sim_time` is a
    dimensionless simulation-time value (interpret consistently, e.g.
    minutes-since-shift-start); it is NOT tied to wall-clock time."""

    def __init__(self) -> None:
        self._queue: list[_QueuedEvent] = []
        self._counter = itertools.count()
        self.sim_time: float = 0.0
        self.log: list[EventLogEntry] = []
        self._handlers: dict[EventType, list[Callable[["DiscreteEventSimulation", dict], None]]] = {}

    def on(self, event_type: EventType, handler: Callable[["DiscreteEventSimulation", dict], None]) -> None:
        self._handlers.setdefault(event_type, []).append(handler)

    def schedule(self, delay: float, event_type: EventType, payload: dict | None = None) -> None:
        if delay < 0:
            raise ValueError("delay cannot be negative")
        heapq.heappush(self._queue, _QueuedEvent(self.sim_time + delay, next(self._counter), event_type, payload or {}))

    def schedule_at(self, sim_time: float, event_type: EventType, payload: dict | None = None) -> None:
        if sim_time < self.sim_time:
            raise ValueError(f"cannot schedule an event at {sim_time} before current sim_time {self.sim_time}")
        heapq.heappush(self._queue, _QueuedEvent(sim_time, next(self._counter), event_type, payload or {}))

    def run(self, until: float | None = None, max_events: int | None = None) -> None:
        events_processed = 0
        while self._queue:
            if until is not None and self._queue[0].sim_time > until:
                break
            if max_events is not None and events_processed >= max_events:
                break
            event = heapq.heappop(self._queue)
            self.sim_time = event.sim_time
            self.log.append(EventLogEntry(self.sim_time, event.event_type, event.payload))
            for handler in self._handlers.get(event.event_type, []):
                handler(self, event.payload)
            events_processed += 1

    def events_of_type(self, event_type: EventType) -> list[EventLogEntry]:
        return [e for e in self.log if e.event_type == event_type]
