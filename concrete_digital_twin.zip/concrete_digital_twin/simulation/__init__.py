"""Simulation engines: Monte Carlo, discrete-event, scenarios."""
