"""FastAPI application exposing the simulator's engines as HTTP endpoints."""
