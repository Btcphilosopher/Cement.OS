"""
api.main
==========

FastAPI application exposing the simulator's engines as HTTP endpoints
(section 58). Run with:

    uvicorn concrete_digital_twin.api.main:app --reload

All numeric results returned by this API are SIMULATED / ESTIMATED design
outputs -- see the top-level package docstring and docs/ASSUMPTIONS.md.
"""

from __future__ import annotations

from fastapi import FastAPI, HTTPException

from ..economics.material_cost import mix_material_cost_per_m3
from ..environment.carbon import mix_carbon_kgco2e_per_m3
from ..mix_design.mix import MixDesignInputs
from ..optimisation.optimizer import RecipeConstraints, search_recipes
from ..reference_plant import PLANT_CAPACITY_M3_H, PLANT_NAME, build_reference_plant
from ..simulation.monte_carlo import run_monte_carlo
from ..simulation.scenarios import SCENARIOS
from .schemas import (
    BatchRequest,
    MixDesignRequest,
    MixDesignResponse,
    MonteCarloRequest,
    MonteCarloResponse,
    OptimiseCandidate,
    OptimiseRequest,
    OptimiseResponse,
)

app = FastAPI(
    title="Concrete Digital Twin API",
    description=(
        "Educational / engineering-prototype API for cement & concrete "
        "production simulation. All outputs are SIMULATED or ESTIMATED "
        "and must not be used as certified structural design results."
    ),
    version="0.1.0",
)

_plant = build_reference_plant()


@app.get("/")
def root() -> dict:
    return {"service": "concrete_digital_twin", "plant": PLANT_NAME, "capacity_m3_h": PLANT_CAPACITY_M3_H}


@app.post("/mix-design", response_model=MixDesignResponse)
def mix_design(request: MixDesignRequest) -> MixDesignResponse:
    inputs = MixDesignInputs(**request.model_dump())
    try:
        result = _plant.engine.design(inputs)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return MixDesignResponse(
        water_kg=result.water_kg, cement_kg=result.cement_kg, scm_kg=result.scm_kg,
        fine_aggregate_kg=result.fine_aggregate_kg, coarse_aggregate_kg=result.coarse_aggregate_kg,
        admixture_kg=result.admixture_kg, air_content_pct=result.air_content_pct,
        total_mass_kg=result.total_mass_kg, yield_m3=result.yield_m3, density_kg_m3=result.density_kg_m3,
        wcm_ratio=result.wcm_ratio, predicted_28d_strength_mpa=result.predicted_28d_strength_mpa,
        notes=result.notes,
    )


@app.post("/optimise", response_model=OptimiseResponse)
def optimise(request: OptimiseRequest) -> OptimiseResponse:
    base_inputs = MixDesignInputs(
        target_strength_mpa=request.target_strength_mpa, slump_mm=request.slump_mm,
        max_agg_size_mm=request.max_agg_size_mm,
    )
    constraints = RecipeConstraints(
        max_cost_per_m3=request.max_cost_per_m3, max_carbon_kgco2e_per_m3=request.max_carbon_kgco2e_per_m3,
    )
    report = search_recipes(_plant.engine, base_inputs, constraints, n_candidates=request.n_candidates)
    return OptimiseResponse(
        n_generated=report.n_generated, n_feasible=report.n_feasible,
        top_10=[
            OptimiseCandidate(
                scm_fraction=c["scm_fraction"], wcm_ratio=c["wcm_ratio"], strength_mpa=c["strength_mpa"],
                cost_per_m3=c["cost_per_m3"], carbon_kgco2e_per_m3=c["carbon_kgco2e_per_m3"], cement_kg_m3=c["cement_kg_m3"],
            )
            for c in report.top_10
        ],
    )


@app.get("/materials")
def materials() -> dict:
    return {
        "cement": _plant.engine.cement.model_dump(),
        "scm": _plant.engine.scm.model_dump() if _plant.engine.scm else None,
        "fine_aggregate": _plant.engine.fine_aggregate.model_dump(),
        "coarse_aggregate": _plant.engine.coarse_aggregate.model_dump(),
    }


@app.get("/cement")
def cement() -> dict:
    return _plant.engine.cement.model_dump()


@app.get("/aggregates")
def aggregates() -> dict:
    return {
        "fine": _plant.engine.fine_aggregate.model_dump(),
        "coarse": _plant.engine.coarse_aggregate.model_dump(),
    }


@app.post("/batch")
def batch(request: BatchRequest) -> dict:
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    target = _plant.engine.design(base_inputs)
    record = _plant.batch_plant.batch(request.batch_id, request.mix_id, target, request.volume_m3)
    return {
        "batch_id": record.batch_id,
        "accuracy_report": record.accuracy_report(),
        "shortages": record.shortages,
        "water_added_kg": record.water_added_kg,
    }


@app.get("/plant")
def plant() -> dict:
    return {
        "name": PLANT_NAME,
        "capacity_m3_h": PLANT_CAPACITY_M3_H,
        "cement_silo_level_pct": _plant.batch_plant.cement_silo.level_pct,
        "fine_stockpile_level_pct": _plant.batch_plant.fine_agg_stockpile.level_pct,
        "coarse_stockpile_level_pct": _plant.batch_plant.coarse_agg_stockpile.level_pct,
        "fleet_size": len(_plant.fleet.trucks),
        "fleet_utilisation_pct": _plant.fleet.fleet_utilisation_pct(),
    }


@app.get("/production")
def production() -> dict:
    return {"capacity_m3_h": PLANT_CAPACITY_M3_H, "mixer_capacity_m3": _plant.mixer.capacity}


@app.post("/quality/monte-carlo", response_model=MonteCarloResponse)
def quality_monte_carlo(request: MonteCarloRequest) -> MonteCarloResponse:
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    result = _plant.engine.design(base_inputs)
    mc = run_monte_carlo(result, n_runs=request.n_runs, target_strength_mpa=request.target_strength_mpa)
    return MonteCarloResponse(
        n_runs=mc.n_runs, strength_mean=mc.strength_mean, strength_p5=mc.strength_p5, strength_p95=mc.strength_p95,
        prob_strength_below_target=mc.prob_strength_below_target, prob_slump_below_min=mc.prob_slump_below_min,
        prob_slump_above_max=mc.prob_slump_above_max,
    )


@app.get("/carbon")
def carbon() -> dict:
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    result = _plant.engine.design(base_inputs)
    return {"carbon_kgco2e_per_m3": mix_carbon_kgco2e_per_m3(result, _plant.engine)}


@app.get("/economics")
def economics() -> dict:
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    result = _plant.engine.design(base_inputs)
    return {"cost_per_m3": mix_material_cost_per_m3(result, _plant.engine)}


@app.get("/scenarios")
def scenarios() -> dict:
    return {name.value: s.description for name, s in SCENARIOS.items()}


@app.get("/simulation/scenarios/{scenario_name}")
def simulation_scenario(scenario_name: str) -> dict:
    for name, s in SCENARIOS.items():
        if name.value == scenario_name:
            return {"name": s.name.value, "description": s.description, "overrides": s.overrides}
    raise HTTPException(status_code=404, detail=f"unknown scenario '{scenario_name}'")
