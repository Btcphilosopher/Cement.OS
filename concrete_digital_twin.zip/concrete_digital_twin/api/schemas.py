"""
api.schemas
=============

Pydantic request/response schemas for the FastAPI layer, with explicit
validation (section 60): reject negative masses, impossible densities,
invalid units/temperatures/moisture/production, invalid mix ratios.
"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from ..mix_design.cement import ExposureClass


class MixDesignRequest(BaseModel):
    target_strength_mpa: float = Field(..., gt=0, le=120)
    slump_mm: float = Field(..., ge=0, le=300)
    exposure: ExposureClass = ExposureClass.XC_CARBONATION
    max_agg_size_mm: float = Field(20.0, gt=0, le=63)
    target_air_content_pct: float = Field(2.0, ge=0, le=10)
    scm_fraction_of_binder: float = Field(0.0, ge=0, le=0.7)
    concrete_temperature_c: float = Field(20.0, ge=-10, le=50)

    @field_validator("target_strength_mpa")
    @classmethod
    def _strength_plausible(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("target_strength_mpa must be positive")
        return v


class MixDesignResponse(BaseModel):
    water_kg: float
    cement_kg: float
    scm_kg: float
    fine_aggregate_kg: float
    coarse_aggregate_kg: float
    admixture_kg: float
    air_content_pct: float
    total_mass_kg: float
    yield_m3: float
    density_kg_m3: float
    wcm_ratio: float
    predicted_28d_strength_mpa: float
    notes: list[str]
    data_provenance: str = "SIMULATED"


class OptimiseRequest(BaseModel):
    target_strength_mpa: float = Field(..., gt=0, le=120)
    slump_mm: float = Field(..., ge=0, le=300)
    max_agg_size_mm: float = Field(20.0, gt=0, le=63)
    max_carbon_kgco2e_per_m3: float | None = Field(None, ge=0)
    max_cost_per_m3: float | None = Field(None, ge=0)
    n_candidates: int = Field(2000, ge=10, le=200000)


class OptimiseCandidate(BaseModel):
    scm_fraction: float
    wcm_ratio: float
    strength_mpa: float
    cost_per_m3: float
    carbon_kgco2e_per_m3: float
    cement_kg_m3: float


class OptimiseResponse(BaseModel):
    n_generated: int
    n_feasible: int
    top_10: list[OptimiseCandidate]


class BatchRequest(BaseModel):
    batch_id: str
    mix_id: str
    volume_m3: float = Field(..., gt=0, le=12)


class MonteCarloRequest(BaseModel):
    n_runs: int = Field(10000, ge=100, le=200000)
    target_strength_mpa: float | None = Field(None, gt=0)


class MonteCarloResponse(BaseModel):
    n_runs: int
    strength_mean: float
    strength_p5: float
    strength_p95: float
    prob_strength_below_target: float
    prob_slump_below_min: float
    prob_slump_above_max: float
    disclaimer: str = "PROBABILISTIC SIMULATION — not a guarantee of field performance."
