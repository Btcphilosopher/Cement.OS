"""
api.db
========

SQLAlchemy 2.0 ORM models + engine/session factory (section 59). Defaults
to a local SQLite file; pass a PostgreSQL URL (e.g.
``postgresql+psycopg2://user:pass@host/dbname``) to `get_engine` to run
against Postgres instead -- the schema is identical either way.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker


class Base(DeclarativeBase):
    pass


class MaterialRecord(Base):
    __tablename__ = "materials"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    category: Mapped[str] = mapped_column(String(50))  # cement, scm, aggregate, admixture
    cost_per_tonne: Mapped[float] = mapped_column(Float)
    embodied_carbon_kgco2e_per_tonne: Mapped[float] = mapped_column(Float)
    data_provenance: Mapped[str] = mapped_column(String(40))
    properties_json: Mapped[str] = mapped_column(String, default="{}")


class RecipeRecord(Base):
    __tablename__ = "recipes"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mix_id: Mapped[str] = mapped_column(String(50), unique=True)
    target_strength_mpa: Mapped[float] = mapped_column(Float)
    slump_mm: Mapped[float] = mapped_column(Float)
    cement_kg_m3: Mapped[float] = mapped_column(Float)
    scm_kg_m3: Mapped[float] = mapped_column(Float)
    water_kg_m3: Mapped[float] = mapped_column(Float)
    fine_aggregate_kg_m3: Mapped[float] = mapped_column(Float)
    coarse_aggregate_kg_m3: Mapped[float] = mapped_column(Float)
    admixture_kg_m3: Mapped[float] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    batches: Mapped[list["BatchRecordDB"]] = relationship(back_populates="recipe")


class BatchRecordDB(Base):
    __tablename__ = "batches"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_id: Mapped[str] = mapped_column(String(50), unique=True)
    recipe_id: Mapped[int] = mapped_column(ForeignKey("recipes.id"))
    volume_m3: Mapped[float] = mapped_column(Float)
    batch_time: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    within_tolerance: Mapped[bool] = mapped_column(Boolean, default=True)

    recipe: Mapped[RecipeRecord] = relationship(back_populates="batches")
    quality_tests: Mapped[list["QualityTestRecord"]] = relationship(back_populates="batch")


class ProductionRecord(Base):
    __tablename__ = "production"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[datetime] = mapped_column(DateTime)
    volume_m3: Mapped[float] = mapped_column(Float)
    cement_tonnes: Mapped[float] = mapped_column(Float)
    energy_kwh: Mapped[float] = mapped_column(Float)
    carbon_kgco2e: Mapped[float] = mapped_column(Float)
    cost: Mapped[float] = mapped_column(Float)


class EquipmentRecord(Base):
    __tablename__ = "equipment"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    equipment_type: Mapped[str] = mapped_column(String(50))
    condition: Mapped[float] = mapped_column(Float, default=1.0)
    mtbf_hours: Mapped[float] = mapped_column(Float)
    mttr_hours: Mapped[float] = mapped_column(Float)
    last_maintenance: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class MeasurementRecord(Base):
    __tablename__ = "measurements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime)
    asset: Mapped[str] = mapped_column(String(100))
    measurement: Mapped[str] = mapped_column(String(100))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(30))
    quality: Mapped[str] = mapped_column(String(20))
    source: Mapped[str] = mapped_column(String(100))


class QualityTestRecord(Base):
    __tablename__ = "quality_tests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("batches.id"))
    test_type: Mapped[str] = mapped_column(String(50))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(20))
    passed: Mapped[bool] = mapped_column(Boolean)
    tested_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    batch: Mapped[BatchRecordDB] = relationship(back_populates="quality_tests")


class TruckRecord(Base):
    __tablename__ = "trucks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    truck_id: Mapped[str] = mapped_column(String(30), unique=True)
    capacity_m3: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(30))


class OrderRecord(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[str] = mapped_column(String(30), unique=True)
    customer: Mapped[str] = mapped_column(String(200))
    mix_id: Mapped[str] = mapped_column(String(50))
    volume_m3: Mapped[float] = mapped_column(Float)
    requested_time: Mapped[datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(30), default="pending")


class InventoryRecord(Base):
    __tablename__ = "inventory"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    material_name: Mapped[str] = mapped_column(String(100))
    level_kg: Mapped[float] = mapped_column(Float)
    min_stock_kg: Mapped[float] = mapped_column(Float)
    target_stock_kg: Mapped[float] = mapped_column(Float)
    max_stock_kg: Mapped[float] = mapped_column(Float)
    reorder_level_kg: Mapped[float] = mapped_column(Float)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class EnergyRecord(Base):
    __tablename__ = "energy"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[datetime] = mapped_column(DateTime)
    electricity_kwh: Mapped[float] = mapped_column(Float)
    fuel_mj: Mapped[float] = mapped_column(Float)


class CarbonRecord(Base):
    __tablename__ = "carbon"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[datetime] = mapped_column(DateTime)
    kgco2e_per_tonne_clinker: Mapped[float] = mapped_column(Float)
    kgco2e_per_tonne_cement: Mapped[float] = mapped_column(Float)
    kgco2e_per_m3_concrete: Mapped[float] = mapped_column(Float)


class CostRecord(Base):
    __tablename__ = "costs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[datetime] = mapped_column(DateTime)
    cost_per_m3: Mapped[float] = mapped_column(Float)
    cost_per_tonne_cement: Mapped[float] = mapped_column(Float)


class SimulationRunRecord(Base):
    __tablename__ = "simulation_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(String(50), unique=True)
    random_seed: Mapped[int | None] = mapped_column(Integer, nullable=True)
    model_version: Mapped[str] = mapped_column(String(30))
    material_db_version: Mapped[str] = mapped_column(String(30))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    configuration_json: Mapped[str] = mapped_column(String, default="{}")


class OptimisationResultRecord(Base):
    __tablename__ = "optimisation_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    run_id: Mapped[str] = mapped_column(String(50))
    rank: Mapped[int] = mapped_column(Integer)
    cost_per_m3: Mapped[float] = mapped_column(Float)
    carbon_kgco2e_per_m3: Mapped[float] = mapped_column(Float)
    strength_mpa: Mapped[float] = mapped_column(Float)
    scm_fraction: Mapped[float] = mapped_column(Float)


def get_engine(url: str = "sqlite:///concrete_digital_twin.db"):
    return create_engine(url, echo=False)


def init_db(url: str = "sqlite:///concrete_digital_twin.db"):
    engine = get_engine(url)
    Base.metadata.create_all(engine)
    return engine


def get_session_factory(engine) -> sessionmaker:
    return sessionmaker(bind=engine, expire_on_commit=False)
