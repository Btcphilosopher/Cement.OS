"""
curing.strength
==================

ESTIMATED strength-development-vs-age model, in the style of the
CEB-FIP/ACI 209 exponential maturity model:

    fc(t) = fc28 * exp( s * (1 - sqrt(28 / t)) )

where `s` depends on cement type/strength class (rapid-hardening cements
have lower `s`, i.e. gain strength faster at early ages). All outputs are
clearly a SIMULATION -- they must be validated against real cylinder/cube
break data before being used for any construction decision.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np

STANDARD_AGES_DAYS = (1, 3, 7, 28, 56, 90)


class CementSpeedClass(str, Enum):
    RAPID_HARDENING = "rapid_hardening"   # s ~ 0.20
    NORMAL = "normal"                       # s ~ 0.25
    SLOW_HARDENING = "slow_hardening"     # s ~ 0.38 (high SCM content, etc.)


_S_COEFFICIENTS = {
    CementSpeedClass.RAPID_HARDENING: 0.20,
    CementSpeedClass.NORMAL: 0.25,
    CementSpeedClass.SLOW_HARDENING: 0.38,
}


def strength_at_age(age_days: np.ndarray | float, fc28_mpa: float, speed_class: CementSpeedClass = CementSpeedClass.NORMAL, s_override: float | None = None) -> np.ndarray | float:
    if fc28_mpa <= 0:
        raise ValueError("fc28_mpa must be positive")
    s = s_override if s_override is not None else _S_COEFFICIENTS[speed_class]
    age = np.asarray(age_days, dtype=float)
    if np.any(age <= 0):
        raise ValueError("age_days must be positive")
    return fc28_mpa * np.exp(s * (1.0 - np.sqrt(28.0 / age)))


@dataclass
class StrengthCurve:
    ages_days: list[float]
    strengths_mpa: list[float]
    fc28_mpa: float
    speed_class: CementSpeedClass


def strength_development_curve(fc28_mpa: float, speed_class: CementSpeedClass = CementSpeedClass.NORMAL, ages_days: tuple[float, ...] = STANDARD_AGES_DAYS) -> StrengthCurve:
    strengths = strength_at_age(np.array(ages_days, dtype=float), fc28_mpa, speed_class)
    return StrengthCurve(
        ages_days=list(ages_days),
        strengths_mpa=[float(x) for x in np.atleast_1d(strengths)],
        fc28_mpa=fc28_mpa,
        speed_class=speed_class,
    )


def maturity_adjusted_strength(equivalent_age_hours: np.ndarray, fc28_mpa: float, speed_class: CementSpeedClass = CementSpeedClass.NORMAL) -> np.ndarray:
    """Same exponential model but driven by Arrhenius equivalent age
    (hours, from curing.maturity.equivalent_age_hours) instead of real
    (calendar) age, so curing temperature history is reflected."""
    te_days = np.asarray(equivalent_age_hours, dtype=float) / 24.0
    te_days_safe = np.where(te_days <= 0, 1e-3, te_days)
    return strength_at_age(te_days_safe, fc28_mpa, speed_class)
