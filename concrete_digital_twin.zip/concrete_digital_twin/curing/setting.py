"""
curing.setting
=================

ESTIMATED initial/final set time model (Vicat-style, NOT a certified
construction prediction), driven by w/cm, cement type/reactivity,
temperature, SCM content and admixture set-time shift.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SettingEstimate:
    initial_set_minutes: float
    final_set_minutes: float

    @property
    def setting_window_minutes(self) -> float:
        return self.final_set_minutes - self.initial_set_minutes


def estimate_setting_times(
    wcm: float,
    cement_reactivity_index: float = 1.0,
    temperature_c: float = 20.0,
    scm_fraction: float = 0.0,
    admixture_set_shift_minutes: float = 0.0,
) -> SettingEstimate:
    """ESTIMATED setting model:

    * Baseline initial set ~ 150 min, final set ~ 240 min at 20C for a
      w/cm=0.5 reference OPC paste (illustrative baseline).
    * Higher w/cm -> slightly longer set (more water to consume).
    * Higher cement reactivity -> faster set.
    * Higher temperature -> faster set (roughly halves every +10C, a
      common simplification consistent with slump-loss temperature
      sensitivity).
    * SCM (being generally less reactive early) delays set somewhat.
    * Admixture set-time shift is applied directly (negative = accelerator).
    """
    if wcm <= 0 or cement_reactivity_index <= 0:
        raise ValueError("wcm and cement_reactivity_index must be positive")
    if not (0.0 <= scm_fraction <= 1.0):
        raise ValueError("scm_fraction must be within [0,1]")

    base_initial = 150.0
    base_final = 240.0

    wcm_factor = 1.0 + (wcm - 0.5) * 0.6
    reactivity_factor = 1.0 / cement_reactivity_index
    temp_factor = 2.0 ** ((20.0 - temperature_c) / 10.0)
    scm_factor = 1.0 + scm_fraction * 0.5

    multiplier = wcm_factor * reactivity_factor * temp_factor * scm_factor

    initial_set = base_initial * multiplier + admixture_set_shift_minutes
    final_set = base_final * multiplier + admixture_set_shift_minutes

    initial_set = max(20.0, initial_set)
    final_set = max(initial_set + 30.0, final_set)

    return SettingEstimate(initial_set_minutes=initial_set, final_set_minutes=final_set)
