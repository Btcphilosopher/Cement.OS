"""
curing.maturity
==================

Nurse-Saul temperature-time-factor maturity, and Arrhenius equivalent age
-- the standard concrete-industry maturity methods (ASTM C1074-style),
used here to drive strength/hydration estimates from a temperature
history.
"""

from __future__ import annotations

import numpy as np

GAS_CONSTANT_J_PER_MOL_K = 8.314


def nurse_saul_maturity_c_hours(temp_c_history: np.ndarray, time_hours: np.ndarray, datum_temp_c: float = -10.0) -> np.ndarray:
    """M(t) = sum[(T_avg - T0) * dt], the classic Nurse-Saul temperature-time
    factor (deg C . hours), integrated via the trapezoidal rule."""
    temp = np.asarray(temp_c_history, dtype=float)
    t = np.asarray(time_hours, dtype=float)
    if temp.shape != t.shape:
        raise ValueError("temp_c_history and time_hours must be the same shape")
    integrand = np.maximum(0.0, temp - datum_temp_c)
    maturity = np.concatenate(([0.0], np.cumsum(
        0.5 * (integrand[1:] + integrand[:-1]) * np.diff(t)
    )))
    return maturity


def equivalent_age_hours(
    temp_c_history: np.ndarray,
    time_hours: np.ndarray,
    activation_energy_j_per_mol: float = 40000.0,
    reference_temp_c: float = 20.0,
) -> np.ndarray:
    """Arrhenius equivalent age at the reference temperature:

        te = sum[ exp( -Ea/R * (1/T - 1/Tr) ) * dt ]

    with T, Tr in Kelvin. Ea ~ 40 kJ/mol is a widely-used default for OPC
    (ASTM C1074 typically 40-45 kJ/mol depending on cement type/SCM)."""
    temp_k = np.asarray(temp_c_history, dtype=float) + 273.15
    t = np.asarray(time_hours, dtype=float)
    tr_k = reference_temp_c + 273.15
    if temp_k.shape != t.shape:
        raise ValueError("temp_c_history and time_hours must be the same shape")

    rate_factor = np.exp(-activation_energy_j_per_mol / GAS_CONSTANT_J_PER_MOL_K * (1.0 / temp_k - 1.0 / tr_k))
    te = np.concatenate(([0.0], np.cumsum(
        0.5 * (rate_factor[1:] + rate_factor[:-1]) * np.diff(t)
    )))
    return te


def estimated_strength_from_maturity(maturity_c_hours: np.ndarray, a: float, b: float) -> np.ndarray:
    """Generic maturity-strength calibration curve: S = a * ln(M) - b
    (Plowman-type maturity-strength relationship). `a`, `b` must be
    calibrated against real trial-mix maturity/strength pairs for a given
    mix -- defaults are NOT provided here deliberately, since this
    relationship is highly mix-specific."""
    m = np.asarray(maturity_c_hours, dtype=float)
    m_safe = np.where(m <= 1.0, 1.0, m)
    return a * np.log(m_safe) - b
