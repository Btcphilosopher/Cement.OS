"""
curing.slump
==============

SIMPLIFIED, configurable slump model with slump-loss over time (during
transport/agitation) driven by w/cm, admixture, temperature and elapsed
time. Includes an uncertainty band -- this is an ESTIMATE, not a
certified field-slump prediction.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SlumpEstimate:
    slump_mm: float
    uncertainty_mm: float

    @property
    def lower_bound_mm(self) -> float:
        return max(0.0, self.slump_mm - self.uncertainty_mm)

    @property
    def upper_bound_mm(self) -> float:
        return self.slump_mm + self.uncertainty_mm


def estimate_initial_slump_mm(
    water_kg_m3: float,
    cement_kg_m3: float,
    wcm: float,
    admixture_water_reduction_pct: float = 0.0,
    superplasticizer_dosage_pct: float = 0.0,
    temperature_c: float = 20.0,
) -> SlumpEstimate:
    """ESTIMATED as-batched slump. Baseline scales with free water content
    and w/cm; superplasticizer dosage adds a slump boost; higher
    temperature reduces workability slightly at the point of test."""
    if water_kg_m3 <= 0 or cement_kg_m3 <= 0:
        raise ValueError("water_kg_m3 and cement_kg_m3 must be positive")

    baseline = 40.0 + (wcm - 0.45) * 200.0
    admixture_boost = superplasticizer_dosage_pct * 40.0  # mm per % dosage, SIMULATED
    temp_penalty = max(0.0, temperature_c - 20.0) * 1.0

    slump = baseline + admixture_boost - temp_penalty
    slump = max(0.0, min(280.0, slump))
    uncertainty = 15.0 + 0.1 * slump  # SIMULATED heteroscedastic uncertainty
    return SlumpEstimate(slump_mm=slump, uncertainty_mm=uncertainty)


def slump_loss_over_time(
    initial_slump_mm: float,
    time_minutes: np.ndarray,
    temperature_c: float = 20.0,
    retarder_shift_minutes: float = 0.0,
    loss_rate_mm_per_min_at_20c: float = 0.35,
) -> np.ndarray:
    """ESTIMATED slump-vs-time curve during transport/agitation.

    Loss rate increases with temperature (Q10-style doubling per 10C
    above 20C, a common simplification) and is delayed by any retarder
    set-time shift.
    """
    t = np.asarray(time_minutes, dtype=float)
    if np.any(t < 0):
        raise ValueError("time_minutes cannot be negative")

    effective_time = np.maximum(0.0, t - max(0.0, retarder_shift_minutes) * 0.5)
    temp_factor = 2.0 ** ((temperature_c - 20.0) / 10.0)
    rate = loss_rate_mm_per_min_at_20c * temp_factor

    slump = initial_slump_mm - rate * effective_time
    return np.maximum(0.0, slump)
