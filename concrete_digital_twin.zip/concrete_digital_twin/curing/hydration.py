"""
curing.hydration
===================

SIMPLIFIED lumped hydration-kinetics model (NOT a particle-scale or
thermodynamic hydration model). Uses a widely-used exponential
degree-of-hydration formulation (in the style of Freiesleben Hansen &
Pedersen / Schindler & Folliard) driven by equivalent age, with
configurable kinetic parameters (tau, beta) and an ultimate degree of
hydration estimated from w/cm via a Powers'-type relationship.

    alpha(te) = alpha_u * exp( -(tau / te) ** beta )

where te is equivalent age in hours (see curing.maturity for the
Arrhenius equivalent-age calculation that should feed this function).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.chemistry import ClinkerPhases, ultimate_heat_of_hydration_j_per_g_cement


@dataclass(frozen=True)
class HydrationKineticParams:
    tau_hours: float = 15.0   # characteristic time constant
    beta: float = 0.9         # curve-shape parameter


def ultimate_degree_of_hydration(wcm: float) -> float:
    """Powers'-type approximation: alpha_u ~= wcm / (0.36 + wcm), capped at 1.
    (Reflects that cement can only fully hydrate if enough water is present
    to fill the capillary/gel pore system; a simplification widely used for
    teaching purposes.)"""
    if wcm <= 0:
        raise ValueError("wcm must be positive")
    return min(1.0, wcm / (0.36 + wcm))


def degree_of_hydration(equivalent_age_hours: np.ndarray | float, wcm: float, params: HydrationKineticParams = HydrationKineticParams()) -> np.ndarray | float:
    te = np.asarray(equivalent_age_hours, dtype=float)
    te_safe = np.where(te <= 0, 1e-6, te)
    alpha_u = ultimate_degree_of_hydration(wcm)
    alpha = alpha_u * np.exp(-((params.tau_hours / te_safe) ** params.beta))
    result = np.where(te <= 0, 0.0, alpha)
    return float(result) if np.isscalar(equivalent_age_hours) else result


@dataclass
class HydrationHeatProfile:
    time_hours: np.ndarray
    degree_of_hydration: np.ndarray
    cumulative_heat_j_per_g_cement: np.ndarray
    heat_rate_w_per_kg_cement: np.ndarray


def hydration_heat_profile(
    time_hours: np.ndarray,
    wcm: float,
    phases: ClinkerPhases,
    clinker_factor: float = 0.95,
    params: HydrationKineticParams = HydrationKineticParams(),
) -> HydrationHeatProfile:
    """Compute degree of hydration, cumulative heat (J/g cement) and heat
    generation rate (W/kg cement) over a time series (assumed to already be
    in EQUIVALENT AGE hours, i.e. temperature-corrected -- see
    curing.maturity.equivalent_age_hours)."""
    t = np.asarray(time_hours, dtype=float)
    if np.any(t < 0):
        raise ValueError("time_hours cannot contain negative values")

    alpha = degree_of_hydration(t, wcm, params)
    hu = ultimate_heat_of_hydration_j_per_g_cement(phases, clinker_factor)  # J/g cement, alpha=1
    cumulative_heat = hu * alpha  # J/g cement

    # Heat rate via analytic derivative of the alpha(te) function times Hu,
    # converted to W/kg cement (J/g == kJ/kg, so *1000/3600 -> W/kg... careful with units)
    te_safe = np.where(t <= 0, 1e-6, t)
    alpha_u = ultimate_degree_of_hydration(wcm)
    dalpha_dte = alpha_u * np.exp(-((params.tau_hours / te_safe) ** params.beta)) * (
        params.beta * (params.tau_hours ** params.beta) / (te_safe ** (params.beta + 1))
    )
    # dQ/dt in J/(g cement . hour) -> convert to W/kg cement: (J/g/h) * (1000 g/kg) / (3600 s/h)
    heat_rate_j_per_g_per_h = hu * dalpha_dte
    heat_rate_w_per_kg = heat_rate_j_per_g_per_h * 1000.0 / 3600.0

    return HydrationHeatProfile(
        time_hours=t,
        degree_of_hydration=alpha,
        cumulative_heat_j_per_g_cement=cumulative_heat,
        heat_rate_w_per_kg_cement=heat_rate_w_per_kg,
    )
