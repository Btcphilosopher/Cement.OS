"""Curing: hydration, temperature, strength development, maturity, slump loss, setting."""
