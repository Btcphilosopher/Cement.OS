"""
curing.temperature
=====================

Semi-adiabatic curing temperature simulation: integrates hydration heat
generation (curing.hydration) against heat loss to ambient (Newton
cooling) for several curing regimes (ambient, water, sealed, heated, cold
weather, hot weather).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np

from ..core.chemistry import ClinkerPhases
from ..core.thermodynamics import SPECIFIC_HEAT_J_PER_KGK
from .hydration import HydrationKineticParams, hydration_heat_profile


class CuringRegime(str, Enum):
    AMBIENT = "ambient"
    WATER = "water"
    SEALED = "sealed"
    HEATED = "heated"
    COLD_WEATHER = "cold_weather"
    HOT_WEATHER = "hot_weather"


# Heat-transfer coefficient multiplier by regime (SIMULATED, relative to a
# 'sealed' baseline -- water curing conducts heat away fastest, sealed
# curing retains the most heat).
_REGIME_HEAT_LOSS_MULTIPLIER = {
    CuringRegime.AMBIENT: 1.0,
    CuringRegime.WATER: 2.2,
    CuringRegime.SEALED: 0.5,
    CuringRegime.HEATED: 0.8,
    CuringRegime.COLD_WEATHER: 1.3,
    CuringRegime.HOT_WEATHER: 0.9,
}

_REGIME_AMBIENT_OFFSET_C = {
    CuringRegime.AMBIENT: 0.0,
    CuringRegime.WATER: 0.0,
    CuringRegime.SEALED: 0.0,
    CuringRegime.HEATED: 15.0,
    CuringRegime.COLD_WEATHER: -15.0,
    CuringRegime.HOT_WEATHER: 12.0,
}


@dataclass
class TemperatureHistory:
    time_hours: np.ndarray
    temperature_c: np.ndarray
    regime: CuringRegime
    degree_of_hydration: np.ndarray


def simulate_curing_temperature(
    time_hours: np.ndarray,
    wcm: float,
    phases: ClinkerPhases,
    cement_content_kg_m3: float,
    clinker_factor: float = 0.95,
    concrete_density_kg_m3: float = 2400.0,
    ambient_temp_c: float = 20.0,
    regime: CuringRegime = CuringRegime.AMBIENT,
    base_heat_loss_coeff_per_hour: float = 0.05,
    params: HydrationKineticParams = HydrationKineticParams(),
) -> TemperatureHistory:
    """Explicit-Euler integration of:

        dT/dt = (heat_generation_rate - heat_loss_rate) / (mass * c_p)

    Uses equivalent-age-driven hydration internally (temperature feeds
    back into hydration rate via the Arrhenius equivalent-age function,
    giving a simple thermal feedback loop -- the essence of a 'digital
    twin' curing simulation).
    """
    t = np.asarray(time_hours, dtype=float)
    if t.ndim != 1 or len(t) < 2:
        raise ValueError("time_hours must be a 1-D array with at least 2 points")

    ambient = ambient_temp_c + _REGIME_AMBIENT_OFFSET_C[regime]
    heat_loss_coeff = base_heat_loss_coeff_per_hour * _REGIME_HEAT_LOSS_MULTIPLIER[regime]

    n = len(t)
    temps = np.zeros(n)
    temps[0] = ambient_temp_c
    equivalent_age = np.zeros(n)
    c_concrete = SPECIFIC_HEAT_J_PER_KGK["concrete"]

    from .maturity import GAS_CONSTANT_J_PER_MOL_K
    ea = 40000.0
    tr_k = 293.15

    for i in range(1, n):
        dt_h = t[i] - t[i - 1]
        temp_k_prev = temps[i - 1] + 273.15
        rate_factor = np.exp(-ea / GAS_CONSTANT_J_PER_MOL_K * (1.0 / temp_k_prev - 1.0 / tr_k))
        equivalent_age[i] = equivalent_age[i - 1] + rate_factor * dt_h

        profile = hydration_heat_profile(np.array([equivalent_age[i - 1], equivalent_age[i]]), wcm, phases, clinker_factor, params)
        d_heat_j_per_g = profile.cumulative_heat_j_per_g_cement[1] - profile.cumulative_heat_j_per_g_cement[0]

        # d_heat_j_per_g is J per gram cement; cement_content_kg_m3 is kg
        # cement per m3 concrete => (J/g) * (kg/m3) * (1000 g/kg) = J/m3 of heat released.
        d_heat_j_per_m3 = d_heat_j_per_g * cement_content_kg_m3 * 1000.0

        heat_capacity_j_per_m3_k = concrete_density_kg_m3 * c_concrete
        d_temp_gen = d_heat_j_per_m3 / heat_capacity_j_per_m3_k

        d_temp_loss = heat_loss_coeff * (temps[i - 1] - ambient) * dt_h

        temps[i] = temps[i - 1] + d_temp_gen - d_temp_loss

    final_profile = hydration_heat_profile(equivalent_age, wcm, phases, clinker_factor, params)

    return TemperatureHistory(
        time_hours=t,
        temperature_c=temps,
        regime=regime,
        degree_of_hydration=final_profile.degree_of_hydration,
    )
