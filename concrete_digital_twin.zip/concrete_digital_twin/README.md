# Concrete Digital Twin

A large-scale, modular Python simulator for **cement production, aggregate
processing, concrete mix design, batching, mixing, transport, curing,
quality control, plant economics, carbon accounting and production
optimisation** — a digital twin of a modern cement/concrete operation.

> **This is an engineering simulation and educational prototype.**
> Outputs are SIMULATED or ESTIMATED — see [`docs/ASSUMPTIONS.md`](docs/ASSUMPTIONS.md).
> Nothing here should be used, on its own, to certify concrete for
> construction.

## What's inside

| Area | Modules |
|---|---|
| Core | units, material models (Pydantic), simplified cement chemistry, thermodynamics, mass balances |
| Cement plant | quarry raw materials → rotary kiln → clinker → cement mill → blending |
| Aggregates | crushing, screening, grading curves, fineness modulus, SSD moisture correction |
| Mix design | absolute-volume-method engine, water/cement/aggregate/admixture models, SciPy-based optimisation |
| Production | virtual batching plant (weigh hoppers, scale error, shortages), mixing, conveyors, truck dispatch |
| Curing | hydration kinetics, semi-adiabatic temperature simulation, strength development, Nurse-Saul/Arrhenius maturity, slump loss, setting time |
| Quality | QC engine, synthetic sampling, SPC (X-bar/R, X-bar/S, I-MR control charts) |
| Plant | silos, mixers, pumps, kilns, storage — with MTBF/MTTR equipment reliability |
| Economics | material/energy/production cost, pricing with margin & volume discounts |
| Environment | carbon (calcination/fuel/electricity/transport), energy intensity, emissions, water balance |
| Optimisation | SciPy constrained optimisation, a from-scratch genetic algorithm, Pareto-frontier multi-objective search |
| Simulation | a from-scratch discrete-event engine, vectorised NumPy Monte Carlo (up to 100k+ runs), named operating scenarios |
| Digital twin | plant-state snapshot, synthetic sensors, SQLite-backed historian |
| Dashboard | Streamlit control centre (production, mix design, optimiser, quality, curing, economics/carbon) |
| API | FastAPI endpoints + SQLAlchemy ORM (SQLite by default, PostgreSQL-compatible) |

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full package
layout and data-flow diagram, and [`docs/QUICKSTART.md`](docs/QUICKSTART.md)
to get running in five minutes.

## Example plant

All examples, the dashboard and the API run against **Northshire Concrete
Works**, an entirely fictional example plant (150 m³/h capacity, 4 m³
mixer, 500 t cement silo, 5,000 t aggregate storage, 30-truck fleet) — see
`reference_plant.py`.

## Quick example

```python
from concrete_digital_twin.reference_plant import build_reference_plant
from concrete_digital_twin.mix_design.mix import MixDesignInputs

plant = build_reference_plant()
result = plant.engine.design(MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.2))
print(result.summary())
```

## Testing

```bash
pip install -r requirements.txt
pytest concrete_digital_twin/tests -q
```

86+ tests, including Hypothesis property-based tests for mass-balance and
mix-mass conservation invariants.

## License / status

Prototype / educational software provided as-is, with no warranty of
fitness for any real construction or process-control purpose. All plant,
company and product names used in examples (e.g. "Northshire Concrete
Works") are fictional.
