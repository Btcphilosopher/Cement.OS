"""production.conveyor — belt conveyor material transport model."""

from __future__ import annotations

from dataclasses import dataclass

from ..plant._equipment_base import Equipment


@dataclass
class Conveyor(Equipment):
    """`capacity` is the rated throughput, kg/h. `length_m` and `speed_m_s`
    determine transit (residence) time on the belt."""

    length_m: float = 50.0
    speed_m_s: float = 1.5

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.length_m <= 0 or self.speed_m_s <= 0:
            raise ValueError("length_m and speed_m_s must be positive")

    @property
    def transit_time_s(self) -> float:
        return self.length_m / self.speed_m_s

    def throughput_kg_h(self, requested_kg_h: float) -> float:
        if requested_kg_h < 0:
            raise ValueError("requested_kg_h cannot be negative")
        if not self.is_operational:
            return 0.0
        max_rate = self.capacity * self.efficiency * (0.5 + 0.5 * self.condition)
        return min(requested_kg_h, max_rate)
