"""
production.mixing
====================

Process-level mixing model: batching -> pre-blend -> mixing ->
homogenisation -> discharge. Tracks mixing time, mixer speed/power,
temperature rise and a simple mix-uniformity index driven by mixing time
relative to a material-dependent minimum.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..plant.mixers import MixerEquipment


@dataclass
class MixingStage:
    name: str
    duration_s: float


DEFAULT_MIXING_SEQUENCE: tuple[MixingStage, ...] = (
    MixingStage("charge_aggregates", 15.0),
    MixingStage("charge_cementitious", 10.0),
    MixingStage("pre_blend_dry", 20.0),
    MixingStage("add_water_and_admixture", 15.0),
    MixingStage("wet_mix", 60.0),
    MixingStage("homogenisation", 30.0),
    MixingStage("discharge", 20.0),
)


@dataclass
class MixingResult:
    total_mixing_time_s: float
    mixer_speed_rpm: float
    power_kw: float
    discharge_temp_c: float
    uniformity_index: float  # 0-1, 1 = perfectly homogeneous
    stage_log: list[MixingStage]


class Mixer:
    """Process-level mixing simulator wrapping a physical MixerEquipment asset."""

    def __init__(self, equipment: MixerEquipment, min_wet_mix_time_s: float = 60.0, rated_speed_rpm: float = 18.0) -> None:
        self.equipment = equipment
        self.min_wet_mix_time_s = min_wet_mix_time_s
        self.rated_speed_rpm = rated_speed_rpm

    def mix(
        self,
        batch_volume_m3: float,
        ambient_temp_c: float = 20.0,
        sequence: tuple[MixingStage, ...] = DEFAULT_MIXING_SEQUENCE,
        speed_rpm: float | None = None,
    ) -> MixingResult:
        if batch_volume_m3 <= 0:
            raise ValueError("batch_volume_m3 must be positive")
        if batch_volume_m3 > self.equipment.capacity:
            raise ValueError(f"batch volume {batch_volume_m3:.2f} m3 exceeds mixer capacity {self.equipment.capacity:.2f} m3")

        speed = speed_rpm or self.rated_speed_rpm
        load_fraction = batch_volume_m3 / self.equipment.capacity
        power_kw = self.equipment.draw_power_kw(load_fraction)

        total_time = sum(s.duration_s for s in sequence)
        wet_mix_time = next((s.duration_s for s in sequence if s.name == "wet_mix"), 0.0)

        # Uniformity rises with wet-mix time relative to the minimum
        # required, saturating asymptotically (SIMULATED).
        ratio = wet_mix_time / self.min_wet_mix_time_s if self.min_wet_mix_time_s > 0 else 1.0
        uniformity = 1.0 - pow(2.71828, -1.6 * ratio)
        uniformity = max(0.0, min(1.0, uniformity)) * (0.7 + 0.3 * self.equipment.condition)

        # Frictional/mechanical heat contributes a small temperature rise
        # during mixing (separate from hydration heat, handled in curing).
        heat_rise_c = power_kw * (total_time / 3600.0) / max(0.5, batch_volume_m3) * 0.15
        discharge_temp_c = ambient_temp_c + heat_rise_c

        self.equipment.complete_batch()

        return MixingResult(
            total_mixing_time_s=total_time,
            mixer_speed_rpm=speed,
            power_kw=power_kw,
            discharge_temp_c=discharge_temp_c,
            uniformity_index=uniformity,
            stage_log=list(sequence),
        )
