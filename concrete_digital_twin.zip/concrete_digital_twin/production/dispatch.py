"""
production.dispatch
======================

Ready-mix truck fleet simulation: truck state machine, transport (distance,
travel time, slump loss, temperature, fuel/CO2), and a simple dispatch
optimiser that assigns pending orders to the nearest available truck.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

import numpy as np

from ..curing.slump import slump_loss_over_time

# Fuel consumption, L diesel per km, loaded ready-mix truck (SIMULATED).
DIESEL_L_PER_KM = 0.45
DIESEL_KGCO2E_PER_L = 2.68


class TruckStatus(str, Enum):
    IDLE = "idle"
    LOADING = "loading"
    EN_ROUTE_TO_SITE = "en_route_to_site"
    AT_SITE = "at_site"
    PLACING = "placing"
    RETURNING = "returning"
    WASHING = "washing"
    OUT_OF_SERVICE = "out_of_service"


@dataclass
class Truck:
    truck_id: str
    capacity_m3: float
    status: TruckStatus = TruckStatus.IDLE
    location_km_from_plant: float = 0.0
    current_mix_id: str | None = None
    current_customer: str | None = None
    departure_time: datetime | None = None
    arrival_time: datetime | None = None
    return_time: datetime | None = None


@dataclass
class DeliveryRecord:
    batch_number: str
    truck_id: str
    mix_id: str
    customer: str
    production_time: datetime
    loading_time_min: float
    departure_time: datetime
    distance_km: float
    average_speed_kmh: float
    travel_time_min: float
    arrival_time: datetime
    placement_time_min: float
    return_time: datetime
    initial_slump_mm: float
    arrival_slump_mm: float
    temperature_at_arrival_c: float
    fuel_l: float
    co2_kgco2e: float
    traffic_delay_min: float = 0.0


def simulate_delivery(
    batch_number: str,
    truck: Truck,
    mix_id: str,
    customer: str,
    production_time: datetime,
    distance_km: float,
    initial_slump_mm: float,
    ambient_temp_c: float = 20.0,
    average_speed_kmh: float = 40.0,
    traffic_delay_min: float = 0.0,
    loading_time_min: float = 8.0,
    placement_time_min: float = 25.0,
    retarder_shift_minutes: float = 0.0,
) -> DeliveryRecord:
    if distance_km < 0:
        raise ValueError("distance_km cannot be negative")
    if truck.status != TruckStatus.IDLE and truck.status != TruckStatus.LOADING:
        raise ValueError(f"truck {truck.truck_id} is not available (status={truck.status})")

    departure_time = production_time + timedelta(minutes=loading_time_min)
    travel_time_min = (distance_km / average_speed_kmh) * 60.0 + traffic_delay_min
    arrival_time = departure_time + timedelta(minutes=travel_time_min)

    total_elapsed_min = loading_time_min + travel_time_min
    arrival_slump = float(slump_loss_over_time(
        initial_slump_mm=initial_slump_mm,
        time_minutes=np.array([total_elapsed_min]),
        temperature_c=ambient_temp_c,
        retarder_shift_minutes=retarder_shift_minutes,
    )[0])

    return_time = arrival_time + timedelta(minutes=placement_time_min) + timedelta(minutes=(distance_km / average_speed_kmh) * 60.0)

    fuel_l = distance_km * 2 * DIESEL_L_PER_KM  # round trip
    co2 = fuel_l * DIESEL_KGCO2E_PER_L

    truck.status = TruckStatus.EN_ROUTE_TO_SITE
    truck.current_mix_id = mix_id
    truck.current_customer = customer
    truck.departure_time = departure_time
    truck.arrival_time = arrival_time
    truck.return_time = return_time
    truck.location_km_from_plant = distance_km

    return DeliveryRecord(
        batch_number=batch_number,
        truck_id=truck.truck_id,
        mix_id=mix_id,
        customer=customer,
        production_time=production_time,
        loading_time_min=loading_time_min,
        departure_time=departure_time,
        distance_km=distance_km,
        average_speed_kmh=average_speed_kmh,
        travel_time_min=travel_time_min,
        arrival_time=arrival_time,
        placement_time_min=placement_time_min,
        return_time=return_time,
        initial_slump_mm=initial_slump_mm,
        arrival_slump_mm=arrival_slump,
        temperature_at_arrival_c=ambient_temp_c,
        fuel_l=fuel_l,
        co2_kgco2e=co2,
        traffic_delay_min=traffic_delay_min,
    )


@dataclass
class Order:
    order_id: str
    customer: str
    mix_id: str
    volume_m3: float
    distance_km: float
    requested_time: datetime


@dataclass
class Fleet:
    trucks: list[Truck] = field(default_factory=list)

    def available_trucks(self, min_capacity_m3: float = 0.0) -> list[Truck]:
        return [t for t in self.trucks if t.status == TruckStatus.IDLE and t.capacity_m3 >= min_capacity_m3]

    def dispatch(self, order: Order) -> Truck | None:
        """Greedy dispatch: assign the smallest idle truck that can still
        cover the order in a single load (minimises unused capacity),
        falling back to the largest available truck if none is big enough
        for a single trip."""
        candidates = self.available_trucks(order.volume_m3)
        if candidates:
            chosen = min(candidates, key=lambda t: t.capacity_m3)
        else:
            idle = self.available_trucks()
            chosen = max(idle, key=lambda t: t.capacity_m3) if idle else None
        if chosen is not None:
            chosen.status = TruckStatus.LOADING
        return chosen

    def return_truck(self, truck_id: str) -> None:
        for t in self.trucks:
            if t.truck_id == truck_id:
                t.status = TruckStatus.IDLE
                t.current_mix_id = None
                t.current_customer = None
                t.location_km_from_plant = 0.0
                return
        raise ValueError(f"unknown truck_id '{truck_id}'")

    def fleet_utilisation_pct(self) -> float:
        if not self.trucks:
            return 0.0
        busy = sum(1 for t in self.trucks if t.status != TruckStatus.IDLE)
        return 100.0 * busy / len(self.trucks)
