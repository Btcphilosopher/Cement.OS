"""
production.batching
======================

Virtual batching plant: weigh hoppers with realistic scale error, moisture
correction (via aggregates.moisture), and material-shortage handling
(drawing from plant.silos.Silo / plant.storage.Stockpile).

Simulates TARGET -> ACTUAL -> ERROR -> CORRECTED for every batch component
(section 19: batch accuracy).
"""

from __future__ import annotations

from dataclasses import dataclass, field
import random

from ..aggregates.moisture import MoistureCorrection, correct_batch_water
from ..core.materials import Aggregate
from ..mix_design.mix import MixDesignResult
from ..plant.silos import Silo
from ..plant.storage import Stockpile


@dataclass
class WeighHopper:
    name: str
    capacity_kg: float
    systematic_error_pct: float = 0.0   # calibration bias, e.g. -0.3% = under-weighs
    random_error_std_pct: float = 0.5   # 1-sigma random scale noise

    def weigh(self, target_kg: float, rng: random.Random | None = None) -> "WeighResult":
        rng = rng or random
        if target_kg < 0:
            raise ValueError("target_kg cannot be negative")
        if target_kg > self.capacity_kg:
            raise ValueError(f"target {target_kg:.1f} kg exceeds hopper capacity {self.capacity_kg:.1f} kg")
        noise_pct = rng.gauss(self.systematic_error_pct, self.random_error_std_pct)
        actual_kg = target_kg * (1.0 + noise_pct / 100.0)
        actual_kg = max(0.0, actual_kg)
        return WeighResult(
            hopper_name=self.name,
            target_kg=target_kg,
            actual_kg=actual_kg,
            error_kg=actual_kg - target_kg,
            error_pct=(noise_pct if target_kg > 0 else 0.0),
        )


@dataclass
class WeighResult:
    hopper_name: str
    target_kg: float
    actual_kg: float
    error_kg: float
    error_pct: float


@dataclass
class BatchRecord:
    batch_id: str
    mix_id: str
    target: MixDesignResult
    weighs: dict[str, WeighResult]
    moisture_corrections: dict[str, MoistureCorrection]
    water_added_kg: float
    shortages: dict[str, float] = field(default_factory=dict)  # material -> shortfall kg

    @property
    def within_tolerance(self, tol_pct: float = 3.0) -> bool:
        return all(abs(w.error_pct) <= tol_pct for w in self.weighs.values())

    def accuracy_report(self) -> list[dict[str, float]]:
        rows = []
        for name, w in self.weighs.items():
            rows.append({
                "component": name,
                "target_kg": w.target_kg,
                "actual_kg": w.actual_kg,
                "error_kg": w.error_kg,
                "error_pct": w.error_pct,
            })
        return rows


class BatchPlant:
    """A batching plant with cement/SCM silos, aggregate stockpiles, water
    supply and weigh hoppers for each material stream."""

    def __init__(
        self,
        cement_silo: Silo,
        fine_agg_stockpile: Stockpile,
        coarse_agg_stockpile: Stockpile,
        fine_aggregate: Aggregate,
        coarse_aggregate: Aggregate,
        scm_silo: Silo | None = None,
        cement_hopper: WeighHopper | None = None,
        aggregate_hopper: WeighHopper | None = None,
        water_hopper: WeighHopper | None = None,
        admixture_hopper: WeighHopper | None = None,
        rng: random.Random | None = None,
    ) -> None:
        self.cement_silo = cement_silo
        self.scm_silo = scm_silo
        self.fine_agg_stockpile = fine_agg_stockpile
        self.coarse_agg_stockpile = coarse_agg_stockpile
        self.fine_aggregate = fine_aggregate
        self.coarse_aggregate = coarse_aggregate
        self.cement_hopper = cement_hopper or WeighHopper("cement_hopper", capacity_kg=2000)
        self.aggregate_hopper = aggregate_hopper or WeighHopper("aggregate_hopper", capacity_kg=8000)
        self.water_hopper = water_hopper or WeighHopper("water_hopper", capacity_kg=1000, random_error_std_pct=0.3)
        self.admixture_hopper = admixture_hopper or WeighHopper("admixture_hopper", capacity_kg=50, random_error_std_pct=1.0)
        self.rng = rng or random.Random()

    def batch(self, batch_id: str, mix_id: str, target: MixDesignResult, volume_m3: float = 1.0) -> BatchRecord:
        if volume_m3 <= 0:
            raise ValueError("volume_m3 must be positive")

        scaled = {
            "cement": target.cement_kg * volume_m3,
            "scm": target.scm_kg * volume_m3,
            "fine_aggregate": target.fine_aggregate_kg * volume_m3,
            "coarse_aggregate": target.coarse_aggregate_kg * volume_m3,
            "water": target.water_kg * volume_m3,
            "admixture": target.admixture_kg * volume_m3,
        }

        shortages: dict[str, float] = {}

        # Silo/stockpile draws (material availability check)
        cement_drawn = self.cement_silo.draw(scaled["cement"])
        if cement_drawn < scaled["cement"]:
            shortages["cement"] = scaled["cement"] - cement_drawn

        if scaled["scm"] > 0 and self.scm_silo is not None:
            scm_drawn = self.scm_silo.draw(scaled["scm"])
            if scm_drawn < scaled["scm"]:
                shortages["scm"] = scaled["scm"] - scm_drawn

        # Moisture correction on aggregates before weighing
        fine_corr = correct_batch_water(self.fine_aggregate, scaled["fine_aggregate"])
        coarse_corr = correct_batch_water(self.coarse_aggregate, scaled["coarse_aggregate"])
        net_water_adjust = (
            (coarse_corr.water_absorbed_by_dry_aggregate_kg - coarse_corr.free_water_contribution_kg)
            + (fine_corr.water_absorbed_by_dry_aggregate_kg - fine_corr.free_water_contribution_kg)
        )
        corrected_water_target = max(0.0, scaled["water"] + net_water_adjust)

        fine_drawn = self.fine_agg_stockpile.remove(fine_corr.batch_mass_as_received_kg)
        if fine_drawn < fine_corr.batch_mass_as_received_kg:
            shortages["fine_aggregate"] = fine_corr.batch_mass_as_received_kg - fine_drawn

        coarse_drawn = self.coarse_agg_stockpile.remove(coarse_corr.batch_mass_as_received_kg)
        if coarse_drawn < coarse_corr.batch_mass_as_received_kg:
            shortages["coarse_aggregate"] = coarse_corr.batch_mass_as_received_kg - coarse_drawn

        # Weigh each stream (target -> actual with scale error)
        weighs: dict[str, WeighResult] = {
            "cement": self.cement_hopper.weigh(scaled["cement"], self.rng),
            "fine_aggregate": self.aggregate_hopper.weigh(fine_corr.batch_mass_as_received_kg, self.rng),
            "coarse_aggregate": self.aggregate_hopper.weigh(coarse_corr.batch_mass_as_received_kg, self.rng),
            "water": self.water_hopper.weigh(corrected_water_target, self.rng),
        }
        if scaled["scm"] > 0:
            weighs["scm"] = self.cement_hopper.weigh(scaled["scm"], self.rng)
        if scaled["admixture"] > 0:
            weighs["admixture"] = self.admixture_hopper.weigh(scaled["admixture"], self.rng)

        return BatchRecord(
            batch_id=batch_id,
            mix_id=mix_id,
            target=target,
            weighs=weighs,
            moisture_corrections={"fine_aggregate": fine_corr, "coarse_aggregate": coarse_corr},
            water_added_kg=weighs["water"].actual_kg,
            shortages=shortages,
        )
