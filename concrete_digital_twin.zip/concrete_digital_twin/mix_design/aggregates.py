"""
mix_design.aggregates
========================

ESTIMATED coarse-aggregate proportioning table (bulk volume of dry-rodded
coarse aggregate per unit volume of concrete, as a function of maximum
aggregate size and fine-aggregate fineness modulus), loosely in the style
of ACI 211.1 Table 6.3.6. Fine aggregate is then proportioned by the
absolute-volume method (the remaining volume after water, cementitious
materials, coarse aggregate and air).
"""

from __future__ import annotations

import numpy as np

# Rows: max aggregate size (mm); columns: fine aggregate FM in {2.4, 2.6, 2.8, 3.0}
_FM_COLUMNS = [2.4, 2.6, 2.8, 3.0]
_BULK_VOLUME_TABLE: dict[float, list[float]] = {
    9.5: [0.50, 0.48, 0.46, 0.44],
    12.5: [0.59, 0.57, 0.55, 0.53],
    19.0: [0.66, 0.64, 0.62, 0.60],
    25.0: [0.71, 0.69, 0.67, 0.65],
    37.5: [0.75, 0.73, 0.71, 0.69],
    50.0: [0.78, 0.76, 0.74, 0.72],
}

_SIZES = np.array(sorted(_BULK_VOLUME_TABLE))


def dry_rodded_bulk_volume_fraction(max_agg_size_mm: float, fine_aggregate_fm: float) -> float:
    """ESTIMATED fraction (0-1) of a cubic metre of concrete occupied by
    coarse aggregate on a dry-rodded bulk-volume basis, bilinearly
    interpolated from the reference table."""
    fm = min(max(fine_aggregate_fm, _FM_COLUMNS[0]), _FM_COLUMNS[-1])
    size = min(max(max_agg_size_mm, _SIZES[0]), _SIZES[-1])

    row_values = np.array([np.interp(size, _SIZES, [_BULK_VOLUME_TABLE[s][i] for s in _SIZES]) for i in range(len(_FM_COLUMNS))])
    return float(np.interp(fm, _FM_COLUMNS, row_values))


def coarse_aggregate_mass_kg_m3(
    max_agg_size_mm: float,
    fine_aggregate_fm: float,
    coarse_dry_rodded_bulk_density_kg_m3: float,
) -> float:
    fraction = dry_rodded_bulk_volume_fraction(max_agg_size_mm, fine_aggregate_fm)
    return fraction * coarse_dry_rodded_bulk_density_kg_m3
