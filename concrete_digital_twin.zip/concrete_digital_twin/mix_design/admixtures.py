"""
mix_design.admixtures
========================

Applies configurable admixture dosing effects (water reduction, air
entrainment, set-time shift) to a mix design, and computes admixture mass
from dosage percentage of total binder.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.materials import Admixture


@dataclass
class AdmixtureDose:
    admixture: Admixture
    dosage_pct_of_binder: float  # overrides admixture.typical_dosage_pct_of_binder if given

    def __post_init__(self) -> None:
        if not (0.0 <= self.dosage_pct_of_binder <= 10.0):
            raise ValueError("dosage_pct_of_binder must be within [0,10]")

    def mass_kg(self, total_binder_kg: float) -> float:
        if total_binder_kg < 0:
            raise ValueError("total_binder_kg cannot be negative")
        return total_binder_kg * (self.dosage_pct_of_binder / 100.0)

    def volume_l(self, total_binder_kg: float) -> float:
        mass = self.mass_kg(total_binder_kg)
        return mass / self.admixture.density_kg_m3 * 1000.0

    def cost(self, total_binder_kg: float) -> float:
        mass_t = self.mass_kg(total_binder_kg) / 1000.0
        return mass_t * self.admixture.cost_per_tonne

    def effective_water_reduction_pct(self) -> float:
        """Scale the admixture's rated water reduction linearly with dose
        relative to its typical dosage (SIMPLIFIED, saturates at rated max)."""
        if self.admixture.typical_dosage_pct_of_binder <= 0:
            return 0.0
        ratio = self.dosage_pct_of_binder / self.admixture.typical_dosage_pct_of_binder
        return min(self.admixture.water_reduction_pct, self.admixture.water_reduction_pct * ratio)

    def effective_set_time_shift_minutes(self) -> float:
        if self.admixture.typical_dosage_pct_of_binder <= 0:
            return 0.0
        ratio = self.dosage_pct_of_binder / self.admixture.typical_dosage_pct_of_binder
        return self.admixture.set_time_shift_minutes * ratio

    def effective_air_entrainment_pct(self) -> float:
        if self.admixture.typical_dosage_pct_of_binder <= 0:
            return 0.0
        ratio = self.dosage_pct_of_binder / self.admixture.typical_dosage_pct_of_binder
        return min(self.admixture.air_entrainment_pct, self.admixture.air_entrainment_pct * ratio)


def combine_doses(doses: list[AdmixtureDose]) -> dict[str, float]:
    """Aggregate effects across multiple simultaneous admixtures (compatibility
    interactions are NOT modelled -- effects are simply summed / capped, which
    is a simplification flagged for advanced-mode extension)."""
    total_water_reduction = sum(d.effective_water_reduction_pct() for d in doses)
    total_set_shift = sum(d.effective_set_time_shift_minutes() for d in doses)
    total_air = sum(d.effective_air_entrainment_pct() for d in doses)
    return {
        "water_reduction_pct": min(40.0, total_water_reduction),
        "set_time_shift_minutes": total_set_shift,
        "air_entrainment_pct": min(10.0, total_air),
    }
