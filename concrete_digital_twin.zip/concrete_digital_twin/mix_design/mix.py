"""
mix_design.mix
================

The concrete mix-design engine: absolute-volume method.

Given target strength/slump/exposure/materials, produces a full recipe
(water, cement, SCM, fine aggregate, coarse aggregate, admixture, air) for
one cubic metre of concrete, with mass balance / volume balance checks.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from ..core.materials import Aggregate, Admixture, Cement, SCM
from .admixtures import AdmixtureDose, combine_doses
from .aggregates import coarse_aggregate_mass_kg_m3
from .cement import ExposureClass, required_cementitious_content_kg_m3, strength_for_wcm, wcm_for_target_strength
from .water import estimate_water_demand_kg_m3
from ..aggregates.grading import fineness_modulus

WATER_DENSITY_KG_M3 = 1000.0
VOLUME_TARGET_M3 = 1.0
VOLUME_TOLERANCE_M3 = 1e-6


class MixDesignInputs(BaseModel):
    target_strength_mpa: float = Field(..., gt=0)
    slump_mm: float = Field(..., ge=0, le=300)
    exposure: ExposureClass = ExposureClass.XC_CARBONATION
    max_agg_size_mm: float = Field(20.0, gt=0)
    target_air_content_pct: float = Field(2.0, ge=0, le=10)
    scm_fraction_of_binder: float = Field(0.0, ge=0, le=0.7)
    wcm_override: float | None = Field(None, gt=0, description="If set, overrides the strength-derived w/cm.")
    concrete_temperature_c: float = Field(20.0, ge=-10, le=50)

    model_config = {"arbitrary_types_allowed": True}


@dataclass
class MixDesignResult:
    inputs: MixDesignInputs
    water_kg: float
    cement_kg: float
    scm_kg: float
    fine_aggregate_kg: float
    coarse_aggregate_kg: float
    admixture_kg: float
    air_content_pct: float
    total_mass_kg: float
    yield_m3: float
    density_kg_m3: float
    wcm_ratio: float
    predicted_28d_strength_mpa: float
    volume_check_m3: float
    notes: list[str] = field(default_factory=list)

    def summary(self) -> dict[str, float]:
        return {
            "water_kg_m3": self.water_kg,
            "cement_kg_m3": self.cement_kg,
            "scm_kg_m3": self.scm_kg,
            "fine_aggregate_kg_m3": self.fine_aggregate_kg,
            "coarse_aggregate_kg_m3": self.coarse_aggregate_kg,
            "admixture_kg_m3": self.admixture_kg,
            "air_content_pct": self.air_content_pct,
            "total_mass_kg_m3": self.total_mass_kg,
            "yield_m3": self.yield_m3,
            "density_kg_m3": self.density_kg_m3,
            "wcm_ratio": self.wcm_ratio,
            "predicted_28d_strength_mpa": self.predicted_28d_strength_mpa,
        }


class MixDesignEngine:
    """Absolute-volume-method concrete mix designer.

    NOTE: all outputs are SIMULATED / ESTIMATED design proportions for one
    cubic metre of concrete. Always validate with laboratory trial batches
    before field use.
    """

    def __init__(
        self,
        cement: Cement,
        fine_aggregate: Aggregate,
        coarse_aggregate: Aggregate,
        scm: SCM | None = None,
        admixture_doses: list[AdmixtureDose] | None = None,
    ) -> None:
        self.cement = cement
        self.fine_aggregate = fine_aggregate
        self.coarse_aggregate = coarse_aggregate
        self.scm = scm
        self.admixture_doses = admixture_doses or []

    def design(self, inputs: MixDesignInputs) -> MixDesignResult:
        notes: list[str] = []

        combined_admix = combine_doses(self.admixture_doses) if self.admixture_doses else {
            "water_reduction_pct": 0.0,
            "set_time_shift_minutes": 0.0,
            "air_entrainment_pct": 0.0,
        }

        air_entrained = combined_admix["air_entrainment_pct"] > 0
        target_air = max(inputs.target_air_content_pct, combined_admix["air_entrainment_pct"])

        water_kg = estimate_water_demand_kg_m3(
            slump_mm=inputs.slump_mm,
            max_agg_size_mm=inputs.max_agg_size_mm,
            air_entrained=air_entrained,
            target_air_content_pct=target_air,
            admixture_water_reduction_pct=combined_admix["water_reduction_pct"],
            cement_water_demand_factor=self.cement.water_demand_factor,
        )

        wcm = inputs.wcm_override or wcm_for_target_strength(inputs.target_strength_mpa)
        min_cementitious, max_wcm = self._exposure_limits(inputs.exposure)
        if wcm > max_wcm:
            notes.append(
                f"Strength-derived w/cm={wcm:.3f} exceeds exposure-class limit {max_wcm:.3f}; "
                f"w/cm reduced to the exposure limit (durability governs over strength here)."
            )
            wcm = max_wcm

        total_cementitious = required_cementitious_content_kg_m3(water_kg, wcm, inputs.exposure)
        if total_cementitious < min_cementitious:
            total_cementitious = min_cementitious
            notes.append(f"Cementitious content raised to exposure-class minimum {min_cementitious:.0f} kg/m3.")

        scm_kg = total_cementitious * inputs.scm_fraction_of_binder
        cement_kg = total_cementitious - scm_kg

        binder_kg = total_cementitious
        admixture_kg = sum(d.mass_kg(binder_kg) for d in self.admixture_doses)

        fine_fm = fineness_modulus(self.fine_aggregate.psd) if self.fine_aggregate.psd else 2.7
        coarse_bulk_density = self.coarse_aggregate.bulk_density_kg_m3
        coarse_kg = coarse_aggregate_mass_kg_m3(inputs.max_agg_size_mm, fine_fm, coarse_bulk_density)

        # Absolute volume method: sum(volumes) = 1 m3
        water_vol = water_kg / WATER_DENSITY_KG_M3
        cement_vol = cement_kg / (self.cement.specific_gravity * WATER_DENSITY_KG_M3)
        scm_vol = (scm_kg / (self.scm.specific_gravity * WATER_DENSITY_KG_M3)) if (self.scm and scm_kg > 0) else 0.0
        coarse_vol = coarse_kg / (self.coarse_aggregate.specific_gravity_ssd * WATER_DENSITY_KG_M3)
        air_vol = target_air / 100.0
        admixture_vol = admixture_kg / 1050.0 / WATER_DENSITY_KG_M3 if admixture_kg > 0 else 0.0

        known_vol = water_vol + cement_vol + scm_vol + coarse_vol + air_vol + admixture_vol
        fine_vol = VOLUME_TARGET_M3 - known_vol
        if fine_vol < 0:
            raise ValueError(
                f"Mix design infeasible: non-fine-aggregate volumes already sum to "
                f"{known_vol:.4f} m3, exceeding the 1 m3 target. Reduce cementitious "
                f"content, coarse aggregate fraction, or air content."
            )
        fine_kg = fine_vol * self.fine_aggregate.specific_gravity_ssd * WATER_DENSITY_KG_M3

        total_mass = water_kg + cement_kg + scm_kg + fine_kg + coarse_kg + admixture_kg
        total_volume_check = water_vol + cement_vol + scm_vol + fine_vol + coarse_vol + air_vol + admixture_vol
        density = total_mass / VOLUME_TARGET_M3

        predicted_strength = strength_for_wcm(wcm)

        return MixDesignResult(
            inputs=inputs,
            water_kg=water_kg,
            cement_kg=cement_kg,
            scm_kg=scm_kg,
            fine_aggregate_kg=fine_kg,
            coarse_aggregate_kg=coarse_kg,
            admixture_kg=admixture_kg,
            air_content_pct=target_air,
            total_mass_kg=total_mass,
            yield_m3=VOLUME_TARGET_M3,
            density_kg_m3=density,
            wcm_ratio=wcm,
            predicted_28d_strength_mpa=predicted_strength,
            volume_check_m3=total_volume_check,
            notes=notes,
        )

    @staticmethod
    def _exposure_limits(exposure: ExposureClass) -> tuple[float, float]:
        from .cement import exposure_limits
        return exposure_limits(exposure)
