"""
mix_design.cement
====================

ESTIMATED water/cementitious-ratio <-> strength relationship (a simplified
Abrams'-law-style model), and minimum-cementitious-content lookups by
exposure class. These are teaching-level correlations; always calibrate
the model constants (A, B) against real trial-mix data before relying on
absolute strength predictions.
"""

from __future__ import annotations

import math
from enum import Enum

import numpy as np


class ExposureClass(str, Enum):
    """Simplified exposure classes (loosely inspired by EN 206 / ACI 318
    categories, not a reproduction of any specific standard's clause)."""

    X0 = "X0_no_risk"
    XC_CARBONATION = "XC_carbonation"
    XD_CHLORIDE = "XD_chloride"
    XS_MARINE = "XS_marine_chloride"
    XF_FREEZE_THAW = "XF_freeze_thaw"
    XA_CHEMICAL = "XA_chemical_attack"


# ESTIMATED minimum cementitious content (kg/m3) and maximum w/cm by
# exposure class -- illustrative, NOT a reproduction of a specific
# national standard's mandatory table. Always confirm against the
# governing specification for real construction.
_EXPOSURE_LIMITS: dict[ExposureClass, tuple[float, float]] = {
    ExposureClass.X0: (260.0, 0.65),
    ExposureClass.XC_CARBONATION: (280.0, 0.60),
    ExposureClass.XD_CHLORIDE: (300.0, 0.55),
    ExposureClass.XS_MARINE: (320.0, 0.50),
    ExposureClass.XF_FREEZE_THAW: (300.0, 0.50),
    ExposureClass.XA_CHEMICAL: (320.0, 0.45),
}


def exposure_limits(exposure: ExposureClass) -> tuple[float, float]:
    """Returns (min_cementitious_kg_m3, max_wcm_ratio) for the exposure class."""
    return _EXPOSURE_LIMITS[exposure]


# Abrams'-law style model: fc(t) = A / B^(w/cm), calibrated so that
# w/cm=0.5 gives ~35 MPa at 28 days for a reference OPC (ESTIMATED,
# illustrative constants -- calibrate to plant trial-mix data in
# production use, see mix_design.optimisation for a fitting helper).
ABRAMS_A_MPA = 97.0
ABRAMS_B = 4.15


def wcm_for_target_strength(target_strength_mpa: float, a: float = ABRAMS_A_MPA, b: float = ABRAMS_B) -> float:
    """Invert the Abrams'-law-style model to obtain a required w/cm ratio
    for a target 28-day compressive strength."""
    if target_strength_mpa <= 0:
        raise ValueError("target_strength_mpa must be positive")
    if target_strength_mpa >= a:
        raise ValueError(
            f"target_strength_mpa={target_strength_mpa} MPa exceeds the model's asymptotic "
            f"limit A={a} MPa for these calibration constants; not achievable via w/cm alone."
        )
    wcm = math.log(a / target_strength_mpa) / math.log(b)
    return max(0.25, wcm)  # practical lower floor


def strength_for_wcm(wcm, a: float = ABRAMS_A_MPA, b: float = ABRAMS_B):
    """Accepts a scalar or a NumPy array of w/cm ratios (the latter used by
    the vectorised Monte Carlo engine)."""
    if np.any(np.asarray(wcm) <= 0):
        raise ValueError("wcm must be positive")
    return a / (b ** wcm)


def required_cementitious_content_kg_m3(
    water_kg_m3: float,
    wcm_ratio: float,
    exposure: ExposureClass | None = None,
) -> float:
    """Total cementitious (cement + SCM) content implied by the water
    content and target w/cm, raised to the exposure-class minimum if
    that governs instead."""
    if water_kg_m3 <= 0 or wcm_ratio <= 0:
        raise ValueError("water_kg_m3 and wcm_ratio must be positive")
    from_wcm = water_kg_m3 / wcm_ratio
    if exposure is not None:
        min_cementitious, _ = exposure_limits(exposure)
        return max(from_wcm, min_cementitious)
    return from_wcm
