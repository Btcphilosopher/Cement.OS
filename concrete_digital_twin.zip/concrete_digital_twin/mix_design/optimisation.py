"""
mix_design.optimisation
==========================

Single-mix optimisation: search over SCM fraction and (within exposure
limits) w/cm ratio to minimise a weighted objective of cost + carbon +
cement content, subject to strength/slump/durability constraints.

For multi-objective (Pareto) exploration and large-scale recipe search,
see the top-level ``optimisation`` package (genetic / multiobjective /
scipy_optimizer), which this module's engine also builds on.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar

from ..environment.carbon import mix_carbon_kgco2e_per_m3
from ..economics.material_cost import mix_material_cost_per_m3
from .cement import ExposureClass, exposure_limits
from .mix import MixDesignEngine, MixDesignInputs, MixDesignResult


@dataclass
class ObjectiveWeights:
    cost_weight: float = 1.0
    carbon_weight: float = 1.0
    cement_weight: float = 0.2


@dataclass
class OptimisedMixResult:
    best: MixDesignResult
    best_scm_fraction: float
    objective_value: float
    cost_per_m3: float
    carbon_kgco2e_per_m3: float
    search_trace: list[dict[str, float]]


def optimise_scm_fraction(
    engine: MixDesignEngine,
    base_inputs: MixDesignInputs,
    weights: ObjectiveWeights = ObjectiveWeights(),
    scm_bounds: tuple[float, float] = (0.0, 0.5),
    currency_symbol: str = "£",
) -> OptimisedMixResult:
    """1-D bounded optimisation over SCM fraction of binder (a common,
    high-leverage lever for cost/carbon trade-off), keeping all other
    mix-design inputs fixed. Uses SciPy's bounded scalar minimizer.
    """
    trace: list[dict[str, float]] = []

    def objective(scm_fraction: float) -> float:
        trial_inputs = base_inputs.model_copy(update={"scm_fraction_of_binder": float(scm_fraction)})
        try:
            result = engine.design(trial_inputs)
        except ValueError:
            return 1e9  # infeasible

        if result.predicted_28d_strength_mpa < base_inputs.target_strength_mpa * 0.97:
            penalty = (base_inputs.target_strength_mpa - result.predicted_28d_strength_mpa) * 1000.0
        else:
            penalty = 0.0

        cost = mix_material_cost_per_m3(result, engine)
        carbon = mix_carbon_kgco2e_per_m3(result, engine)

        score = (
            weights.cost_weight * cost
            + weights.carbon_weight * carbon
            + weights.cement_weight * result.cement_kg
            + penalty
        )
        trace.append({"scm_fraction": scm_fraction, "cost": cost, "carbon": carbon, "score": score})
        return score

    res = minimize_scalar(objective, bounds=scm_bounds, method="bounded", options={"xatol": 1e-3})
    best_scm = float(res.x)
    best_inputs = base_inputs.model_copy(update={"scm_fraction_of_binder": best_scm})
    best_result = engine.design(best_inputs)

    return OptimisedMixResult(
        best=best_result,
        best_scm_fraction=best_scm,
        objective_value=float(res.fun),
        cost_per_m3=mix_material_cost_per_m3(best_result, engine),
        carbon_kgco2e_per_m3=mix_carbon_kgco2e_per_m3(best_result, engine),
        search_trace=sorted(trace, key=lambda t: t["scm_fraction"]),
    )


def sensitivity_analysis(
    engine: MixDesignEngine,
    base_inputs: MixDesignInputs,
    parameter: str,
    values: list[float],
) -> list[dict[str, float]]:
    """Vary a single MixDesignInputs field across `values` and report the
    resulting strength, cost, carbon and w/cm -- used for section 52
    (sensitivity analysis)."""
    if parameter not in MixDesignInputs.model_fields:
        raise ValueError(f"unknown mix design parameter '{parameter}'")

    rows = []
    for v in values:
        trial = base_inputs.model_copy(update={parameter: v})
        try:
            result = engine.design(trial)
        except ValueError:
            rows.append({parameter: v, "feasible": 0.0})
            continue
        rows.append({
            parameter: v,
            "feasible": 1.0,
            "strength_mpa": result.predicted_28d_strength_mpa,
            "wcm_ratio": result.wcm_ratio,
            "cost_per_m3": mix_material_cost_per_m3(result, engine),
            "carbon_kgco2e_per_m3": mix_carbon_kgco2e_per_m3(result, engine),
        })
    return rows
