"""
mix_design.water
==================

ESTIMATED mix-water demand, loosely following the shape of the classic
ACI 211.1 Table 6.3.3 approach (water content as a function of slump and
maximum aggregate size, with an air-entrainment reduction). Values here
are illustrative, simplified, and interpolated/extrapolated with smooth
functions rather than reproducing the table verbatim -- treat as
ESTIMATED, not a substitute for trial batches.
"""

from __future__ import annotations

import numpy as np

# Reference (non-air-entrained) water content, kg/m3, at slump=75mm for a
# range of max aggregate sizes (mm). ESTIMATED, illustrative baseline.
_REF_WATER_AT_75MM_SLUMP: dict[float, float] = {
    9.5: 210.0,
    12.5: 200.0,
    19.0: 185.0,
    25.0: 180.0,
    37.5: 160.0,
    50.0: 155.0,
}

_SIZES = np.array(sorted(_REF_WATER_AT_75MM_SLUMP))
_REFS = np.array([_REF_WATER_AT_75MM_SLUMP[s] for s in _SIZES])


def _base_water_kg_m3(max_agg_size_mm: float) -> float:
    return float(np.interp(max_agg_size_mm, _SIZES, _REFS))


def estimate_water_demand_kg_m3(
    slump_mm: float,
    max_agg_size_mm: float,
    air_entrained: bool = False,
    target_air_content_pct: float = 2.0,
    admixture_water_reduction_pct: float = 0.0,
    cement_water_demand_factor: float = 1.0,
) -> float:
    """ESTIMATED water demand, kg per m3 of concrete.

    * Baseline from max aggregate size at a 75 mm reference slump.
    * +/- ~3 kg/m3 per 25mm change in slump around the reference (higher
      slump => more water), a common rule-of-thumb magnitude.
    * Air entrainment reduces water demand (workability aid), roughly
      3-5 kg/m3 per percentage point of entrained air above ~1%.
    * Admixture water reduction and cement (blaine/reactivity) water-demand
      factor are then applied multiplicatively.
    """
    if slump_mm < 0 or max_agg_size_mm <= 0:
        raise ValueError("slump_mm must be >=0 and max_agg_size_mm must be >0")
    if not (0.0 <= admixture_water_reduction_pct <= 40.0):
        raise ValueError("admixture_water_reduction_pct must be within [0,40]")

    base = _base_water_kg_m3(max_agg_size_mm)
    slump_delta = slump_mm - 75.0
    water = base + (slump_delta / 25.0) * 3.0

    if air_entrained and target_air_content_pct > 1.0:
        water -= (target_air_content_pct - 1.0) * 4.0

    water *= cement_water_demand_factor
    water *= (1.0 - admixture_water_reduction_pct / 100.0)

    return max(100.0, water)  # physical floor
