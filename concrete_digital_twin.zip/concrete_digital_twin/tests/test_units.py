import pytest

from concrete_digital_twin.core.units import Quantity, UnitError, kg, m3, tonnes


def test_kg_to_tonnes_roundtrip():
    q = kg(1500)
    assert q.to("t") == pytest.approx(1.5)


def test_cannot_add_mass_and_volume():
    with pytest.raises(UnitError):
        _ = kg(10) + m3(1)


def test_cannot_convert_across_dimensions():
    q = kg(10)
    with pytest.raises(UnitError):
        q.to("m3")


def test_tonnes_and_kg_are_equal_quantities():
    assert tonnes(2) == kg(2000)


def test_litres_and_m3_consistent():
    q = Quantity.of(1000, "L")
    assert q.to("m3") == pytest.approx(1.0)


def test_temperature_offset_conversion():
    q = Quantity.of(20, "degC")
    assert q.to("K") == pytest.approx(293.15)


def test_unknown_unit_raises():
    with pytest.raises(UnitError):
        Quantity.of(1, "furlongs")
