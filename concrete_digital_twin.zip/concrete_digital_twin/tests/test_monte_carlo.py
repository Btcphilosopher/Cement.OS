import pytest

from concrete_digital_twin.simulation.monte_carlo import run_monte_carlo


def test_monte_carlo_runs_at_various_scales(mix_result):
    for n in (1000, 10000):
        mc = run_monte_carlo(mix_result, n_runs=n, seed=42)
        assert mc.n_runs == n
        assert len(mc.raw_strengths) == n


def test_monte_carlo_probabilities_within_bounds(mix_result):
    mc = run_monte_carlo(mix_result, n_runs=5000, seed=1)
    for p in (mc.prob_strength_below_target, mc.prob_slump_below_min, mc.prob_slump_above_max, mc.prob_wcm_above_limit, mc.prob_temperature_above_limit, mc.prob_batch_mass_out_of_tolerance):
        assert 0.0 <= p <= 1.0


def test_monte_carlo_percentiles_ordered(mix_result):
    mc = run_monte_carlo(mix_result, n_runs=5000, seed=2)
    assert mc.strength_p5 <= mc.strength_p50 <= mc.strength_p95


def test_monte_carlo_reproducible_with_seed(mix_result):
    mc1 = run_monte_carlo(mix_result, n_runs=2000, seed=123)
    mc2 = run_monte_carlo(mix_result, n_runs=2000, seed=123)
    assert mc1.strength_mean == pytest.approx(mc2.strength_mean)


def test_monte_carlo_rejects_zero_runs(mix_result):
    with pytest.raises(ValueError):
        run_monte_carlo(mix_result, n_runs=0)
