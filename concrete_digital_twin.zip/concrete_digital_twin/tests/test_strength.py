import numpy as np
import pytest

from concrete_digital_twin.curing.strength import CementSpeedClass, strength_at_age, strength_development_curve
from concrete_digital_twin.mix_design.cement import strength_for_wcm, wcm_for_target_strength


def test_strength_increases_monotonically_with_age():
    ages = np.array([1, 3, 7, 28, 56, 90], dtype=float)
    strengths = strength_at_age(ages, fc28_mpa=35.0)
    assert np.all(np.diff(strengths) > 0)


def test_strength_at_28_days_equals_fc28():
    s = strength_at_age(28.0, fc28_mpa=40.0)
    assert s == pytest.approx(40.0, rel=1e-6)


def test_rapid_hardening_gains_strength_faster_at_early_age():
    rapid = strength_at_age(3.0, fc28_mpa=35.0, speed_class=CementSpeedClass.RAPID_HARDENING)
    normal = strength_at_age(3.0, fc28_mpa=35.0, speed_class=CementSpeedClass.NORMAL)
    assert rapid > normal


def test_wcm_strength_roundtrip():
    target = 40.0
    wcm = wcm_for_target_strength(target)
    back = strength_for_wcm(wcm)
    assert back == pytest.approx(target, rel=1e-6)


def test_wcm_for_target_strength_rejects_impossible_target():
    with pytest.raises(ValueError):
        wcm_for_target_strength(200.0)  # exceeds model asymptote


def test_strength_development_curve_shape():
    curve = strength_development_curve(35.0)
    assert curve.strengths_mpa[-1] >= curve.strengths_mpa[0]
    assert len(curve.ages_days) == len(curve.strengths_mpa)
