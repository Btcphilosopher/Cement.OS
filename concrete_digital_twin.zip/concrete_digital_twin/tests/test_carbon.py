import pytest

from concrete_digital_twin.environment.carbon import mix_carbon_kgco2e_per_m3, transport_carbon_kgco2e


def test_mix_carbon_positive(plant, mix_result):
    carbon = mix_carbon_kgco2e_per_m3(mix_result, plant.engine)
    assert carbon > 0


def test_mix_carbon_equals_sum_of_material_contributions(plant, mix_result):
    cement_co2 = (mix_result.cement_kg / 1000.0) * plant.engine.cement.embodied_carbon_kgco2e_per_tonne
    scm_co2 = (mix_result.scm_kg / 1000.0) * plant.engine.scm.embodied_carbon_kgco2e_per_tonne if mix_result.scm_kg > 0 else 0.0
    fine_co2 = (mix_result.fine_aggregate_kg / 1000.0) * plant.engine.fine_aggregate.embodied_carbon_kgco2e_per_tonne
    coarse_co2 = (mix_result.coarse_aggregate_kg / 1000.0) * plant.engine.coarse_aggregate.embodied_carbon_kgco2e_per_tonne
    admixture_co2 = sum(
        (d.mass_kg(mix_result.cement_kg + mix_result.scm_kg) / 1000.0) * d.admixture.embodied_carbon_kgco2e_per_tonne
        for d in plant.engine.admixture_doses
    )
    expected = cement_co2 + scm_co2 + fine_co2 + coarse_co2 + admixture_co2
    actual = mix_carbon_kgco2e_per_m3(mix_result, plant.engine)
    assert actual == pytest.approx(expected, rel=1e-9)


def test_transport_carbon_scales_with_distance_and_mass():
    c1 = transport_carbon_kgco2e(mass_tonnes=10, distance_km=5)
    c2 = transport_carbon_kgco2e(mass_tonnes=10, distance_km=10)
    assert c2 == pytest.approx(2 * c1)


def test_transport_carbon_rejects_negative_inputs():
    with pytest.raises(ValueError):
        transport_carbon_kgco2e(mass_tonnes=-1, distance_km=5)


def test_lower_scm_free_mix_has_higher_carbon_than_high_scm_mix(plant):
    from concrete_digital_twin.mix_design.mix import MixDesignInputs
    low_scm = plant.engine.design(MixDesignInputs(target_strength_mpa=35, slump_mm=100, scm_fraction_of_binder=0.0))
    high_scm = plant.engine.design(MixDesignInputs(target_strength_mpa=35, slump_mm=100, scm_fraction_of_binder=0.4))
    assert mix_carbon_kgco2e_per_m3(low_scm, plant.engine) > mix_carbon_kgco2e_per_m3(high_scm, plant.engine)
