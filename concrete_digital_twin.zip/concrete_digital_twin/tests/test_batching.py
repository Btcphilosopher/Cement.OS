import pytest


def test_batch_within_reasonable_tolerance(plant, mix_result):
    record = plant.batch_plant.batch("B-TEST-01", "MIX-001", mix_result, volume_m3=1.0)
    for row in record.accuracy_report():
        assert abs(row["error_pct"]) < 10.0  # generous bound; scale error stds are all < 2%


def test_batch_shortage_detected_when_silo_nearly_empty(plant, mix_result):
    plant.batch_plant.cement_silo.level_kg = 1.0  # force a shortage
    record = plant.batch_plant.batch("B-TEST-02", "MIX-001", mix_result, volume_m3=1.0)
    assert "cement" in record.shortages
    assert record.shortages["cement"] > 0


def test_batch_scales_with_volume(plant, mix_result):
    record = plant.batch_plant.batch("B-TEST-03", "MIX-001", mix_result, volume_m3=2.0)
    cement_weigh = record.weighs["cement"]
    assert cement_weigh.target_kg == pytest.approx(mix_result.cement_kg * 2.0)


def test_batch_rejects_non_positive_volume(plant, mix_result):
    with pytest.raises(ValueError):
        plant.batch_plant.batch("B-TEST-04", "MIX-001", mix_result, volume_m3=0.0)


def test_weigh_hopper_rejects_overload():
    from concrete_digital_twin.production.batching import WeighHopper
    hopper = WeighHopper("test", capacity_kg=100)
    with pytest.raises(ValueError):
        hopper.weigh(150)
