import pytest

from concrete_digital_twin.aggregates.crushing import JawCrusher
from concrete_digital_twin.aggregates.screening import VibratingScreen
from concrete_digital_twin.cement.grinding import CementMill, MillFeed
from concrete_digital_twin.cement.kiln import KilnInputs, RotaryKiln
from concrete_digital_twin.core.balances import MassBalanceError, check_mass_balance
from concrete_digital_twin.core.materials import ParticleSizeDistribution


def test_check_mass_balance_pass():
    result = check_mass_balance(inputs_kg=100, outputs_kg=95, losses_kg=5)
    assert result.ok


def test_check_mass_balance_fail_raises():
    with pytest.raises(MassBalanceError):
        check_mass_balance(inputs_kg=100, outputs_kg=90, losses_kg=5)


def test_check_mass_balance_negative_rejected():
    with pytest.raises(ValueError):
        check_mass_balance(inputs_kg=-1, outputs_kg=0)


def test_kiln_mass_balance():
    kiln = RotaryKiln()
    out = kiln.simulate(KilnInputs(raw_meal_feed_kg_h=100_000, caco3_fraction_of_raw_meal=0.78))
    assert out.mass_balance_ok
    # clinker + CO2 + dust should reconcile with feed within 0.02%
    total_out = out.clinker_kg_h + out.co2_calcination_kg_h + out.dust_kg_h
    assert total_out == pytest.approx(100_000, rel=1e-4)


def test_cement_mill_mass_balance():
    mill = CementMill()
    feed = MillFeed(clinker_kg_h=45000, gypsum_kg_h=2000, scm_kg_h=3000)
    out = mill.simulate(feed, target_blaine_m2_kg=380)
    assert out.cement_kg_h + out.reject_kg_h == pytest.approx(feed.total_kg_h, rel=1e-4)


def test_crusher_mass_balance():
    crusher = JawCrusher(capacity_kg_h=200_000, css_mm=20)
    out = crusher.simulate(feed_kg_h=100_000, feed_top_size_mm=200)
    assert out.product_kg_h + out.fines_kg_h == pytest.approx(100_000, rel=1e-4)


def test_screen_mass_balance():
    screen = VibratingScreen(cut_size_mm=4.0, efficiency=0.9)
    psd = ParticleSizeDistribution(sieve_sizes_mm=[1, 2, 4, 8, 16], percent_passing=[10, 25, 45, 80, 100])
    out = screen.simulate(feed_kg_h=50_000, feed_psd=psd)
    assert out.oversize_kg_h + out.undersize_kg_h == pytest.approx(50_000, rel=1e-6)
