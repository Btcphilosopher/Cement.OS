import numpy as np
import pytest

from concrete_digital_twin.cement.raw_materials import default_raw_meal_blend
from concrete_digital_twin.core.chemistry import bogue_phases
from concrete_digital_twin.curing.hydration import degree_of_hydration, hydration_heat_profile, ultimate_degree_of_hydration
from concrete_digital_twin.curing.maturity import equivalent_age_hours, nurse_saul_maturity_c_hours
from concrete_digital_twin.curing.temperature import CuringRegime, simulate_curing_temperature


@pytest.fixture
def phases():
    blend = default_raw_meal_blend()
    return bogue_phases(blend.blended_oxides_ignited_basis())


def test_degree_of_hydration_increases_with_time():
    t = np.array([1, 10, 50, 200, 1000], dtype=float)
    alpha = degree_of_hydration(t, wcm=0.5)
    assert np.all(np.diff(alpha) >= 0)


def test_degree_of_hydration_bounded_by_ultimate():
    alpha_u = ultimate_degree_of_hydration(0.5)
    alpha = degree_of_hydration(np.array([1e6]), wcm=0.5)
    assert alpha[0] <= alpha_u + 1e-9


def test_ultimate_degree_of_hydration_capped_at_one():
    assert ultimate_degree_of_hydration(5.0) <= 1.0


def test_hydration_heat_profile_non_negative(phases):
    t = np.linspace(0, 200, 30)
    profile = hydration_heat_profile(t, wcm=0.5, phases=phases)
    assert np.all(profile.cumulative_heat_j_per_g_cement >= 0)
    assert np.all(profile.degree_of_hydration >= 0)


def test_nurse_saul_maturity_monotonic():
    temps = np.array([20.0] * 10)
    times = np.linspace(0, 100, 10)
    m = nurse_saul_maturity_c_hours(temps, times)
    assert np.all(np.diff(m) >= 0)


def test_equivalent_age_at_reference_temp_equals_real_time():
    temps = np.full(20, 20.0)
    times = np.linspace(0, 50, 20)
    te = equivalent_age_hours(temps, times, reference_temp_c=20.0)
    assert te[-1] == pytest.approx(times[-1], rel=1e-6)


def test_curing_temperature_rises_above_ambient_for_sealed_regime(phases):
    t = np.linspace(0, 72, 40)
    history = simulate_curing_temperature(t, wcm=0.45, phases=phases, cement_content_kg_m3=380, regime=CuringRegime.SEALED)
    assert history.temperature_c.max() > history.temperature_c[0]
