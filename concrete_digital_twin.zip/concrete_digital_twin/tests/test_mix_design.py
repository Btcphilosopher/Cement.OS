import pytest

from concrete_digital_twin.mix_design.cement import ExposureClass
from concrete_digital_twin.mix_design.mix import MixDesignInputs


def test_mix_total_mass_equals_sum_of_components(mix_result):
    component_sum = (
        mix_result.water_kg + mix_result.cement_kg + mix_result.scm_kg
        + mix_result.fine_aggregate_kg + mix_result.coarse_aggregate_kg + mix_result.admixture_kg
    )
    assert mix_result.total_mass_kg == pytest.approx(component_sum, rel=1e-9)


def test_mix_volume_balances_to_one_m3(mix_result):
    assert mix_result.volume_check_m3 == pytest.approx(1.0, abs=1e-6)


def test_mix_yield_is_one_m3(mix_result):
    assert mix_result.yield_m3 == pytest.approx(1.0)


def test_higher_target_strength_lowers_wcm(plant):
    low = plant.engine.design(MixDesignInputs(target_strength_mpa=25.0, slump_mm=100.0))
    high = plant.engine.design(MixDesignInputs(target_strength_mpa=45.0, slump_mm=100.0, exposure=ExposureClass.X0))
    assert high.wcm_ratio <= low.wcm_ratio


def test_all_component_masses_non_negative(mix_result):
    for value in (mix_result.water_kg, mix_result.cement_kg, mix_result.scm_kg, mix_result.fine_aggregate_kg, mix_result.coarse_aggregate_kg, mix_result.admixture_kg):
        assert value >= 0


def test_scm_reduces_cement_content(plant):
    no_scm = plant.engine.design(MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.0))
    with_scm = plant.engine.design(MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.3))
    assert with_scm.cement_kg < no_scm.cement_kg
    assert with_scm.scm_kg > 0


def test_infeasible_mix_raises(plant):
    with pytest.raises(ValueError):
        # An extremely low forced w/cm drives cementitious content (and thus
        # cement volume) so high, combined with a large max aggregate size
        # (high coarse-aggregate bulk volume fraction) and high air content,
        # that non-fine volumes alone exceed 1 m3.
        plant.engine.design(MixDesignInputs(
            target_strength_mpa=80.0, slump_mm=280.0, target_air_content_pct=9.9,
            wcm_override=0.08, max_agg_size_mm=50.0,
        ))
