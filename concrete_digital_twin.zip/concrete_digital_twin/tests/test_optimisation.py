import numpy as np
import pytest

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.mix_design.optimisation import optimise_scm_fraction
from concrete_digital_twin.optimisation.genetic import genetic_algorithm
from concrete_digital_twin.optimisation.multiobjective import pareto_frontier, select_balanced, select_weighted
from concrete_digital_twin.optimisation.optimizer import RecipeConstraints, recommend_mix, search_recipes


def test_genetic_algorithm_minimises_sphere_function():
    result = genetic_algorithm(lambda x: float(np.sum(x ** 2)), bounds=[(-5, 5), (-5, 5)], generations=40, seed=0)
    assert result.best_fitness < 1.0


def test_pareto_frontier_excludes_dominated_points():
    candidates = [
        {"cost": 10, "carbon": 100}, {"cost": 20, "carbon": 50},
        {"cost": 30, "carbon": 200},  # dominated by both above
        {"cost": 5, "carbon": 300},
    ]
    frontier = pareto_frontier(candidates, ["cost", "carbon"])
    assert {"cost": 30, "carbon": 200} not in frontier
    assert {"cost": 10, "carbon": 100} in frontier


def test_select_balanced_returns_a_candidate():
    candidates = [{"cost": 10, "carbon": 100}, {"cost": 20, "carbon": 50}, {"cost": 15, "carbon": 70}]
    chosen = select_balanced(candidates, ["cost", "carbon"])
    assert chosen in candidates


def test_select_weighted_prefers_cost_when_weighted_heavily():
    candidates = [{"cost": 10, "carbon": 200}, {"cost": 100, "carbon": 10}]
    chosen = select_weighted(candidates, weights={"cost": 0.99, "carbon": 0.01})
    assert chosen["cost"] == 10


def test_search_recipes_returns_feasible_candidates(plant):
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    report = search_recipes(plant.engine, base_inputs, RecipeConstraints(), n_candidates=300)
    assert report.n_feasible > 0
    assert len(report.top_10) <= 10
    for c in report.top_10:
        assert c["strength_mpa"] >= base_inputs.target_strength_mpa * 0.97 - 1e-6


def test_search_recipes_respects_carbon_constraint(plant):
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    report = search_recipes(plant.engine, base_inputs, RecipeConstraints(max_carbon_kgco2e_per_m3=150), n_candidates=500)
    for c in report.feasible:
        assert c["carbon_kgco2e_per_m3"] <= 150


def test_recommend_mix_never_auto_applies(plant, mix_result):
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    rec = recommend_mix(mix_result, plant.engine, base_inputs, n_candidates=300)
    with pytest.raises(RuntimeError):
        rec.apply()


def test_optimise_scm_fraction_stays_within_bounds(plant):
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    result = optimise_scm_fraction(plant.engine, base_inputs, scm_bounds=(0.0, 0.4))
    assert 0.0 <= result.best_scm_fraction <= 0.4
