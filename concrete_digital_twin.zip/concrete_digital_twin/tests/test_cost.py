import pytest

from concrete_digital_twin.economics.material_cost import material_cost_breakdown, mix_material_cost_per_m3
from concrete_digital_twin.economics.pricing import Currency, PricingPolicy, convert, price_per_m3
from concrete_digital_twin.economics.production_cost import ProductionCostInputs, cost_per_day, cost_per_m3


def test_cost_per_m3_positive(plant, mix_result):
    cost = mix_material_cost_per_m3(mix_result, plant.engine)
    assert cost > 0


def test_cost_breakdown_sums_to_total(plant, mix_result):
    breakdown = material_cost_breakdown(mix_result, plant.engine)
    assert sum(breakdown.values()) == pytest.approx(mix_material_cost_per_m3(mix_result, plant.engine), rel=1e-9)


def test_price_includes_margin():
    price = price_per_m3(cost_per_m3=50.0, policy=PricingPolicy(margin_pct=20.0, volume_discount_tiers=()))
    assert price == pytest.approx(60.0)


def test_volume_discount_reduces_price():
    policy = PricingPolicy(margin_pct=0.0, volume_discount_tiers=((100.0, 10.0),))
    small_order = price_per_m3(50.0, policy, order_volume_m3=10)
    large_order = price_per_m3(50.0, policy, order_volume_m3=200)
    assert large_order < small_order


def test_currency_conversion():
    eur = Currency(symbol="€", code="EUR", fx_rate_to_gbp=1.15)
    assert convert(100.0, eur) == pytest.approx(115.0)


def test_production_cost_per_day_scales_with_volume():
    inputs = ProductionCostInputs(
        material_cost_per_m3=50, energy_cost_per_m3=2, labour_cost_per_hour=40,
        maintenance_cost_per_hour=10, transport_cost_per_m3=5,
    )
    low = cost_per_day(inputs, daily_volume_m3=100, operating_hours=8)
    high = cost_per_day(inputs, daily_volume_m3=200, operating_hours=8)
    assert high > low
