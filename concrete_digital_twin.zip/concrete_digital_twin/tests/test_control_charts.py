import numpy as np
import pytest

from concrete_digital_twin.quality.control_charts import individuals_moving_range_chart, xbar_r_chart, xbar_s_chart


def test_xbar_r_chart_center_line_matches_grand_mean():
    rng = np.random.default_rng(0)
    subgroups = [list(rng.normal(100, 2, 4)) for _ in range(20)]
    xbar, r = xbar_r_chart(subgroups)
    grand_mean = np.mean([np.mean(g) for g in subgroups])
    assert xbar.center_line == pytest.approx(grand_mean)


def test_xbar_r_chart_ucl_above_lcl():
    rng = np.random.default_rng(1)
    subgroups = [list(rng.normal(50, 1, 5)) for _ in range(15)]
    xbar, r = xbar_r_chart(subgroups)
    assert xbar.upper_control_limit > xbar.lower_control_limit
    assert r.upper_control_limit >= r.lower_control_limit


def test_out_of_control_point_detected():
    rng = np.random.default_rng(2)
    subgroups = [list(rng.normal(100, 1, 4)) for _ in range(19)]
    subgroups.append([200, 201, 199, 202])  # obviously out of control
    xbar, r = xbar_r_chart(subgroups)
    assert 19 in xbar.out_of_control_indices


def test_rejects_mismatched_subgroup_sizes():
    with pytest.raises(ValueError):
        xbar_r_chart([[1, 2, 3], [1, 2]])


def test_individuals_chart_basic():
    # A long stable baseline plus one clear spike: with only a few points,
    # the moving-range average itself gets dragged up by the spike (a
    # well-known limitation of I-MR charts on short series), so use enough
    # baseline points that the average moving range stays tight.
    values = [10.0, 10.2, 9.8, 10.1, 9.9, 10.0, 10.3, 9.7, 10.1, 9.9, 10.0, 30.0, 10.1, 9.8]
    i_chart, mr_chart = individuals_moving_range_chart(values)
    assert len(i_chart.out_of_control_indices) >= 1


def test_xbar_s_chart_runs():
    rng = np.random.default_rng(3)
    subgroups = [list(rng.normal(30, 0.5, 6)) for _ in range(10)]
    xbar, s = xbar_s_chart(subgroups)
    assert xbar.center_line == pytest.approx(30, abs=1.0)
