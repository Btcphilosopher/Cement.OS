import pytest

from concrete_digital_twin.aggregates.aggregate import make_fine_aggregate
from concrete_digital_twin.aggregates.moisture import correct_batch_water, net_water_adjustment_kg


def test_wet_aggregate_contributes_free_water():
    agg = make_fine_aggregate(absorption_pct=1.0, moisture_content_pct=4.0)  # 3% surface moisture
    corr = correct_batch_water(agg, ssd_target_mass_kg=1000.0)
    assert corr.surface_moisture_pct == pytest.approx(3.0)
    assert corr.free_water_contribution_kg == pytest.approx(30.0)
    assert corr.water_absorbed_by_dry_aggregate_kg == 0.0
    assert corr.batch_mass_as_received_kg == pytest.approx(1030.0)


def test_dry_aggregate_absorbs_water():
    agg = make_fine_aggregate(absorption_pct=2.0, moisture_content_pct=0.5)  # -1.5% surface (drier than SSD)
    corr = correct_batch_water(agg, ssd_target_mass_kg=1000.0)
    assert corr.surface_moisture_pct == pytest.approx(-1.5)
    assert corr.water_absorbed_by_dry_aggregate_kg == pytest.approx(15.0)
    assert corr.free_water_contribution_kg == 0.0
    assert corr.batch_mass_as_received_kg == pytest.approx(985.0)


def test_ssd_aggregate_needs_no_correction():
    agg = make_fine_aggregate(absorption_pct=1.5, moisture_content_pct=1.5)
    corr = correct_batch_water(agg, ssd_target_mass_kg=500.0)
    assert corr.surface_moisture_pct == pytest.approx(0.0, abs=1e-9)
    assert corr.batch_mass_as_received_kg == pytest.approx(500.0)


def test_net_water_adjustment_combines_multiple_aggregates():
    wet = make_fine_aggregate(absorption_pct=1.0, moisture_content_pct=3.0)   # +2% -> reduces added water
    dry = make_fine_aggregate(absorption_pct=2.0, moisture_content_pct=0.0)   # -2% -> increases added water
    wet_corr = correct_batch_water(wet, 1000.0)
    dry_corr = correct_batch_water(dry, 1000.0)
    net = net_water_adjustment_kg([wet_corr, dry_corr])
    # +20 kg needed for dry aggregate, -20 kg for wet aggregate -> net 0
    assert net == pytest.approx(0.0)


def test_negative_target_mass_rejected():
    agg = make_fine_aggregate()
    with pytest.raises(ValueError):
        correct_batch_water(agg, -10.0)
