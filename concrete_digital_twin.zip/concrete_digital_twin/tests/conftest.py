import sys
from pathlib import Path

# Make the package importable when tests are run directly (pytest usually
# handles this via rootdir insertion, but this keeps `python -m pytest`
# working from any cwd).
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.reference_plant import build_reference_plant


@pytest.fixture
def plant():
    return build_reference_plant()


@pytest.fixture
def base_inputs():
    return MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)


@pytest.fixture
def mix_result(plant, base_inputs):
    return plant.engine.design(base_inputs)
