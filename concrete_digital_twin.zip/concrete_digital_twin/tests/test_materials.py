import pytest
from pydantic import ValidationError

from concrete_digital_twin.aggregates.aggregate import make_coarse_aggregate, make_fine_aggregate
from concrete_digital_twin.core.materials import (
    Admixture,
    AdmixtureType,
    Aggregate,
    AggregateClass,
    Cement,
    CementClass,
    DataProvenance,
)


def test_cement_rejects_negative_cost():
    with pytest.raises(ValidationError):
        Cement(
            name="bad", cost_per_tonne=-1.0, embodied_carbon_kgco2e_per_tonne=100.0,
            density_kg_m3=3100, specific_gravity=3.1, cement_class=CementClass.OPC,
        )


def test_cement_rejects_impossible_specific_gravity():
    with pytest.raises(ValidationError):
        Cement(
            name="bad", cost_per_tonne=100.0, embodied_carbon_kgco2e_per_tonne=800.0,
            density_kg_m3=3100, specific_gravity=10.0, cement_class=CementClass.OPC,
        )


def test_aggregate_rejects_negative_bulk_density():
    with pytest.raises(ValidationError):
        Aggregate(
            name="bad", cost_per_tonne=10.0, embodied_carbon_kgco2e_per_tonne=2.0,
            aggregate_class=AggregateClass.FINE, bulk_density_kg_m3=-100,
            specific_gravity_ssd=2.6, absorption_pct=1.0, max_size_mm=4.0,
        )


def test_aggregate_surface_moisture_computation():
    agg = make_fine_aggregate(absorption_pct=1.0, moisture_content_pct=4.0)
    assert agg.surface_moisture_pct == pytest.approx(3.0)


def test_admixture_dosage_bounds():
    with pytest.raises(ValidationError):
        Admixture(
            name="bad", cost_per_tonne=100.0, embodied_carbon_kgco2e_per_tonne=100.0,
            admixture_type=AdmixtureType.PLASTICIZER, typical_dosage_pct_of_binder=99.0,
        )


def test_psd_must_be_monotonic():
    from concrete_digital_twin.core.materials import ParticleSizeDistribution
    with pytest.raises(ValueError):
        ParticleSizeDistribution(sieve_sizes_mm=[1, 2, 3], percent_passing=[50, 40, 90])


def test_coarse_aggregate_factory_defaults_sane():
    agg = make_coarse_aggregate()
    assert agg.max_size_mm == 20.0
    assert agg.data_provenance == DataProvenance.SIMULATED
