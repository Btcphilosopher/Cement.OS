"""
digital_twin.historian
=========================

A lightweight SQLite-backed time-series historian for sensor readings and
plant-state snapshots, giving the digital twin persistence across a
session (section 59 database / section 69 digital twin ingestion).
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .sensors import SensorReading

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sensor_readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    asset TEXT NOT NULL,
    measurement TEXT NOT NULL,
    value REAL,
    unit TEXT NOT NULL,
    quality TEXT NOT NULL,
    source TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sensor_asset_measurement ON sensor_readings(asset, measurement);
CREATE INDEX IF NOT EXISTS idx_sensor_timestamp ON sensor_readings(timestamp);
"""


@dataclass
class HistorianQueryResult:
    rows: list[SensorReading]


class Historian:
    def __init__(self, db_path: str | Path = ":memory:") -> None:
        self.db_path = str(db_path)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def record(self, reading: SensorReading) -> None:
        self._conn.execute(
            "INSERT INTO sensor_readings (timestamp, asset, measurement, value, unit, quality, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (reading.timestamp.isoformat(), reading.asset, reading.measurement, reading.value, reading.unit, reading.quality, reading.source),
        )
        self._conn.commit()

    def record_many(self, readings: list[SensorReading]) -> None:
        self._conn.executemany(
            "INSERT INTO sensor_readings (timestamp, asset, measurement, value, unit, quality, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [(r.timestamp.isoformat(), r.asset, r.measurement, r.value, r.unit, r.quality, r.source) for r in readings],
        )
        self._conn.commit()

    def query(self, asset: str | None = None, measurement: str | None = None, since: datetime | None = None, limit: int = 1000) -> list[SensorReading]:
        clauses = []
        params: list = []
        if asset is not None:
            clauses.append("asset = ?")
            params.append(asset)
        if measurement is not None:
            clauses.append("measurement = ?")
            params.append(measurement)
        if since is not None:
            clauses.append("timestamp >= ?")
            params.append(since.isoformat())
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        cursor = self._conn.execute(
            f"SELECT timestamp, asset, measurement, value, unit, quality, source FROM sensor_readings {where} ORDER BY timestamp DESC LIMIT ?",
            (*params, limit),
        )
        return [
            SensorReading(datetime.fromisoformat(ts), asset, measurement, value, unit, quality, source)
            for ts, asset, measurement, value, unit, quality, source in cursor.fetchall()
        ]

    def close(self) -> None:
        self._conn.close()
