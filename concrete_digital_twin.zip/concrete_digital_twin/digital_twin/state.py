"""
digital_twin.state
=====================

Aggregated real-time plant state (section 33/34): production rate, silo
and stockpile levels, mixer/truck status, energy, temperature, downtime,
quality -- everything the dashboard's control-centre screen needs in one
place.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ..plant.silos import Silo
from ..plant.storage import Stockpile
from ..production.dispatch import Fleet, TruckStatus


@dataclass
class PlantState:
    timestamp: datetime
    production_rate_m3_h: float
    cement_tonnes_h: float
    mixer_running: bool
    silo_levels_pct: dict[str, float]
    aggregate_levels_pct: dict[str, float]
    water_level_pct: float
    energy_kwh_per_t: float
    carbon_kgco2e_per_m3: float
    quality_pass: bool
    open_orders: int
    trucks_active: int
    trucks_total: int
    cost_per_m3: float
    downtime_minutes_today: float = 0.0

    @classmethod
    def snapshot(
        cls,
        cement_silo: Silo,
        scm_silo: Silo | None,
        fine_stockpile: Stockpile,
        coarse_stockpile: Stockpile,
        water_level_pct: float,
        fleet: Fleet,
        production_rate_m3_h: float,
        cement_tonnes_h: float,
        mixer_running: bool,
        energy_kwh_per_t: float,
        carbon_kgco2e_per_m3: float,
        quality_pass: bool,
        open_orders: int,
        cost_per_m3: float,
        downtime_minutes_today: float = 0.0,
    ) -> "PlantState":
        silo_levels = {"cement": cement_silo.level_pct}
        if scm_silo is not None:
            silo_levels["scm"] = scm_silo.level_pct
        aggregate_levels = {"fine_aggregate": fine_stockpile.level_pct, "coarse_aggregate": coarse_stockpile.level_pct}
        trucks_active = sum(1 for t in fleet.trucks if t.status != TruckStatus.IDLE)

        return cls(
            timestamp=datetime.now(),
            production_rate_m3_h=production_rate_m3_h,
            cement_tonnes_h=cement_tonnes_h,
            mixer_running=mixer_running,
            silo_levels_pct=silo_levels,
            aggregate_levels_pct=aggregate_levels,
            water_level_pct=water_level_pct,
            energy_kwh_per_t=energy_kwh_per_t,
            carbon_kgco2e_per_m3=carbon_kgco2e_per_m3,
            quality_pass=quality_pass,
            open_orders=open_orders,
            trucks_active=trucks_active,
            trucks_total=len(fleet.trucks),
            cost_per_m3=cost_per_m3,
            downtime_minutes_today=downtime_minutes_today,
        )

    def as_dashboard_dict(self) -> dict[str, str]:
        return {
            "PRODUCTION": f"{self.production_rate_m3_h:.0f} m3/h",
            "CEMENT": f"{self.cement_tonnes_h:.1f} t/h",
            "MIXER": "RUNNING" if self.mixer_running else "STOPPED",
            "SILOS": f"{self.silo_levels_pct.get('cement', 0):.0f}%",
            "ENERGY": f"{self.energy_kwh_per_t:.1f} kWh/t",
            "CARBON": f"{self.carbon_kgco2e_per_m3:.0f} kgCO2e/m3",
            "QUALITY": "PASS" if self.quality_pass else "FAIL",
            "ORDERS": f"{self.open_orders}",
            "TRUCKS": f"{self.trucks_active}/{self.trucks_total}",
            "COST": f"£{self.cost_per_m3:.2f}/m3",
        }
