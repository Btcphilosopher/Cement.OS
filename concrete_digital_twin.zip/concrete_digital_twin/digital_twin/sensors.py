"""
digital_twin.sensors
=======================

Synthetic sensor-reading generator: produces noisy, timestamped readings
for a named asset/measurement (temperature, level, power, flow), used to
exercise the historian and to stand in for real SCADA/OPC-UA tag data in
section 69 (digital twin ingestion).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
import random


@dataclass
class SensorReading:
    timestamp: datetime
    asset: str
    measurement: str
    value: float
    unit: str
    quality: str  # "good" | "uncertain" | "bad"
    source: str


class SyntheticSensor:
    def __init__(self, asset: str, measurement: str, unit: str, mean: float, std: float, source: str = "simulated_scada", rng: random.Random | None = None) -> None:
        self.asset = asset
        self.measurement = measurement
        self.unit = unit
        self.mean = mean
        self.std = std
        self.source = source
        self.rng = rng or random.Random()

    def read(self, timestamp: datetime | None = None, bad_data_probability: float = 0.01) -> SensorReading:
        timestamp = timestamp or datetime.now()
        value = self.rng.gauss(self.mean, self.std)
        quality = "good"
        if self.rng.random() < bad_data_probability:
            quality = "bad"
            value = float("nan")
        elif abs(value - self.mean) > 3 * self.std:
            quality = "uncertain"
        return SensorReading(
            timestamp=timestamp, asset=self.asset, measurement=self.measurement,
            value=value, unit=self.unit, quality=quality, source=self.source,
        )

    def read_series(self, start: datetime, interval_s: float, n: int) -> list[SensorReading]:
        return [self.read(start + timedelta(seconds=i * interval_s)) for i in range(n)]
