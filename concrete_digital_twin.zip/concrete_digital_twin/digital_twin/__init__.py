"""Digital twin: plant state aggregation, synthetic sensors, historian (time-series store)."""
