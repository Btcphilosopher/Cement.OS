"""
core.materials
===============

Pydantic material models shared across the cement, aggregate and mix-design
subsystems. Every material record carries a ``data_provenance`` tag so
downstream reports can clearly label numbers as SIMULATED / ESTIMATED /
USER_PROVIDED / VALIDATED_EXPERIMENTAL.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class DataProvenance(str, Enum):
    SIMULATED = "SIMULATED"
    ESTIMATED = "ESTIMATED"
    USER_PROVIDED = "USER_PROVIDED"
    VALIDATED_EXPERIMENTAL = "VALIDATED_EXPERIMENTAL_DATA"


class CementClass(str, Enum):
    OPC = "Ordinary Portland Cement"
    PLC = "Portland Limestone Cement"
    BFSC = "Blast Furnace Slag Cement"
    FLYASH = "Fly Ash Blended Cement"
    POZZOLANIC = "Pozzolanic Cement"
    USER_DEFINED = "User-Defined Cement"


class SCMType(str, Enum):
    SLAG = "ground granulated blast furnace slag"
    FLY_ASH = "fly ash"
    SILICA_FUME = "silica fume"
    NATURAL_POZZOLAN = "natural pozzolan"
    CALCINED_CLAY = "calcined clay"
    LIMESTONE_FILLER = "limestone filler"


class AggregateClass(str, Enum):
    FINE = "fine aggregate"
    COARSE = "coarse aggregate"
    RECYCLED = "recycled aggregate"
    MANUFACTURED_SAND = "manufactured sand"
    GRAVEL = "gravel"
    LIMESTONE = "limestone"
    GRANITE = "granite"
    SANDSTONE = "sandstone"
    USER_DEFINED = "user-defined aggregate"


class AdmixtureType(str, Enum):
    PLASTICIZER = "plasticizer"
    SUPERPLASTICIZER = "superplasticizer"
    RETARDER = "retarder"
    ACCELERATOR = "accelerator"
    AIR_ENTRAINER = "air entrainer"
    VISCOSITY_MODIFIER = "viscosity modifying agent"
    USER_DEFINED = "user-defined admixture"


class MaterialBase(BaseModel):
    """Common fields for every material record."""

    name: str
    supplier: str = "unspecified"
    availability: float = Field(
        1.0, ge=0.0, le=1.0, description="Fractional availability (0-1) used by planning/optimisation."
    )
    cost_per_tonne: float = Field(..., ge=0.0, description="Currency units per tonne (currency configurable at report level).")
    embodied_carbon_kgco2e_per_tonne: float = Field(..., ge=0.0)
    data_provenance: DataProvenance = DataProvenance.ESTIMATED

    model_config = {"use_enum_values": False}


class CementitiousMaterial(MaterialBase):
    """Cement or SCM: a binder-phase material with a density and a
    (simplified) reactivity index used by the strength/hydration models."""

    density_kg_m3: float = Field(..., gt=0, description="Absolute (particle) density, kg/m3.")
    specific_gravity: float = Field(..., gt=0)
    blaine_fineness_m2_kg: float = Field(350.0, gt=0, description="Blaine specific surface, m2/kg.")
    reactivity_index: float = Field(
        1.0, ge=0.0, le=1.5,
        description="SIMULATED relative reactivity vs. pure OPC clinker (1.0 = reference).",
    )
    water_demand_factor: float = Field(
        1.0, gt=0, description="SIMULATED multiplier on baseline water demand relative to OPC."
    )

    @field_validator("specific_gravity")
    @classmethod
    def _sg_sane(cls, v: float) -> float:
        if not (1.5 <= v <= 3.5):
            raise ValueError("specific_gravity outside plausible range [1.5, 3.5] for cementitious materials")
        return v


class Cement(CementitiousMaterial):
    cement_class: CementClass = CementClass.OPC
    clinker_factor: float = Field(0.95, ge=0.0, le=1.0, description="Mass fraction of clinker in the cement.")


class SCM(CementitiousMaterial):
    scm_type: SCMType


class ParticleSizeDistribution(BaseModel):
    """Cumulative-passing sieve analysis. Sieves in mm, passing in % (0-100)."""

    sieve_sizes_mm: list[float]
    percent_passing: list[float]

    @model_validator(mode="after")
    def _validate(self) -> "ParticleSizeDistribution":
        if len(self.sieve_sizes_mm) != len(self.percent_passing):
            raise ValueError("sieve_sizes_mm and percent_passing must be the same length")
        if len(self.sieve_sizes_mm) < 2:
            raise ValueError("need at least two sieve points")
        sizes = self.sieve_sizes_mm
        if sizes != sorted(sizes):
            raise ValueError("sieve_sizes_mm must be ascending")
        for p in self.percent_passing:
            if not (0.0 <= p <= 100.0):
                raise ValueError("percent_passing values must be within [0,100]")
        passing = self.percent_passing
        if passing != sorted(passing):
            raise ValueError("percent_passing must be non-decreasing with increasing sieve size")
        return self


class Aggregate(MaterialBase):
    aggregate_class: AggregateClass
    bulk_density_kg_m3: float = Field(..., gt=0)
    specific_gravity_ssd: float = Field(..., gt=0, description="Specific gravity at saturated-surface-dry (SSD).")
    absorption_pct: float = Field(..., ge=0.0, le=15.0, description="Absorption capacity, % of dry mass.")
    moisture_content_pct: float = Field(0.0, ge=-15.0, le=25.0, description="Actual (as-received) moisture, % of dry mass. Can be below absorption (surface-dry) or above (wet).")
    max_size_mm: float = Field(..., gt=0)
    psd: Optional[ParticleSizeDistribution] = None

    @property
    def surface_moisture_pct(self) -> float:
        """Free/surface moisture beyond SSD; negative means the aggregate is
        drier than SSD (will absorb extra mix water)."""
        return self.moisture_content_pct - self.absorption_pct


class Admixture(MaterialBase):
    admixture_type: AdmixtureType
    density_kg_m3: float = Field(1050.0, gt=0)
    typical_dosage_pct_of_binder: float = Field(..., ge=0.0, le=10.0, description="Typical dosage, % by mass of total binder.")
    water_reduction_pct: float = Field(0.0, ge=0.0, le=40.0, description="SIMULATED water-reduction capability at typical dosage.")
    set_time_shift_minutes: float = Field(0.0, description="SIMULATED shift in setting time (negative = accelerates).")
    air_entrainment_pct: float = Field(0.0, ge=0.0, le=10.0)

    @field_validator("cost_per_tonne")
    @classmethod
    def _admixture_cost_positive(cls, v: float) -> float:
        if v < 0:
            raise ValueError("cost cannot be negative")
        return v
