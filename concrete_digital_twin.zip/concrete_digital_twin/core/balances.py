"""
core.balances
==============

Mass- and water-balance checking utilities used throughout the plant and
mix-design engines. These are the backbone of the "CHECK MASS BALANCES"
discipline requested for this project: every stage that transforms
material streams should be validated with :func:`check_mass_balance`.
"""

from __future__ import annotations

from dataclasses import dataclass, field


class MassBalanceError(ValueError):
    """Raised when inputs and outputs (+ losses) do not reconcile within
    tolerance."""


@dataclass
class MassBalanceResult:
    inputs_kg: float
    outputs_kg: float
    losses_kg: float
    tolerance_kg: float
    ok: bool
    discrepancy_kg: float = field(init=False)

    def __post_init__(self) -> None:
        self.discrepancy_kg = self.inputs_kg - (self.outputs_kg + self.losses_kg)


def check_mass_balance(
    inputs_kg: float,
    outputs_kg: float,
    losses_kg: float = 0.0,
    tolerance_kg: float = 1e-6,
    raise_on_fail: bool = True,
) -> MassBalanceResult:
    """Validate that inputs == outputs + losses within an absolute tolerance.

    Parameters
    ----------
    inputs_kg, outputs_kg, losses_kg:
        Total mass flows in kg (SI). Callers are responsible for converting
        from whatever unit the stream used via ``core.units``.
    tolerance_kg:
        Absolute tolerance in kg. Defaults to a very tight numeric
        tolerance for pure calculations; process code should widen this
        (e.g. to 0.01% of throughput) for physically-measured or
        stochastic streams.
    raise_on_fail:
        If True, raises :class:`MassBalanceError` on failure. If False,
        returns a result with ``ok=False`` for the caller to handle.
    """
    if inputs_kg < 0 or outputs_kg < 0 or losses_kg < 0:
        raise ValueError("mass balance streams cannot be negative")

    discrepancy = inputs_kg - (outputs_kg + losses_kg)
    ok = abs(discrepancy) <= tolerance_kg
    result = MassBalanceResult(
        inputs_kg=inputs_kg,
        outputs_kg=outputs_kg,
        losses_kg=losses_kg,
        tolerance_kg=tolerance_kg,
        ok=ok,
    )
    if not ok and raise_on_fail:
        raise MassBalanceError(
            f"Mass balance violated: inputs={inputs_kg:.6f} kg, "
            f"outputs+losses={outputs_kg + losses_kg:.6f} kg, "
            f"discrepancy={result.discrepancy_kg:.6f} kg "
            f"(tolerance={tolerance_kg:.6f} kg)"
        )
    return result


def relative_tolerance_kg(throughput_kg: float, relative_pct: float = 0.1) -> float:
    """Convenience helper: tolerance as a percentage of throughput, with a
    small absolute floor so zero-throughput edge cases don't divide by
    zero or produce a zero tolerance."""
    return max(1e-6, throughput_kg * (relative_pct / 100.0))
