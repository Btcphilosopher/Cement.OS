"""Core primitives: units, materials, thermodynamics, chemistry, balances."""
