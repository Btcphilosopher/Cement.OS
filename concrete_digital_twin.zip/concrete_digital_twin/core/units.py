"""
core.units
==========

A small, dependency-free rigorous unit system.

Design goals
------------
* Every :class:`Quantity` remembers its **physical dimension** (mass,
  volume, pressure, temperature, energy, power, mass-flow, ...).
* All internal storage/arithmetic happens in **consistent SI base units**:
    mass        -> kg
    volume      -> m3
    pressure    -> Pa
    temperature -> K
    energy      -> J
    power       -> W
    mass CO2e   -> kg (CO2e)
    time        -> s
* Conversion to/from "display" units (tonnes, litres, MPa, kWh, degC, ...)
  is explicit -- there is no silent mixing of kg/tonnes/litres/m3.
* Arithmetic between incompatible dimensions raises :class:`UnitError`.

This is intentionally simpler than a full CAS-style unit library (e.g.
``pint``) so that it has zero external dependencies and is easy to audit,
but it enforces the same core invariant: **you cannot add kilograms to
cubic metres**.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math


MODEL_VERSION = "units-1.0"


class Dimension(str, Enum):
    MASS = "mass"                  # kg
    VOLUME = "volume"              # m3
    LENGTH = "length"              # m
    PRESSURE = "pressure"          # Pa (used for strength, MPa etc.)
    TEMPERATURE = "temperature"    # K (absolute)
    TEMPERATURE_DELTA = "dtemp"    # K (difference, allows negative)
    ENERGY = "energy"              # J
    POWER = "power"                # W
    TIME = "time"                  # s
    MASS_CO2E = "mass_co2e"        # kg CO2 equivalent
    DIMENSIONLESS = "dimensionless"
    MASS_FLOW = "mass_flow"        # kg/s
    VOLUME_FLOW = "volume_flow"    # m3/s
    DENSITY = "density"            # kg/m3


class UnitError(ValueError):
    """Raised on an invalid unit conversion or a dimensionally-unsound
    arithmetic operation (e.g. adding a mass Quantity to a volume Quantity).
    """


# ---------------------------------------------------------------------------
# Conversion tables: {unit_symbol: (dimension, factor_to_SI, offset_to_SI)}
# value_SI = value * factor_to_SI + offset_to_SI   (offset only used for degC)
# ---------------------------------------------------------------------------

_UNITS: dict[str, tuple[Dimension, float, float]] = {
    # mass
    "kg": (Dimension.MASS, 1.0, 0.0),
    "g": (Dimension.MASS, 1e-3, 0.0),
    "t": (Dimension.MASS, 1000.0, 0.0),
    "tonne": (Dimension.MASS, 1000.0, 0.0),
    "tonnes": (Dimension.MASS, 1000.0, 0.0),
    # volume
    "m3": (Dimension.VOLUME, 1.0, 0.0),
    "L": (Dimension.VOLUME, 1e-3, 0.0),
    "litre": (Dimension.VOLUME, 1e-3, 0.0),
    "litres": (Dimension.VOLUME, 1e-3, 0.0),
    "mL": (Dimension.VOLUME, 1e-6, 0.0),
    # length
    "m": (Dimension.LENGTH, 1.0, 0.0),
    "mm": (Dimension.LENGTH, 1e-3, 0.0),
    "cm": (Dimension.LENGTH, 1e-2, 0.0),
    "km": (Dimension.LENGTH, 1e3, 0.0),
    # pressure / strength
    "Pa": (Dimension.PRESSURE, 1.0, 0.0),
    "kPa": (Dimension.PRESSURE, 1e3, 0.0),
    "MPa": (Dimension.PRESSURE, 1e6, 0.0),
    "bar": (Dimension.PRESSURE, 1e5, 0.0),
    # temperature (absolute)
    "K": (Dimension.TEMPERATURE, 1.0, 0.0),
    "degC": (Dimension.TEMPERATURE, 1.0, 273.15),
    # temperature delta
    "dK": (Dimension.TEMPERATURE_DELTA, 1.0, 0.0),
    "degC_delta": (Dimension.TEMPERATURE_DELTA, 1.0, 0.0),
    # energy
    "J": (Dimension.ENERGY, 1.0, 0.0),
    "kJ": (Dimension.ENERGY, 1e3, 0.0),
    "MJ": (Dimension.ENERGY, 1e6, 0.0),
    "GJ": (Dimension.ENERGY, 1e9, 0.0),
    "kWh": (Dimension.ENERGY, 3.6e6, 0.0),
    "MWh": (Dimension.ENERGY, 3.6e9, 0.0),
    # power
    "W": (Dimension.POWER, 1.0, 0.0),
    "kW": (Dimension.POWER, 1e3, 0.0),
    "MW": (Dimension.POWER, 1e6, 0.0),
    # time
    "s": (Dimension.TIME, 1.0, 0.0),
    "min": (Dimension.TIME, 60.0, 0.0),
    "h": (Dimension.TIME, 3600.0, 0.0),
    "day": (Dimension.TIME, 86400.0, 0.0),
    # carbon
    "kgCO2e": (Dimension.MASS_CO2E, 1.0, 0.0),
    "tCO2e": (Dimension.MASS_CO2E, 1000.0, 0.0),
    # dimensionless / ratio
    "-": (Dimension.DIMENSIONLESS, 1.0, 0.0),
    "%": (Dimension.DIMENSIONLESS, 0.01, 0.0),
    # flows
    "kg/s": (Dimension.MASS_FLOW, 1.0, 0.0),
    "t/h": (Dimension.MASS_FLOW, 1000.0 / 3600.0, 0.0),
    "kg/h": (Dimension.MASS_FLOW, 1.0 / 3600.0, 0.0),
    "m3/s": (Dimension.VOLUME_FLOW, 1.0, 0.0),
    "m3/h": (Dimension.VOLUME_FLOW, 1.0 / 3600.0, 0.0),
    # density
    "kg/m3": (Dimension.DENSITY, 1.0, 0.0),
}


@dataclass(frozen=True)
class Quantity:
    """An immutable physical quantity stored internally in SI base units.

    ``value`` is always in SI (kg, m3, Pa, K, J, W, s, kgCO2e, ...);
    use :meth:`to` to obtain a value in a display unit.
    """

    si_value: float
    dimension: Dimension

    # -- construction -----------------------------------------------------
    @classmethod
    def of(cls, value: float, unit: str) -> "Quantity":
        if unit not in _UNITS:
            raise UnitError(f"Unknown unit '{unit}'. Known units: {sorted(_UNITS)}")
        dim, factor, offset = _UNITS[unit]
        return cls(si_value=value * factor + offset, dimension=dim)

    # -- conversion ---------------------------------------------------------
    def to(self, unit: str) -> float:
        if unit not in _UNITS:
            raise UnitError(f"Unknown unit '{unit}'.")
        dim, factor, offset = _UNITS[unit]
        if dim != self.dimension:
            raise UnitError(
                f"Cannot express a {self.dimension.value} quantity in "
                f"'{unit}' ({dim.value})."
            )
        return (self.si_value - offset) / factor

    # -- arithmetic -----------------------------------------------------
    def _check_same(self, other: "Quantity") -> None:
        if not isinstance(other, Quantity):
            raise UnitError("Can only operate Quantity with Quantity.")
        if self.dimension != other.dimension:
            raise UnitError(
                f"Dimension mismatch: {self.dimension.value} vs {other.dimension.value}. "
                "Refusing to silently mix incompatible units (e.g. kg with m3)."
            )

    def __add__(self, other: "Quantity") -> "Quantity":
        self._check_same(other)
        return Quantity(self.si_value + other.si_value, self.dimension)

    def __sub__(self, other: "Quantity") -> "Quantity":
        self._check_same(other)
        return Quantity(self.si_value - other.si_value, self.dimension)

    def __mul__(self, scalar: float) -> "Quantity":
        if isinstance(scalar, Quantity):
            raise UnitError(
                "Quantity * Quantity is not supported by this simplified unit "
                "system (would change dimension); operate on .si_value directly "
                "and re-wrap with the correct Dimension if you need this."
            )
        return Quantity(self.si_value * scalar, self.dimension)

    __rmul__ = __mul__

    def __truediv__(self, scalar: float) -> "Quantity":
        if isinstance(scalar, Quantity):
            if scalar.dimension != self.dimension:
                # produces a dimensionless ratio only if same dimension
                raise UnitError(
                    "Dividing quantities of different dimensions is not "
                    "supported by this simplified unit system."
                )
            return Quantity(self.si_value / scalar.si_value, Dimension.DIMENSIONLESS)
        return Quantity(self.si_value / scalar, self.dimension)

    def __neg__(self) -> "Quantity":
        return Quantity(-self.si_value, self.dimension)

    def __lt__(self, other: "Quantity") -> bool:
        self._check_same(other)
        return self.si_value < other.si_value

    def __le__(self, other: "Quantity") -> bool:
        self._check_same(other)
        return self.si_value <= other.si_value

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Quantity):
            return NotImplemented
        return self.dimension == other.dimension and math.isclose(
            self.si_value, other.si_value, rel_tol=1e-9, abs_tol=1e-12
        )

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"Quantity({self.si_value:.6g} SI[{self.dimension.value}])"


# Convenience constructors -------------------------------------------------

def kg(v: float) -> Quantity:
    return Quantity.of(v, "kg")


def tonnes(v: float) -> Quantity:
    return Quantity.of(v, "t")


def m3(v: float) -> Quantity:
    return Quantity.of(v, "m3")


def litres(v: float) -> Quantity:
    return Quantity.of(v, "L")


def mpa(v: float) -> Quantity:
    return Quantity.of(v, "MPa")


def degc(v: float) -> Quantity:
    return Quantity.of(v, "degC")


def kwh(v: float) -> Quantity:
    return Quantity.of(v, "kWh")


def kgco2e(v: float) -> Quantity:
    return Quantity.of(v, "kgCO2e")


class DisplayUnits:
    """Operator-configurable *display* preferences.

    Internal storage is always SI; this only controls what unit a report
    or dashboard renders a value in.
    """

    def __init__(
        self,
        mass: str = "kg",
        volume: str = "m3",
        pressure: str = "MPa",
        temperature: str = "degC",
        energy: str = "kWh",
        carbon: str = "kgCO2e",
    ) -> None:
        self.mass = mass
        self.volume = volume
        self.pressure = pressure
        self.temperature = temperature
        self.energy = energy
        self.carbon = carbon

    def render(self, q: Quantity) -> str:
        unit_map = {
            Dimension.MASS: self.mass,
            Dimension.VOLUME: self.volume,
            Dimension.PRESSURE: self.pressure,
            Dimension.TEMPERATURE: self.temperature,
            Dimension.ENERGY: self.energy,
            Dimension.MASS_CO2E: self.carbon,
        }
        unit = unit_map.get(q.dimension)
        if unit is None:
            return f"{q.si_value:.4g} ({q.dimension.value}, SI)"
        return f"{q.to(unit):.4g} {unit}"


DEFAULT_DISPLAY_UNITS = DisplayUnits()
