"""
core.thermodynamics
=====================

Lightweight thermal helpers shared by the kiln, hydration and curing
models: sensible heat, simple lumped-capacitance heating/cooling, and
specific heat lookups. All SIMULATED / textbook-level approximations.
"""

from __future__ import annotations

import math

# Specific heat capacities, J/(kg.K) -- approximate literature values.
SPECIFIC_HEAT_J_PER_KGK = {
    "raw_meal": 900.0,
    "clinker": 800.0,
    "cement": 840.0,
    "concrete": 1000.0,
    "water": 4186.0,
    "air": 1005.0,
    "flue_gas": 1100.0,
    "steel": 490.0,
}


def sensible_heat_j(mass_kg: float, specific_heat_j_per_kgk: float, delta_t_k: float) -> float:
    """Q = m * c * dT."""
    if mass_kg < 0:
        raise ValueError("mass_kg cannot be negative")
    return mass_kg * specific_heat_j_per_kgk * delta_t_k


def lumped_capacitance_cooling(
    t_initial_c: float,
    t_ambient_c: float,
    time_s: float,
    cooling_rate_constant_per_s: float,
) -> float:
    """Newton's law of cooling: T(t) = Tamb + (T0 - Tamb) * exp(-k t).

    Used for e.g. clinker cooler exit temperature or a curing element
    losing heat to ambient.
    """
    if cooling_rate_constant_per_s < 0:
        raise ValueError("cooling_rate_constant_per_s must be >= 0")
    return t_ambient_c + (t_initial_c - t_ambient_c) * math.exp(-cooling_rate_constant_per_s * time_s)


def adiabatic_temperature_rise_k(heat_j_per_kg_binder: float, binder_kg_per_m3: float, concrete_density_kg_m3: float) -> float:
    """Approximate adiabatic temperature rise of a concrete mass given a
    heat release (J per kg binder) and mix proportions.

    dT = (heat_j_per_kg_binder * binder_kg_per_m3) / (concrete_density_kg_m3 * c_concrete)
    """
    c = SPECIFIC_HEAT_J_PER_KGK["concrete"]
    total_heat_per_m3 = heat_j_per_kg_binder * binder_kg_per_m3
    return total_heat_per_m3 / (concrete_density_kg_m3 * c)
