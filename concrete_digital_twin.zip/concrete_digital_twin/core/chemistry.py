"""
core.chemistry
================

SIMPLIFIED cement chemistry model.

This module is NOT a rigorous thermochemical / phase-equilibrium model.
It implements textbook-standard simplified relationships that are widely
used for teaching and first-pass process simulation:

* Bogue equations for estimating clinker phase composition (C3S, C2S,
  C3A, C4AF) from bulk oxide analysis.
* Simplified relative heat-of-hydration contributions per phase (from
  Bogue-phase heat coefficients reported in the cement literature,
  approximate and material-dependent in reality).
* A simplified water-demand estimator driven by phase composition and
  fineness.

ASSUMPTIONS / LIMITATIONS (read before trusting a number):
  - Bogue equations assume the four standard clinker phases only and
    ignore minor phases (free lime, alkalis, MgO) beyond a simple cap.
  - Heat-of-hydration coefficients are widely-cited approximate literature
    values (J/g of phase, complete reaction), not measured for any
    specific plant's clinker.
  - No coupling to particle-scale diffusion; hydration KINETICS are
    handled separately in curing.hydration using a lumped Avrami-type
    model, not derived from first-principles chemistry here.

Where higher-fidelity chemistry is required, replace or extend this
module -- it is deliberately isolated so a more advanced (e.g. GEMS/
Cemdata-style thermodynamic) model can be plugged in behind the same
function signatures.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class OxideComposition:
    """Bulk oxide analysis of clinker, mass % (as typically reported by XRF)."""

    CaO: float
    SiO2: float
    Al2O3: float
    Fe2O3: float
    SO3: float = 0.0
    MgO: float = 0.0
    free_lime: float = 1.0

    def validate(self) -> None:
        total = self.CaO + self.SiO2 + self.Al2O3 + self.Fe2O3 + self.SO3 + self.MgO
        if not (85.0 <= total <= 101.0):
            raise ValueError(
                f"Oxide composition sums to {total:.1f}%, outside plausible "
                "range for Portland clinker [85, 101]%."
            )


@dataclass(frozen=True)
class ClinkerPhases:
    """Bogue-estimated clinker phase composition, mass %."""

    C3S: float
    C2S: float
    C3A: float
    C4AF: float

    @property
    def total_silicates(self) -> float:
        return self.C3S + self.C2S

    def as_dict(self) -> dict[str, float]:
        return {"C3S": self.C3S, "C2S": self.C2S, "C3A": self.C3A, "C4AF": self.C4AF}


def bogue_phases(ox: OxideComposition) -> ClinkerPhases:
    """Standard Bogue equations (ASTM C150 Annex).

    C3S = 4.071*CaO - 7.600*SiO2 - 6.718*Al2O3 - 1.430*Fe2O3 - 2.852*SO3
    C2S = 2.867*SiO2 - 0.7544*C3S
    C3A = 2.650*Al2O3 - 1.692*Fe2O3
    C4AF = 3.043*Fe2O3

    Values are clamped to >= 0 (Bogue can produce small negative numbers
    for compositions that are not truly Portland-clinker-like; this is a
    known limitation of the linear approximation).
    """

    ox.validate()
    c3s = 4.071 * ox.CaO - 7.600 * ox.SiO2 - 6.718 * ox.Al2O3 - 1.430 * ox.Fe2O3 - 2.852 * ox.SO3
    c2s = 2.867 * ox.SiO2 - 0.7544 * c3s
    c3a = 2.650 * ox.Al2O3 - 1.692 * ox.Fe2O3
    c4af = 3.043 * ox.Fe2O3

    phases = ClinkerPhases(
        C3S=max(0.0, c3s),
        C2S=max(0.0, c2s),
        C3A=max(0.0, c3a),
        C4AF=max(0.0, c4af),
    )
    return phases


# Approximate, literature-typical ultimate heat of hydration per phase
# (J/g of phase, complete reaction). SIMULATED / illustrative values.
_ULTIMATE_HEAT_J_PER_G = {
    "C3S": 500.0,
    "C2S": 260.0,
    "C3A": 866.0,
    "C4AF": 420.0,
}

# Approximate relative early-age strength contribution weighting
# (dimensionless, SIMULATED) used by curing.strength as an optional
# chemistry-aware correction.
_STRENGTH_WEIGHT = {
    "C3S": 1.00,   # dominant early/medium strength contributor
    "C2S": 0.35,   # slow, dominant late strength contributor
    "C3A": 0.25,   # fast reacting, modest strength, big heat
    "C4AF": 0.15,
}


def ultimate_heat_of_hydration_j_per_g_cement(phases: ClinkerPhases, clinker_factor: float = 1.0) -> float:
    """Estimate ultimate (t -> inf) heat of hydration per gram of CEMENT
    (not clinker), assuming clinker_factor is the mass fraction of clinker
    in the cement and the remainder (SCM/filler) does not contribute here
    (SCM heat handled separately as a smaller pozzolanic contribution in
    curing.hydration).
    """

    per_g_clinker = sum(
        (getattr(phases, k) / 100.0) * _ULTIMATE_HEAT_J_PER_G[k] for k in _ULTIMATE_HEAT_J_PER_G
    )
    return per_g_clinker * clinker_factor


def chemistry_strength_index(phases: ClinkerPhases) -> float:
    """A dimensionless SIMULATED index (roughly 0-1 scaled) summarising how
    favourable a phase composition is for strength development, used as an
    optional multiplier in curing.strength. Normalised against a typical
    'reference OPC' composition (C3S=55, C2S=18, C3A=10, C4AF=8)."""

    ref = ClinkerPhases(C3S=55.0, C2S=18.0, C3A=10.0, C4AF=8.0)
    ref_score = sum((getattr(ref, k) / 100.0) * _STRENGTH_WEIGHT[k] for k in _STRENGTH_WEIGHT)
    this_score = sum((getattr(phases, k) / 100.0) * _STRENGTH_WEIGHT[k] for k in _STRENGTH_WEIGHT)
    if ref_score == 0:
        return 1.0
    return this_score / ref_score


def water_demand_ml_per_100g(phases: ClinkerPhases, blaine_m2_kg: float) -> float:
    """SIMPLIFIED empirical water-demand estimator (normal consistency,
    mL water per 100 g cement), driven by C3A content (fast water uptake)
    and Blaine fineness (higher surface area -> higher demand).

    This is a rough teaching correlation, NOT a substitute for an actual
    EN 196-3 / ASTM C187 normal-consistency test.
    """

    baseline = 24.0  # mL/100g, typical OPC baseline
    c3a_term = 0.15 * phases.C3A
    fineness_term = 0.01 * max(0.0, blaine_m2_kg - 300.0)
    return baseline + c3a_term + fineness_term
