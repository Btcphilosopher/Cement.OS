"""
aggregates.grading
=====================

Sieve-analysis / particle-size-distribution utilities: fineness modulus,
packing density (Fuller-curve based estimate), void ratio, and target
grading-curve generation for plotting (full / target / actual / optimised).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.materials import ParticleSizeDistribution

# Standard sieve series used for fineness modulus (ASTM), mm.
FM_SIEVES_MM = [0.15, 0.3, 0.6, 1.18, 2.36, 4.75, 9.5, 19.0, 37.5]


def percent_retained(psd: ParticleSizeDistribution) -> list[float]:
    """Individual (non-cumulative) percent retained on each sieve, largest
    sieve first as conventionally tabulated."""
    passing = psd.percent_passing
    retained = []
    prev_passing = 100.0
    for p in reversed(passing):
        retained.append(prev_passing - p)
        prev_passing = p
    return retained


def fineness_modulus(psd: ParticleSizeDistribution) -> float:
    """FM = sum(cumulative % retained on standard sieves) / 100.

    Cumulative retained is interpolated (log-size) onto the standard FM
    sieve series from the supplied PSD.
    """
    sizes = np.array(psd.sieve_sizes_mm, dtype=float)
    passing = np.array(psd.percent_passing, dtype=float)
    log_sizes = np.log10(sizes)

    cum_retained_sum = 0.0
    for s in FM_SIEVES_MM:
        p = float(np.interp(np.log10(s), log_sizes, passing, left=passing[0], right=passing[-1]))
        cum_retained_sum += max(0.0, 100.0 - p)
    return cum_retained_sum / 100.0


def fuller_curve(max_size_mm: float, n: float = 0.45, points: int = 50) -> ParticleSizeDistribution:
    """Fuller-Thompson idealised maximum-density grading curve:

        P(d) = 100 * (d / D)^n

    where D is the maximum aggregate size. n=0.45-0.5 is the classic
    "0.45 power curve" used as a target/reference grading in mix design.
    """
    if max_size_mm <= 0:
        raise ValueError("max_size_mm must be positive")
    sizes = np.geomspace(0.075, max_size_mm, points)
    passing = 100.0 * (sizes / max_size_mm) ** n
    passing = np.clip(passing, 0, 100)
    return ParticleSizeDistribution(sieve_sizes_mm=list(sizes), percent_passing=list(passing))


def blend_psds(psds: list[ParticleSizeDistribution], mass_fractions: list[float], common_sieves_mm: list[float] | None = None) -> ParticleSizeDistribution:
    """Combine several aggregate PSDs (e.g. fine + coarse) at given mass
    fractions into a single combined grading curve, interpolated onto a
    common sieve series."""
    if abs(sum(mass_fractions) - 1.0) > 1e-6:
        raise ValueError("mass_fractions must sum to 1.0")
    if len(psds) != len(mass_fractions):
        raise ValueError("psds and mass_fractions must be the same length")

    if common_sieves_mm is None:
        all_sizes = sorted({s for psd in psds for s in psd.sieve_sizes_mm})
        common_sieves_mm = all_sizes

    combined_passing = np.zeros(len(common_sieves_mm))
    for psd, frac in zip(psds, mass_fractions):
        sizes = np.log10(np.array(psd.sieve_sizes_mm, dtype=float))
        passing = np.array(psd.percent_passing, dtype=float)
        interp = np.interp(np.log10(common_sieves_mm), sizes, passing, left=0.0, right=100.0)
        combined_passing += frac * interp

    return ParticleSizeDistribution(sieve_sizes_mm=list(common_sieves_mm), percent_passing=list(combined_passing))


@dataclass
class PackingEstimate:
    packing_density: float  # fraction of total volume occupied by solids (0-1)
    void_ratio: float


def estimate_packing_density(psd: ParticleSizeDistribution, particle_shape_factor: float = 1.0) -> PackingEstimate:
    """SIMPLIFIED packing-density estimate based on the closeness of the
    given grading to the ideal Fuller curve (n=0.45): the closer the fit
    (lower RMS deviation), the higher the assumed packing density.

    This is a coarse heuristic (NOT a full particle-packing model such as
    the Compressible Packing Model / Toufar model) intended for relative
    comparison between grading curves within this simulator.
    """
    max_size = psd.sieve_sizes_mm[-1]
    target = fuller_curve(max_size)
    log_sizes = np.log10(psd.sieve_sizes_mm)
    target_interp = np.interp(
        log_sizes, np.log10(target.sieve_sizes_mm), target.percent_passing
    )
    actual = np.array(psd.percent_passing)
    rms_dev = float(np.sqrt(np.mean((actual - target_interp) ** 2)))

    # Baseline packing density for a well-graded aggregate ~0.80-0.85;
    # degrade with RMS deviation from ideal Fuller curve and shape factor.
    baseline = 0.83
    packing_density = baseline * particle_shape_factor - 0.0025 * rms_dev
    packing_density = max(0.55, min(0.90, packing_density))
    void_ratio = (1.0 - packing_density) / packing_density
    return PackingEstimate(packing_density=packing_density, void_ratio=void_ratio)
