"""
aggregates.moisture
=====================

SSD (saturated-surface-dry) moisture correction. Every batch water
calculation in this simulator MUST route through here so that wet or dry
aggregates automatically correct the added mix water and total aggregate
mass -- this is the "make the calculation visible to the operator"
requirement from the spec.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.materials import Aggregate


@dataclass
class MoistureCorrection:
    aggregate_name: str
    ssd_mass_kg: float               # target SSD (design) mass
    surface_moisture_pct: float      # moisture_content - absorption
    free_water_contribution_kg: float  # water carried on the aggregate surface (+ve = wet, -ve = dry)
    batch_mass_as_received_kg: float   # actual mass to weigh out (SSD mass adjusted for moisture)
    water_absorbed_by_dry_aggregate_kg: float  # water the aggregate will pull from the mix if drier than SSD

    def explanation(self) -> str:
        if self.surface_moisture_pct > 0:
            return (
                f"{self.aggregate_name} is WET: {self.surface_moisture_pct:.2f}% surface moisture "
                f"contributes {self.free_water_contribution_kg:.2f} kg of free water to the mix. "
                f"Batch water is REDUCED by this amount; batched aggregate mass is INCREASED to "
                f"{self.batch_mass_as_received_kg:.2f} kg (as-received) to still deliver "
                f"{self.ssd_mass_kg:.2f} kg SSD of solids."
            )
        elif self.surface_moisture_pct < 0:
            return (
                f"{self.aggregate_name} is DRIER THAN SSD by {-self.surface_moisture_pct:.2f}%: it will "
                f"ABSORB {self.water_absorbed_by_dry_aggregate_kg:.2f} kg of mix water. Batch water is "
                f"INCREASED by this amount; batched aggregate mass is DECREASED to "
                f"{self.batch_mass_as_received_kg:.2f} kg (as-received)."
            )
        return f"{self.aggregate_name} is at SSD: no water correction required."


def correct_batch_water(aggregate: Aggregate, ssd_target_mass_kg: float) -> MoistureCorrection:
    """Compute the moisture correction for a single aggregate.

    Design (mix) proportions are normally expressed on an SSD basis.
    Given the aggregate's actual (as-received) moisture content, this
    calculates:

      * the as-received mass to weigh out so that the SSD-equivalent
        solids mass matches the design target
      * the free-water contribution (positive) or absorption demand
        (negative contribution / extra water needed) that must be
        added/subtracted from the mix water
    """
    if ssd_target_mass_kg < 0:
        raise ValueError("ssd_target_mass_kg cannot be negative")

    surface_pct = aggregate.surface_moisture_pct  # moisture - absorption

    # As-received mass = SSD mass * (1 + surface_moisture_fraction)
    # (SSD mass already includes absorbed water; surface water is extra mass on top)
    as_received_mass_kg = ssd_target_mass_kg * (1.0 + surface_pct / 100.0)

    free_water_kg = 0.0
    absorbed_kg = 0.0
    if surface_pct > 0:
        free_water_kg = ssd_target_mass_kg * (surface_pct / 100.0)
    elif surface_pct < 0:
        absorbed_kg = ssd_target_mass_kg * (-surface_pct / 100.0)

    return MoistureCorrection(
        aggregate_name=aggregate.name,
        ssd_mass_kg=ssd_target_mass_kg,
        surface_moisture_pct=surface_pct,
        free_water_contribution_kg=free_water_kg,
        batch_mass_as_received_kg=as_received_mass_kg,
        water_absorbed_by_dry_aggregate_kg=absorbed_kg,
    )


def net_water_adjustment_kg(corrections: list[MoistureCorrection]) -> float:
    """Net adjustment to ADDED mix water across all aggregates: positive
    free water REDUCES added water, absorption INCREASES added water."""
    return sum(c.water_absorbed_by_dry_aggregate_kg - c.free_water_contribution_kg for c in corrections)
