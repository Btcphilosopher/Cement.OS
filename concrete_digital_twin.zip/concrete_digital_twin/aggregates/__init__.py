"""Aggregate processing: quarry -> crushing -> screening -> grading -> moisture."""
