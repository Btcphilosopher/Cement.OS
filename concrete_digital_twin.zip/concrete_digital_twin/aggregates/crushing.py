"""
aggregates.crushing
======================

Simplified crusher model: reduction ratio and a Rosin-Rammler style output
particle-size distribution as a function of the closed-side setting (CSS).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.balances import check_mass_balance, relative_tolerance_kg
from ..core.materials import ParticleSizeDistribution


@dataclass
class CrusherOutputs:
    product_kg_h: float
    fines_kg_h: float  # material below CSS considered "fines"/dust generated
    reduction_ratio: float
    psd: ParticleSizeDistribution
    power_kw: float


class JawCrusher:
    """Simplified primary/secondary crusher.

    Product top-size ~= closed-side setting (CSS). Product PSD approximated
    with a Rosin-Rammler distribution: P(d) = 100 * (1 - exp(-(d/d63.2)^m))
    """

    def __init__(self, capacity_kg_h: float, css_mm: float, rr_uniformity_m: float = 1.4, specific_energy_kwh_per_t: float = 1.2) -> None:
        if capacity_kg_h <= 0 or css_mm <= 0:
            raise ValueError("capacity_kg_h and css_mm must be positive")
        self.capacity_kg_h = capacity_kg_h
        self.css_mm = css_mm
        self.rr_uniformity_m = rr_uniformity_m
        self.specific_energy_kwh_per_t = specific_energy_kwh_per_t

    def simulate(self, feed_kg_h: float, feed_top_size_mm: float, fines_fraction: float = 0.03) -> CrusherOutputs:
        if feed_kg_h <= 0:
            raise ValueError("feed_kg_h must be positive")
        if feed_kg_h > self.capacity_kg_h:
            raise ValueError(f"feed {feed_kg_h:.0f} kg/h exceeds crusher capacity {self.capacity_kg_h:.0f} kg/h")
        if feed_top_size_mm <= self.css_mm:
            raise ValueError("feed_top_size_mm must exceed the closed-side setting to require crushing")

        fines_kg_h = feed_kg_h * fines_fraction
        product_kg_h = feed_kg_h - fines_kg_h

        check_mass_balance(
            inputs_kg=feed_kg_h,
            outputs_kg=product_kg_h,
            losses_kg=fines_kg_h,
            tolerance_kg=relative_tolerance_kg(feed_kg_h, 0.01),
        )

        d63_2 = self.css_mm * 1.15  # characteristic size slightly above CSS
        sizes = np.geomspace(max(0.1, self.css_mm * 0.1), feed_top_size_mm, 30)
        passing = 100.0 * (1.0 - np.exp(-((sizes / d63_2) ** self.rr_uniformity_m)))
        passing = np.clip(passing, 0, 100)
        psd = ParticleSizeDistribution(sieve_sizes_mm=list(sizes), percent_passing=list(passing))

        reduction_ratio = feed_top_size_mm / self.css_mm
        power_kw = self.specific_energy_kwh_per_t * (feed_kg_h / 1000.0)

        return CrusherOutputs(
            product_kg_h=product_kg_h,
            fines_kg_h=fines_kg_h,
            reduction_ratio=reduction_ratio,
            psd=psd,
            power_kw=power_kw,
        )
