"""
aggregates.screening
=======================

Vibrating-screen model: splits an incoming stream into oversize/undersize
fractions at a cut size, with a configurable screening efficiency.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.balances import check_mass_balance, relative_tolerance_kg
from ..core.materials import ParticleSizeDistribution


@dataclass
class ScreenOutputs:
    oversize_kg_h: float
    undersize_kg_h: float
    misplaced_kg_h: float  # material that ends up on the "wrong" side of the cut, due to <100% efficiency


class VibratingScreen:
    def __init__(self, cut_size_mm: float, efficiency: float = 0.90) -> None:
        if cut_size_mm <= 0:
            raise ValueError("cut_size_mm must be positive")
        if not (0.0 < efficiency <= 1.0):
            raise ValueError("efficiency must be within (0,1]")
        self.cut_size_mm = cut_size_mm
        self.efficiency = efficiency

    def simulate(self, feed_kg_h: float, feed_psd: ParticleSizeDistribution) -> ScreenOutputs:
        if feed_kg_h <= 0:
            raise ValueError("feed_kg_h must be positive")

        sizes = np.array(feed_psd.sieve_sizes_mm, dtype=float)
        passing = np.array(feed_psd.percent_passing, dtype=float)
        pct_undersize_ideal = float(np.interp(np.log10(self.cut_size_mm), np.log10(sizes), passing, left=passing[0], right=passing[-1]))

        ideal_undersize_kg_h = feed_kg_h * (pct_undersize_ideal / 100.0)
        ideal_oversize_kg_h = feed_kg_h - ideal_undersize_kg_h

        # Effective split: `efficiency` fraction of each ideal stream reports
        # to its correct side; the remainder is misrouted evenly to the
        # other side (SIMPLIFIED efficiency model).
        misplaced_kg_h = (ideal_undersize_kg_h + ideal_oversize_kg_h) * (1.0 - self.efficiency) * 0.5
        undersize_kg_h = ideal_undersize_kg_h * self.efficiency + ideal_oversize_kg_h * (1 - self.efficiency) * 0.5
        oversize_kg_h = feed_kg_h - undersize_kg_h

        check_mass_balance(
            inputs_kg=feed_kg_h,
            outputs_kg=undersize_kg_h + oversize_kg_h,
            losses_kg=0.0,
            tolerance_kg=relative_tolerance_kg(feed_kg_h, 0.01),
        )

        return ScreenOutputs(
            oversize_kg_h=oversize_kg_h,
            undersize_kg_h=undersize_kg_h,
            misplaced_kg_h=misplaced_kg_h,
        )
