"""
aggregates.aggregate
======================

Convenience factory functions for building common :class:`~core.materials.Aggregate`
records (fine sand, coarse gravel/granite, recycled, manufactured sand),
and standard size-fraction bins used across the aggregate plant.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.materials import Aggregate, AggregateClass, DataProvenance, ParticleSizeDistribution

# Standard configurable size fractions (mm), matching section 10 of the spec.
STANDARD_SIZE_FRACTIONS_MM: tuple[tuple[float, float], ...] = (
    (0.0, 2.0),
    (2.0, 4.0),
    (4.0, 8.0),
    (8.0, 16.0),
    (16.0, 32.0),
)


@dataclass(frozen=True)
class SizeFraction:
    lower_mm: float
    upper_mm: float
    mass_fraction: float  # fraction of total stockpile mass in this bin

    def __post_init__(self) -> None:
        if self.lower_mm < 0 or self.upper_mm <= self.lower_mm:
            raise ValueError("invalid size fraction bounds")
        if not (0.0 <= self.mass_fraction <= 1.0):
            raise ValueError("mass_fraction must be within [0,1]")


def make_fine_aggregate(
    name: str = "River Sand 0-4mm",
    supplier: str = "Northshire Quarry",
    cost_per_tonne: float = 12.0,
    embodied_carbon_kgco2e_per_tonne: float = 2.5,
    bulk_density_kg_m3: float = 1650.0,
    specific_gravity_ssd: float = 2.65,
    absorption_pct: float = 1.2,
    moisture_content_pct: float = 4.5,
    psd: ParticleSizeDistribution | None = None,
) -> Aggregate:
    return Aggregate(
        name=name,
        supplier=supplier,
        cost_per_tonne=cost_per_tonne,
        embodied_carbon_kgco2e_per_tonne=embodied_carbon_kgco2e_per_tonne,
        data_provenance=DataProvenance.SIMULATED,
        aggregate_class=AggregateClass.FINE,
        bulk_density_kg_m3=bulk_density_kg_m3,
        specific_gravity_ssd=specific_gravity_ssd,
        absorption_pct=absorption_pct,
        moisture_content_pct=moisture_content_pct,
        max_size_mm=4.0,
        psd=psd or ParticleSizeDistribution(
            sieve_sizes_mm=[0.15, 0.3, 0.6, 1.18, 2.36, 4.75],
            percent_passing=[8, 20, 42, 65, 85, 100],
        ),
    )


def make_coarse_aggregate(
    name: str = "Granite 4-20mm",
    supplier: str = "Northshire Quarry",
    cost_per_tonne: float = 14.0,
    embodied_carbon_kgco2e_per_tonne: float = 3.0,
    bulk_density_kg_m3: float = 1550.0,
    specific_gravity_ssd: float = 2.70,
    absorption_pct: float = 0.8,
    moisture_content_pct: float = 1.0,
    max_size_mm: float = 20.0,
    aggregate_class: AggregateClass = AggregateClass.GRANITE,
    psd: ParticleSizeDistribution | None = None,
) -> Aggregate:
    return Aggregate(
        name=name,
        supplier=supplier,
        cost_per_tonne=cost_per_tonne,
        embodied_carbon_kgco2e_per_tonne=embodied_carbon_kgco2e_per_tonne,
        data_provenance=DataProvenance.SIMULATED,
        aggregate_class=aggregate_class,
        bulk_density_kg_m3=bulk_density_kg_m3,
        specific_gravity_ssd=specific_gravity_ssd,
        absorption_pct=absorption_pct,
        moisture_content_pct=moisture_content_pct,
        max_size_mm=max_size_mm,
        psd=psd or ParticleSizeDistribution(
            sieve_sizes_mm=[4.75, 9.5, 12.5, 19.0, 25.0],
            percent_passing=[2, 25, 55, 95, 100],
        ),
    )


def make_recycled_aggregate(
    name: str = "Recycled Concrete Aggregate 4-20mm",
    cost_per_tonne: float = 8.0,
    embodied_carbon_kgco2e_per_tonne: float = 1.5,
) -> Aggregate:
    return Aggregate(
        name=name,
        supplier="Northshire Recycling Yard",
        cost_per_tonne=cost_per_tonne,
        embodied_carbon_kgco2e_per_tonne=embodied_carbon_kgco2e_per_tonne,
        data_provenance=DataProvenance.SIMULATED,
        aggregate_class=AggregateClass.RECYCLED,
        bulk_density_kg_m3=1350.0,
        specific_gravity_ssd=2.45,
        absorption_pct=5.5,
        moisture_content_pct=6.0,
        max_size_mm=20.0,
        psd=ParticleSizeDistribution(
            sieve_sizes_mm=[4.75, 9.5, 12.5, 19.0, 25.0],
            percent_passing=[3, 28, 58, 96, 100],
        ),
    )
