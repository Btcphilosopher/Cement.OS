"""
reference_plant
=================

A single, shared, entirely FICTIONAL example plant -- "Northshire Concrete
Works" (section 66) -- used by the examples, API and dashboard so they all
exercise the same consistent set of materials and equipment.

Capacity: 150 m3/hour | Mixer: 4 m3 | Cement silo: 500 t |
Aggregate storage: 5,000 t | Fleet: 30 trucks.

All data below is SIMULATED / illustrative and does not describe any real
company, quarry or product.
"""

from __future__ import annotations

from dataclasses import dataclass

from .aggregates.aggregate import make_coarse_aggregate, make_fine_aggregate
from .core.materials import Admixture, AdmixtureType, Cement, CementClass, DataProvenance, SCM, SCMType
from .mix_design.admixtures import AdmixtureDose
from .mix_design.mix import MixDesignEngine
from .plant.mixers import MixerEquipment
from .plant.silos import Silo
from .plant.storage import Stockpile
from .production.batching import BatchPlant, WeighHopper
from .production.dispatch import Fleet, Truck

PLANT_NAME = "Northshire Concrete Works"
PLANT_CAPACITY_M3_H = 150.0
MIXER_CAPACITY_M3 = 4.0
CEMENT_SILO_CAPACITY_T = 500.0
AGGREGATE_STORAGE_CAPACITY_T = 5000.0
FLEET_SIZE = 30
TRUCK_CAPACITY_M3 = 6.0


def reference_cement() -> Cement:
    return Cement(
        name="Northshire CEM II/A-LL 42.5N",
        supplier="Northshire Cement Works",
        cost_per_tonne=95.0,
        embodied_carbon_kgco2e_per_tonne=740.0,
        data_provenance=DataProvenance.SIMULATED,
        density_kg_m3=3100.0,
        specific_gravity=3.10,
        blaine_fineness_m2_kg=390.0,
        reactivity_index=1.0,
        water_demand_factor=1.0,
        cement_class=CementClass.PLC,
        clinker_factor=0.90,
    )


def reference_scm() -> SCM:
    return SCM(
        name="Fly Ash (Class F equivalent)",
        supplier="Riverside Power Station",
        cost_per_tonne=35.0,
        embodied_carbon_kgco2e_per_tonne=27.0,
        data_provenance=DataProvenance.SIMULATED,
        density_kg_m3=2200.0,
        specific_gravity=2.20,
        blaine_fineness_m2_kg=380.0,
        reactivity_index=0.45,
        water_demand_factor=0.93,
        scm_type=SCMType.FLY_ASH,
    )


def reference_superplasticizer() -> Admixture:
    return Admixture(
        name="Northshire SP-40 Superplasticizer",
        supplier="Northshire Admixtures Ltd",
        cost_per_tonne=1450.0,
        embodied_carbon_kgco2e_per_tonne=950.0,
        data_provenance=DataProvenance.SIMULATED,
        admixture_type=AdmixtureType.SUPERPLASTICIZER,
        density_kg_m3=1080.0,
        typical_dosage_pct_of_binder=0.8,
        water_reduction_pct=18.0,
        set_time_shift_minutes=-10.0,
        air_entrainment_pct=0.5,
    )


@dataclass
class ReferencePlant:
    engine: MixDesignEngine
    batch_plant: BatchPlant
    mixer: MixerEquipment
    fleet: Fleet


def build_reference_plant(admixture_dosage_pct: float = 0.8) -> ReferencePlant:
    cement = reference_cement()
    scm = reference_scm()
    fine = make_fine_aggregate()
    coarse = make_coarse_aggregate()
    admixture = reference_superplasticizer()
    dose = AdmixtureDose(admixture=admixture, dosage_pct_of_binder=admixture_dosage_pct)

    engine = MixDesignEngine(
        cement=cement, fine_aggregate=fine, coarse_aggregate=coarse, scm=scm, admixture_doses=[dose],
    )

    cement_silo = Silo(
        name="Cement Silo 1", capacity=CEMENT_SILO_CAPACITY_T * 1000, material_name="cement",
        level_kg=CEMENT_SILO_CAPACITY_T * 1000 * 0.7, reorder_level_kg=CEMENT_SILO_CAPACITY_T * 1000 * 0.15,
        mtbf_hours=8000, mttr_hours=4,
    )
    scm_silo = Silo(
        name="Fly Ash Silo 1", capacity=150_000, material_name="fly_ash",
        level_kg=150_000 * 0.6, reorder_level_kg=150_000 * 0.15, mtbf_hours=8000, mttr_hours=4,
    )
    fine_stockpile = Stockpile(
        name="Sand Stockpile", capacity=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.4, material_name="fine_aggregate",
        level_kg=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.4 * 0.65, reorder_level_kg=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.4 * 0.15,
        mtbf_hours=20000, mttr_hours=2,
    )
    coarse_stockpile = Stockpile(
        name="Coarse Aggregate Stockpile", capacity=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.6, material_name="coarse_aggregate",
        level_kg=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.6 * 0.65, reorder_level_kg=AGGREGATE_STORAGE_CAPACITY_T * 1000 * 0.6 * 0.15,
        mtbf_hours=20000, mttr_hours=2,
    )

    batch_plant = BatchPlant(
        cement_silo=cement_silo, scm_silo=scm_silo,
        fine_agg_stockpile=fine_stockpile, coarse_agg_stockpile=coarse_stockpile,
        fine_aggregate=fine, coarse_aggregate=coarse,
        cement_hopper=WeighHopper("cement_hopper", capacity_kg=2000, systematic_error_pct=-0.2),
        aggregate_hopper=WeighHopper("aggregate_hopper", capacity_kg=8000, systematic_error_pct=0.1),
        water_hopper=WeighHopper("water_hopper", capacity_kg=1000, random_error_std_pct=0.3),
        admixture_hopper=WeighHopper("admixture_hopper", capacity_kg=50, random_error_std_pct=1.0),
    )

    mixer = MixerEquipment(name="Twin-Shaft Mixer 1", capacity=MIXER_CAPACITY_M3, rated_power_kw=90.0, mtbf_hours=5000, mttr_hours=6)

    fleet = Fleet(trucks=[Truck(truck_id=f"NC-{i+1:02d}", capacity_m3=TRUCK_CAPACITY_M3) for i in range(FLEET_SIZE)])

    return ReferencePlant(engine=engine, batch_plant=batch_plant, mixer=mixer, fleet=fleet)
