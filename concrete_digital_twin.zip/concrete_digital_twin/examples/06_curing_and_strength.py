#!/usr/bin/env python
"""
Example 06: Curing, hydration & strength development
========================================================

Demonstrates: curing.hydration, curing.temperature (semi-adiabatic
temperature simulation across curing regimes), curing.strength (age-based
strength development), curing.maturity (Nurse-Saul / equivalent age).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import numpy as np

from concrete_digital_twin.cement.raw_materials import default_raw_meal_blend
from concrete_digital_twin.core.chemistry import bogue_phases
from concrete_digital_twin.curing.maturity import equivalent_age_hours, nurse_saul_maturity_c_hours
from concrete_digital_twin.curing.strength import CementSpeedClass, strength_development_curve
from concrete_digital_twin.curing.temperature import CuringRegime, simulate_curing_temperature
from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.reference_plant import build_reference_plant


def main() -> None:
    plant = build_reference_plant()
    result = plant.engine.design(MixDesignInputs(target_strength_mpa=40.0, slump_mm=100.0))
    blend = default_raw_meal_blend()
    phases = bogue_phases(blend.blended_oxides_ignited_basis())

    print("STEP 1: Strength development curve (SIMULATION)")
    curve = strength_development_curve(result.predicted_28d_strength_mpa, CementSpeedClass.NORMAL)
    for age, s in zip(curve.ages_days, curve.strengths_mpa):
        print(f"  Day {age:>3.0f}: {s:5.1f} MPa")

    print("\nSTEP 2: Curing temperature simulation across regimes (SIMULATION)")
    t = np.linspace(0, 72, 30)
    for regime in CuringRegime:
        history = simulate_curing_temperature(t, wcm=result.wcm_ratio, phases=phases, cement_content_kg_m3=result.cement_kg, regime=regime)
        print(f"  {regime.value:15s}: peak temperature {history.temperature_c.max():5.1f} degC, "
              f"degree of hydration at 72h = {history.degree_of_hydration[-1]*100:4.1f}%")

    print("\nSTEP 3: Nurse-Saul maturity and Arrhenius equivalent age")
    temps = np.full(30, 25.0)
    times = np.linspace(0, 168, 30)
    maturity = nurse_saul_maturity_c_hours(temps, times)
    te = equivalent_age_hours(temps, times)
    print(f"  Maturity at 168h: {maturity[-1]:.0f} degC-hours")
    print(f"  Equivalent age at 168h (25 degC curing, 20 degC reference): {te[-1]:.1f} h")


if __name__ == "__main__":
    main()
