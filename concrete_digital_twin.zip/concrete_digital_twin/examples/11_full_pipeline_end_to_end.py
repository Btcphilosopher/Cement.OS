#!/usr/bin/env python
"""
Example 11: Full end-to-end pipeline
=======================================

RAW MATERIALS -> CEMENT -> AGGREGATES -> MIX DESIGN -> OPTIMISATION ->
BATCHING -> MIXING -> TRUCK -> PLACEMENT -> CURING -> STRENGTH -> QUALITY
-> COST -> CARBON -> OPTIMISATION (section 70's full walk-through).
"""

import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.cement.raw_materials import default_raw_meal_blend
from concrete_digital_twin.core.chemistry import bogue_phases
from concrete_digital_twin.curing.strength import strength_development_curve
from concrete_digital_twin.economics.material_cost import mix_material_cost_per_m3
from concrete_digital_twin.environment.carbon import mix_carbon_kgco2e_per_m3
from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.optimisation.optimizer import RecipeConstraints, search_recipes
from concrete_digital_twin.production.dispatch import Order, simulate_delivery
from concrete_digital_twin.production.mixing import Mixer
from concrete_digital_twin.quality.qc import QualityControlEngine, default_concrete_qc_specs
from concrete_digital_twin.quality.sampling import SampleHistory, generate_batch_samples
from concrete_digital_twin.reference_plant import build_reference_plant


def main() -> None:
    print("### 1. RAW MATERIALS -> CEMENT ###")
    plant = build_reference_plant()
    blend = default_raw_meal_blend()
    phases = bogue_phases(blend.blended_oxides_ignited_basis())
    print(f"Clinker phases: {phases.as_dict()}")
    print(f"Cement in use: {plant.engine.cement.name} (clinker factor {plant.engine.cement.clinker_factor:.2f})")

    print("\n### 2. AGGREGATES ###")
    print(f"Fine aggregate: {plant.engine.fine_aggregate.name}")
    print(f"Coarse aggregate: {plant.engine.coarse_aggregate.name}")

    print("\n### 3. MIX DESIGN ###")
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=120.0, scm_fraction_of_binder=0.2)
    result = plant.engine.design(base_inputs)
    print(result.summary())

    print("\n### 4. OPTIMISATION ###")
    report = search_recipes(plant.engine, base_inputs, RecipeConstraints(max_carbon_kgco2e_per_m3=250), n_candidates=1500)
    print(f"Found {report.n_feasible} feasible recipes; best balanced pick: cost=£{report.balanced['cost_per_m3']:.2f}/m3, carbon={report.balanced['carbon_kgco2e_per_m3']:.0f} kgCO2e/m3")

    print("\n### 5. BATCHING ###")
    batch_record = plant.batch_plant.batch("B-99001", "MIX-DEMO", result, volume_m3=6.0)
    print(f"Shortages: {batch_record.shortages or 'none'}")

    print("\n### 6. MIXING ###")
    mixer = Mixer(plant.mixer)
    mixing_result = mixer.mix(batch_volume_m3=4.0, ambient_temp_c=20.0)
    print(f"Uniformity index: {mixing_result.uniformity_index:.3f}")

    print("\n### 7. TRUCK & PLACEMENT ###")
    truck = plant.fleet.dispatch(Order("O-001", "Riverside Development Ltd", "MIX-DEMO", 6.0, distance_km=12.0, requested_time=datetime.now()))
    delivery = simulate_delivery(
        batch_number="B-99001", truck=truck, mix_id="MIX-DEMO", customer="Riverside Development Ltd",
        production_time=datetime.now(), distance_km=12.0, initial_slump_mm=base_inputs.slump_mm,
    )
    print(f"Arrival slump: {delivery.arrival_slump_mm:.0f} mm (initial {delivery.initial_slump_mm:.0f} mm)")
    print(f"Travel time: {delivery.travel_time_min:.0f} min   CO2: {delivery.co2_kgco2e:.1f} kg")

    print("\n### 8. CURING -> STRENGTH ###")
    curve = strength_development_curve(result.predicted_28d_strength_mpa)
    print(f"7-day: {curve.strengths_mpa[2]:.1f} MPa   28-day: {curve.strengths_mpa[3]:.1f} MPa")

    print("\n### 9. QUALITY ###")
    history = SampleHistory()
    for s in generate_batch_samples("B-99001", datetime.now(), base_inputs.slump_mm, result.air_content_pct, result.density_kg_m3, curve.strengths_mpa[2], curve.strengths_mpa[3]):
        history.add(s)
    qc = QualityControlEngine(default_concrete_qc_specs(base_inputs.slump_mm, result.air_content_pct, result.density_kg_m3, base_inputs.target_strength_mpa))
    overall = qc.overall_pass(history)
    print(f"Overall QC pass: {overall}")

    print("\n### 10. COST -> CARBON ###")
    cost = mix_material_cost_per_m3(result, plant.engine)
    carbon = mix_carbon_kgco2e_per_m3(result, plant.engine)
    print(f"Cost: £{cost:.2f}/m3   Carbon: {carbon:.0f} kgCO2e/m3")

    print("\nPipeline complete. All figures above are SIMULATED / ESTIMATED.")


if __name__ == "__main__":
    main()
