#!/usr/bin/env python
"""
Example 01: Material database
================================

Loads the material database (data/materials/materials.yaml) and prints a
summary table. Demonstrates: core.materials Pydantic validation, and how
material records carry a data_provenance tag (SIMULATED / ESTIMATED /
USER_PROVIDED / VALIDATED_EXPERIMENTAL_DATA).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import yaml

from concrete_digital_twin.core.materials import (
    Admixture,
    AdmixtureType,
    Aggregate,
    AggregateClass,
    Cement,
    CementClass,
    SCM,
    SCMType,
)

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "materials" / "materials.yaml"


def main() -> None:
    with open(DATA_FILE) as f:
        data = yaml.safe_load(f)

    print("=" * 70)
    print("CEMENTS")
    print("=" * 70)
    for row in data["cements"]:
        row = dict(row)
        row["cement_class"] = CementClass(row["cement_class"])
        cement = Cement(**row)
        print(f"  {cement.name:40s} | {cement.cost_per_tonne:7.2f}/t | {cement.embodied_carbon_kgco2e_per_tonne:6.1f} kgCO2e/t | [{cement.data_provenance.value}]")

    print("\n" + "=" * 70)
    print("SUPPLEMENTARY CEMENTITIOUS MATERIALS")
    print("=" * 70)
    for row in data["scms"]:
        row = dict(row)
        row["scm_type"] = SCMType(row["scm_type"])
        scm = SCM(**row)
        print(f"  {scm.name:40s} | {scm.cost_per_tonne:7.2f}/t | {scm.embodied_carbon_kgco2e_per_tonne:6.1f} kgCO2e/t | [{scm.data_provenance.value}]")

    print("\n" + "=" * 70)
    print("AGGREGATES")
    print("=" * 70)
    for kind in ("fine", "coarse"):
        for row in data["aggregates"][kind]:
            row = dict(row)
            row["aggregate_class"] = AggregateClass(row["aggregate_class"])
            agg = Aggregate(**row)
            print(f"  [{kind:6s}] {agg.name:40s} | {agg.cost_per_tonne:6.2f}/t | surface moisture {agg.surface_moisture_pct:+.1f}%")

    print("\n" + "=" * 70)
    print("ADMIXTURES")
    print("=" * 70)
    for row in data["admixtures"]:
        row = dict(row)
        row["admixture_type"] = AdmixtureType(row["admixture_type"])
        admix = Admixture(**row)
        print(f"  {admix.name:40s} | dose {admix.typical_dosage_pct_of_binder:.2f}% | water reduction {admix.water_reduction_pct:.0f}%")

    print("\nAll data above is loaded via Pydantic models that reject invalid")
    print("units, negative masses, impossible densities, etc. (section 60).")


if __name__ == "__main__":
    main()
