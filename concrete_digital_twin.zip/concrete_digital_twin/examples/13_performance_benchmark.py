#!/usr/bin/env python
"""
Example 13: Performance benchmark
====================================

Benchmarks mix-design throughput at 1 / 100 / 1,000 / 10,000 mixes, and
the recipe optimiser's candidate-generation rate up to ~200,000
candidates (section 63). The full absolute-volume mix design routes
through Pydantic validation each call, so this also demonstrates the
overhead of "always validate" (section 60) at scale.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.optimisation.optimizer import generate_candidate_mixes
from concrete_digital_twin.reference_plant import build_reference_plant


def benchmark_mix_design(plant, n: int) -> float:
    start = time.perf_counter()
    for i in range(n):
        inputs = MixDesignInputs(target_strength_mpa=25.0 + (i % 40), slump_mm=75.0 + (i % 100))
        plant.engine.design(inputs)
    return time.perf_counter() - start


def main() -> None:
    plant = build_reference_plant()

    print("Mix design throughput:")
    for n in (1, 100, 1000, 10000):
        elapsed = benchmark_mix_design(plant, n)
        rate = n / elapsed if elapsed > 0 else float("inf")
        print(f"  n={n:>6d}  {elapsed*1000:9.1f} ms   ({rate:9.0f} mixes/sec)")

    print("\nRecipe candidate generation throughput (optimisation.optimizer):")
    base_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0)
    for n in (1000, 10000, 100000):
        start = time.perf_counter()
        candidates = generate_candidate_mixes(plant.engine, base_inputs, n_candidates=n)
        elapsed = time.perf_counter() - start
        rate = len(candidates) / elapsed if elapsed > 0 else float("inf")
        print(f"  n={n:>7d}  {elapsed:6.2f} s   ({len(candidates)} feasible, {rate:8.0f} candidates/sec)")


if __name__ == "__main__":
    main()
