#!/usr/bin/env python
"""
Example 05: Batching and mixing
==================================

Demonstrates: production.batching (weigh hoppers, scale error, moisture
correction, material shortages -- TARGET -> ACTUAL -> ERROR -> CORRECTED),
and production.mixing (mixing sequence, uniformity index, power draw).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.production.mixing import Mixer
from concrete_digital_twin.reference_plant import build_reference_plant


def main() -> None:
    plant = build_reference_plant()
    inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.2)
    target = plant.engine.design(inputs)

    print("STEP 1: Batch the mix (TARGET -> ACTUAL -> ERROR)")
    record = plant.batch_plant.batch("B-00001", "C35-EXAMPLE", target, volume_m3=3.0)
    print(f"{'Component':<20}{'Target (kg)':>14}{'Actual (kg)':>14}{'Error (%)':>12}")
    for row in record.accuracy_report():
        print(f"{row['component']:<20}{row['target_kg']:>14.1f}{row['actual_kg']:>14.1f}{row['error_pct']:>12.2f}")

    if record.shortages:
        print(f"\n  SHORTAGES: {record.shortages}")
    else:
        print("\n  No material shortages.")

    print("\nSTEP 2: Mix in the plant's twin-shaft mixer")
    mixer = Mixer(plant.mixer)
    mix_result = mixer.mix(batch_volume_m3=3.0, ambient_temp_c=22.0)
    print(f"  Total mixing time: {mix_result.total_mixing_time_s:.0f} s")
    print(f"  Power draw: {mix_result.power_kw:.1f} kW")
    print(f"  Discharge temperature: {mix_result.discharge_temp_c:.1f} degC")
    print(f"  Uniformity index: {mix_result.uniformity_index:.3f} (1.0 = perfectly homogeneous)")


if __name__ == "__main__":
    main()
