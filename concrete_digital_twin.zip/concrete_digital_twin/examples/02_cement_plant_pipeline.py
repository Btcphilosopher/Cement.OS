#!/usr/bin/env python
"""
Example 02: Cement plant pipeline
====================================

Quarry raw materials -> Bogue clinker phase estimate -> rotary kiln
(mass/energy/CO2 balance) -> clinker -> cement mill -> cement blending.
Demonstrates: cement.raw_materials, core.chemistry, cement.kiln,
cement.grinding, cement.blending, and mass-balance checking throughout.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.cement.blending import CementBlend, build_cement
from concrete_digital_twin.cement.grinding import CementMill, MillFeed
from concrete_digital_twin.cement.kiln import KilnInputs, RotaryKiln
from concrete_digital_twin.cement.raw_materials import (
    alumina_modulus,
    default_raw_meal_blend,
    lime_saturation_factor,
    silica_modulus,
)
from concrete_digital_twin.core.chemistry import bogue_phases
from concrete_digital_twin.core.materials import DataProvenance, SCM, SCMType


def main() -> None:
    print("STEP 1: Raw meal blend (quarry) -> oxide composition")
    blend = default_raw_meal_blend()
    ox = blend.blended_oxides_ignited_basis()
    print(f"  LSF={lime_saturation_factor(ox):.1f}  SM={silica_modulus(ox):.2f}  AM={alumina_modulus(ox):.2f}")

    print("\nSTEP 2: Bogue clinker phase estimate")
    phases = bogue_phases(ox)
    for k, v in phases.as_dict().items():
        print(f"  {k}: {v:5.1f}%")

    print("\nSTEP 3: Rotary kiln simulation (100 t/h raw meal feed)")
    kiln = RotaryKiln()
    kiln_out = kiln.simulate(KilnInputs(raw_meal_feed_kg_h=100_000, caco3_fraction_of_raw_meal=0.78, fuel_type="coal"))
    print(f"  Clinker output: {kiln_out.clinker_kg_h/1000:.1f} t/h")
    print(f"  CO2 (calcination): {kiln_out.co2_calcination_kg_h/1000:.1f} t/h")
    print(f"  CO2 (fuel): {kiln_out.co2_fuel_kg_h/1000:.1f} t/h")
    print(f"  Specific energy: {kiln_out.specific_energy_mj_per_t_clinker:.0f} MJ/t clinker")
    print(f"  Mass balance OK: {kiln_out.mass_balance_ok}")

    print("\nSTEP 4: Cement mill (clinker + gypsum + fly ash -> cement)")
    mill = CementMill()
    feed = MillFeed(clinker_kg_h=kiln_out.clinker_kg_h, gypsum_kg_h=kiln_out.clinker_kg_h * 0.05, scm_kg_h=kiln_out.clinker_kg_h * 0.10)
    mill_out = mill.simulate(feed, target_blaine_m2_kg=390)
    print(f"  Cement output: {mill_out.cement_kg_h/1000:.1f} t/h")
    print(f"  Mill power: {mill_out.mill_power_kw:.0f} kW  ({mill_out.specific_energy_kwh_per_t:.1f} kWh/t)")

    print("\nSTEP 5: Blend into a finished cement material record")
    scm = SCM(
        name="Fly Ash", cost_per_tonne=35.0, embodied_carbon_kgco2e_per_tonne=27.0,
        data_provenance=DataProvenance.SIMULATED, density_kg_m3=2200, specific_gravity=2.20,
        scm_type=SCMType.FLY_ASH,
    )
    clinker_co2_per_t = kiln_out.co2_total_kg_h / (kiln_out.clinker_kg_h / 1000)
    total_feed = feed.total_kg_h
    cement_blend = CementBlend(
        clinker_fraction=feed.clinker_kg_h / total_feed,
        gypsum_fraction=feed.gypsum_kg_h / total_feed,
        scm=scm,
        scm_fraction=feed.scm_kg_h / total_feed,
    )
    cement = build_cement(cement_blend, phases, blaine_m2_kg=390, cost_per_tonne=95.0, clinker_co2_kg_per_t=clinker_co2_per_t)
    print(f"  Cement class: {cement.cement_class.value}")
    print(f"  Clinker factor: {cement.clinker_factor:.2f}")
    print(f"  Embodied carbon: {cement.embodied_carbon_kgco2e_per_tonne:.0f} kgCO2e/t")
    print(f"  Density: {cement.density_kg_m3:.0f} kg/m3")


if __name__ == "__main__":
    main()
