#!/usr/bin/env python
"""
Example 08: Economics and carbon
===================================

Demonstrates: economics.material_cost / production_cost / pricing, and
environment.carbon -- including a BASELINE vs LOW-CARBON scenario
comparison (section 40).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.economics.material_cost import material_cost_breakdown, mix_material_cost_per_m3
from concrete_digital_twin.economics.pricing import PricingPolicy, price_per_m3
from concrete_digital_twin.economics.production_cost import ProductionCostInputs, cost_per_day
from concrete_digital_twin.environment.carbon import CarbonScenarioComparison, mix_carbon_kgco2e_per_m3
from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.reference_plant import build_reference_plant


def main() -> None:
    plant = build_reference_plant()

    baseline_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.0)
    low_carbon_inputs = MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0, scm_fraction_of_binder=0.45)

    baseline = plant.engine.design(baseline_inputs)
    low_carbon = plant.engine.design(low_carbon_inputs)

    baseline_cost = mix_material_cost_per_m3(baseline, plant.engine)
    baseline_carbon = mix_carbon_kgco2e_per_m3(baseline, plant.engine)
    low_carbon_cost = mix_material_cost_per_m3(low_carbon, plant.engine)
    low_carbon_carbon = mix_carbon_kgco2e_per_m3(low_carbon, plant.engine)

    print("STEP 1: Cost breakdown (baseline mix)")
    for k, v in material_cost_breakdown(baseline, plant.engine).items():
        print(f"  {k:20s}: £{v:6.2f}/m3")

    print("\nSTEP 2: Baseline vs low-carbon scenario (section 40)")
    comparison = CarbonScenarioComparison(baseline_kgco2e_per_m3=baseline_carbon, optimised_kgco2e_per_m3=low_carbon_carbon)
    print(f"  Baseline:    £{baseline_cost:6.2f}/m3   {baseline_carbon:6.0f} kgCO2e/m3")
    print(f"  Low-carbon:  £{low_carbon_cost:6.2f}/m3   {low_carbon_carbon:6.0f} kgCO2e/m3")
    print(f"  CO2 reduction: {comparison.reduction_kgco2e_per_m3:.0f} kgCO2e/m3 ({comparison.reduction_pct:.1f}%)")
    print(f"  Cost change:   £{low_carbon_cost - baseline_cost:+.2f}/m3")

    print("\nSTEP 3: Production cost roll-up (£/day at 150 m3/h, 12h/day)")
    prod_inputs = ProductionCostInputs(
        material_cost_per_m3=baseline_cost, energy_cost_per_m3=2.5, labour_cost_per_hour=180.0,
        maintenance_cost_per_hour=45.0, transport_cost_per_m3=6.0,
    )
    daily_cost = cost_per_day(prod_inputs, daily_volume_m3=150 * 12 * 0.7, operating_hours=12)
    print(f"  Estimated daily production cost: £{daily_cost:,.0f}")

    print("\nSTEP 4: Customer pricing (15% margin, volume discount)")
    price = price_per_m3(baseline_cost, PricingPolicy(margin_pct=15.0), order_volume_m3=200)
    print(f"  Price to customer (200 m3 order): £{price:.2f}/m3")


if __name__ == "__main__":
    main()
