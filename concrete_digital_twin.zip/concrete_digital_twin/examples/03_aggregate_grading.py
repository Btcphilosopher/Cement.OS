#!/usr/bin/env python
"""
Example 03: Aggregate grading & moisture correction
======================================================

Demonstrates: aggregates.grading (fineness modulus, Fuller curve, packing
density), aggregates.moisture (SSD correction), and blending fine +
coarse PSDs into a combined grading curve.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.aggregates.aggregate import make_coarse_aggregate, make_fine_aggregate
from concrete_digital_twin.aggregates.grading import blend_psds, estimate_packing_density, fineness_modulus, fuller_curve
from concrete_digital_twin.aggregates.moisture import correct_batch_water


def main() -> None:
    fine = make_fine_aggregate()
    coarse = make_coarse_aggregate()

    print("STEP 1: Fineness modulus")
    print(f"  Fine aggregate FM: {fineness_modulus(fine.psd):.2f}")
    print(f"  Coarse aggregate FM: {fineness_modulus(coarse.psd):.2f}")

    print("\nSTEP 2: Combined grading curve (60% fine / 40% coarse, illustrative)")
    combined = blend_psds([fine.psd, coarse.psd], [0.6, 0.4])
    for size, passing in zip(combined.sieve_sizes_mm, combined.percent_passing):
        print(f"  {size:6.2f} mm : {passing:5.1f}% passing")

    print("\nSTEP 3: Fuller 0.45-power target curve (max size 20mm)")
    target = fuller_curve(max_size_mm=20.0, n=0.45, points=8)
    for size, passing in zip(target.sieve_sizes_mm, target.percent_passing):
        print(f"  {size:6.2f} mm : {passing:5.1f}% passing")

    print("\nSTEP 4: Packing density estimate (relative to Fuller curve)")
    est = estimate_packing_density(combined)
    print(f"  Packing density: {est.packing_density:.3f}  (void ratio {est.void_ratio:.3f})")

    print("\nSTEP 5: Moisture correction — visible operator calculation")
    wet_sand = make_fine_aggregate(absorption_pct=1.0, moisture_content_pct=5.0)
    corr = correct_batch_water(wet_sand, ssd_target_mass_kg=800.0)
    print(f"  {corr.explanation()}")


if __name__ == "__main__":
    main()
