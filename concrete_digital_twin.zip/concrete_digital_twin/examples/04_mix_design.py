#!/usr/bin/env python
"""
Example 04: Concrete mix design (absolute volume method)
============================================================

Loads the example mix presets (data/mixes/example_mixes.yaml) and runs
each through MixDesignEngine, printing the full recipe for the reference
Northshire Concrete Works plant.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import yaml

from concrete_digital_twin.mix_design.cement import ExposureClass
from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.reference_plant import build_reference_plant

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "mixes" / "example_mixes.yaml"


def main() -> None:
    plant = build_reference_plant()
    with open(DATA_FILE) as f:
        presets = yaml.safe_load(f)["presets"]

    for preset in presets:
        inputs = MixDesignInputs(
            target_strength_mpa=preset["target_strength_mpa"],
            slump_mm=preset["slump_mm"],
            exposure=ExposureClass(preset["exposure"]),
            max_agg_size_mm=preset["max_agg_size_mm"],
            scm_fraction_of_binder=preset["scm_fraction_of_binder"],
        )
        print(f"\n=== {preset['mix_id']} ===")
        try:
            result = plant.engine.design(inputs)
        except ValueError as e:
            print(f"  INFEASIBLE with this material set: {e}")
            continue
        print(f"  Water: {result.water_kg:6.1f} kg/m3   Cement: {result.cement_kg:6.1f} kg/m3   SCM: {result.scm_kg:5.1f} kg/m3")
        print(f"  Fine agg: {result.fine_aggregate_kg:6.1f} kg/m3   Coarse agg: {result.coarse_aggregate_kg:6.1f} kg/m3")
        print(f"  w/cm: {result.wcm_ratio:.3f}   Predicted 28d strength: {result.predicted_28d_strength_mpa:.1f} MPa (target {preset['target_strength_mpa']:.0f})")
        print(f"  Density: {result.density_kg_m3:.0f} kg/m3   Yield: {result.yield_m3:.2f} m3")
        if result.notes:
            for n in result.notes:
                print(f"  NOTE: {n}")


if __name__ == "__main__":
    main()
