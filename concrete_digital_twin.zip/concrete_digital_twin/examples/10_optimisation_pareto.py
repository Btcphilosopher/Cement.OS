#!/usr/bin/env python
"""
Example 10: Recipe optimiser & Pareto frontier
=================================================

Demonstrates: optimisation.optimizer.search_recipes (section 55 — top-10
ranked recipe search), the cost-vs-carbon Pareto frontier (section 49),
and the "never auto-applies" recommendation engine (section 50).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.optimisation.optimizer import RecipeConstraints, recommend_mix, search_recipes
from concrete_digital_twin.reference_plant import build_reference_plant


def main() -> None:
    plant = build_reference_plant()
    base_inputs = MixDesignInputs(target_strength_mpa=40.0, slump_mm=150.0, max_agg_size_mm=20.0)
    constraints = RecipeConstraints(max_carbon_kgco2e_per_m3=300.0, max_cost_per_m3=90.0)

    print(f"Searching 5,000 candidate recipes for {base_inputs.target_strength_mpa} MPa, "
          f"slump {base_inputs.slump_mm} mm, max carbon {constraints.max_carbon_kgco2e_per_m3} kgCO2e/m3, "
          f"max cost £{constraints.max_cost_per_m3}/m3...\n")

    report = search_recipes(plant.engine, base_inputs, constraints, n_candidates=5000)
    print(f"Generated: {report.n_generated}   Feasible: {report.n_feasible}\n")

    print(f"{'Rank':<6}{'Cost £/m3':>12}{'Carbon kgCO2e/m3':>20}{'Strength MPa':>16}{'SCM %':>10}")
    for i, c in enumerate(report.top_10, 1):
        print(f"{i:<6}{c['cost_per_m3']:>12.2f}{c['carbon_kgco2e_per_m3']:>20.1f}{c['strength_mpa']:>16.1f}{c['scm_fraction']*100:>10.1f}")

    print(f"\nPareto frontier size: {len(report.pareto_frontier)} of {report.n_feasible} feasible mixes")
    print(f"Lowest cost:    £{report.lowest_cost['cost_per_m3']:.2f}/m3")
    print(f"Lowest carbon:  {report.lowest_carbon['carbon_kgco2e_per_m3']:.0f} kgCO2e/m3")
    print(f"Max strength:   {report.max_strength['strength_mpa']:.1f} MPa")
    print(f"Balanced pick:  £{report.balanced['cost_per_m3']:.2f}/m3, {report.balanced['carbon_kgco2e_per_m3']:.0f} kgCO2e/m3")

    print("\n--- Recommendation engine (never auto-applies) ---")
    current = plant.engine.design(base_inputs.model_copy(update={"scm_fraction_of_binder": 0.0}))
    rec = recommend_mix(current, plant.engine, base_inputs, constraints, n_candidates=2000)
    print(f"Current:     cement={rec.current['cement_kg_m3']:.0f} kg/m3, cost=£{rec.current['cost_per_m3']:.2f}, carbon={rec.current['carbon_kgco2e_per_m3']:.0f}")
    print(f"Recommended: cement={rec.recommended['cement_kg_m3']:.0f} kg/m3, SCM={rec.recommended['scm_kg_m3']:.0f} kg/m3, "
          f"cost=£{rec.recommended['cost_per_m3']:.2f}, carbon={rec.recommended['carbon_kgco2e_per_m3']:.0f}")
    print(f"Cost change: £{rec.cost_change_per_m3:+.2f}/m3   Carbon change: {rec.carbon_change_kgco2e_per_m3:+.0f} kgCO2e/m3")
    for r in rec.rationale:
        print(f"  - {r}")
    try:
        rec.apply()
    except RuntimeError as e:
        print(f"\n(Confirming recommendations are NOT auto-applied: {e})")


if __name__ == "__main__":
    main()
