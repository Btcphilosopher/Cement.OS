#!/usr/bin/env python
"""
Example 07: Quality control & SPC
====================================

Demonstrates: quality.sampling (synthetic batch samples), quality.qc
(spec comparison, pass/fail), quality.control_charts (X-bar/R SPC chart).
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.quality.control_charts import xbar_r_chart
from concrete_digital_twin.quality.qc import QualityControlEngine, default_concrete_qc_specs
from concrete_digital_twin.quality.sampling import SampleHistory, generate_batch_samples


def main() -> None:
    target_slump, target_air, target_density, target_strength = 100.0, 5.0, 2400.0, 35.0

    print("STEP 1: Generate 30 days of synthetic QC samples")
    history = SampleHistory()
    for day in range(30):
        samples = generate_batch_samples(
            batch_id=f"B-{day:04d}",
            batch_time=datetime.now() + timedelta(days=day),
            target_slump_mm=target_slump, target_air_pct=target_air,
            target_density_kg_m3=target_density,
            target_strength_7d_mpa=target_strength * 0.65,
            target_strength_28d_mpa=target_strength,
        )
        for s in samples:
            history.add(s)

    print("\nSTEP 2: QC evaluation against spec")
    specs = default_concrete_qc_specs(target_slump, target_air, target_density, target_strength)
    qc = QualityControlEngine(specs)
    for result in qc.evaluate(history):
        status = "PASS" if result.passed else "FAIL"
        cpk_str = f"Cpk={result.cpk:.2f}" if result.cpk is not None else "Cpk=n/a"
        print(f"  {result.test_type:15s} [{status}]  mean={result.mean:7.2f}  std={result.std:5.2f}  {cpk_str}")

    print("\nSTEP 3: Slump X-bar/R control chart (subgroups of 5 consecutive batches)")
    slumps = history.values("slump")
    subgroups = [slumps[i:i+5] for i in range(0, len(slumps) - len(slumps) % 5, 5)]
    xbar, r = xbar_r_chart(subgroups)
    print(f"  X-bar center line: {xbar.center_line:.2f}  UCL: {xbar.upper_control_limit:.2f}  LCL: {xbar.lower_control_limit:.2f}")
    print(f"  Out-of-control subgroups: {xbar.out_of_control_indices or 'none'}")


if __name__ == "__main__":
    main()
