#!/usr/bin/env python
"""
Example 12: Discrete-event plant simulation
==============================================

Demonstrates: simulation.discrete_event -- a shift's worth of batch/mixer/
truck events driven off a simulation-time event queue (independent of
wall-clock time), plus a PLANT_FAILURE scenario injected mid-shift.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.simulation.discrete_event import DiscreteEventSimulation, EventType
from concrete_digital_twin.simulation.scenarios import ScenarioName, get_scenario


def main() -> None:
    sim = DiscreteEventSimulation()
    state = {"batches_completed": 0, "trucks_dispatched": 0, "downtime_min": 0.0}

    def on_batch_start(s: DiscreteEventSimulation, payload: dict) -> None:
        s.schedule(delay=5.0, event_type=EventType.MIXER_START, payload=payload)

    def on_mixer_start(s: DiscreteEventSimulation, payload: dict) -> None:
        s.schedule(delay=3.0, event_type=EventType.MIXER_COMPLETE, payload=payload)

    def on_mixer_complete(s: DiscreteEventSimulation, payload: dict) -> None:
        state["batches_completed"] += 1
        s.schedule(delay=1.0, event_type=EventType.TRUCK_LOADED, payload=payload)

    def on_truck_loaded(s: DiscreteEventSimulation, payload: dict) -> None:
        state["trucks_dispatched"] += 1
        s.schedule(delay=25.0, event_type=EventType.TRUCK_DEPARTURE, payload=payload)
        # Next batch, 12 minutes after this one starts (nominal cycle time)
        s.schedule(delay=11.0, event_type=EventType.BATCH_START, payload={"batch_id": payload["batch_id"] + 1})

    def on_equipment_failure(s: DiscreteEventSimulation, payload: dict) -> None:
        downtime = payload.get("downtime_min", 30.0)
        state["downtime_min"] += downtime
        print(f"  [t={s.sim_time:6.1f} min] EQUIPMENT FAILURE: {payload['asset']} down for {downtime:.0f} min")

    sim.on(EventType.BATCH_START, on_batch_start)
    sim.on(EventType.MIXER_START, on_mixer_start)
    sim.on(EventType.MIXER_COMPLETE, on_mixer_complete)
    sim.on(EventType.TRUCK_LOADED, on_truck_loaded)
    sim.on(EventType.EQUIPMENT_FAILURE, on_equipment_failure)

    sim.schedule(delay=0.0, event_type=EventType.BATCH_START, payload={"batch_id": 1})
    # Inject a mid-shift mixer failure (PLANT_FAILURE scenario, section 47)
    scenario = get_scenario(ScenarioName.PLANT_FAILURE)
    sim.schedule(delay=180.0, event_type=EventType.EQUIPMENT_FAILURE, payload={"asset": "Twin-Shaft Mixer 1", "downtime_min": 45.0, "scenario": scenario.name.value})

    sim.run(until=480.0)  # simulate an 8-hour shift (480 sim-minutes)

    print(f"\nShift summary (0-480 simulation minutes):")
    print(f"  Batches completed: {state['batches_completed']}")
    print(f"  Trucks dispatched: {state['trucks_dispatched']}")
    print(f"  Downtime: {state['downtime_min']:.0f} min")
    print(f"  Total events processed: {len(sim.log)}")


if __name__ == "__main__":
    main()
