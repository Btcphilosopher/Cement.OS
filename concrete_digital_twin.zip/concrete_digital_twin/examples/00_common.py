"""Shared bootstrap for the example scripts: makes the package importable
whether run as `python examples/NN_xxx.py` from inside the repo or from
elsewhere."""

from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
