#!/usr/bin/env python
"""
Example 09: Monte Carlo quality risk
=======================================

Demonstrates: simulation.monte_carlo at 1,000 / 10,000 / 100,000 runs
(section 31), and quality-risk probabilities (section 32). Also
benchmarks wall-clock time at each scale.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from concrete_digital_twin.mix_design.mix import MixDesignInputs
from concrete_digital_twin.reference_plant import build_reference_plant
from concrete_digital_twin.simulation.monte_carlo import run_monte_carlo


def main() -> None:
    plant = build_reference_plant()
    result = plant.engine.design(MixDesignInputs(target_strength_mpa=35.0, slump_mm=100.0))

    print("PROBABILISTIC SIMULATION — not a guarantee of field performance.\n")
    for n in (1000, 10000, 100000):
        start = time.perf_counter()
        mc = run_monte_carlo(result, n_runs=n, seed=42)
        elapsed = time.perf_counter() - start
        print(f"n_runs={n:>7d}  ({elapsed*1000:6.1f} ms)")
        print(f"  Strength: mean={mc.strength_mean:5.1f}  P5={mc.strength_p5:5.1f}  P50={mc.strength_p50:5.1f}  P95={mc.strength_p95:5.1f} MPa")
        print(f"  P(strength < target):    {mc.prob_strength_below_target*100:5.2f}%")
        print(f"  P(slump < min):          {mc.prob_slump_below_min*100:5.2f}%")
        print(f"  P(slump > max):          {mc.prob_slump_above_max*100:5.2f}%")
        print(f"  P(w/cm > limit):         {mc.prob_wcm_above_limit*100:5.2f}%")
        print(f"  P(temperature > limit):  {mc.prob_temperature_above_limit*100:5.2f}%")
        print(f"  P(batch mass off spec):  {mc.prob_batch_mass_out_of_tolerance*100:5.2f}%")
        print()


if __name__ == "__main__":
    main()
