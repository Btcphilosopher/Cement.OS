"""
Concrete Digital Twin
======================

A large-scale, modular, EDUCATIONAL / ENGINEERING-PROTOTYPE simulator for
cement production, aggregate processing, concrete mix design, batching,
mixing, curing, quality control, plant economics, carbon accounting and
production optimisation.

IMPORTANT DISCLAIMER
---------------------
This package is a SIMULATION and TEACHING TOOL. It is not a certified
structural design tool and must never be used, on its own, to certify
concrete for construction. Every numeric model in this codebase is one of:

    SIMULATED               - a simplified physics/chemistry approximation
    ESTIMATED                - an empirical correlation with stated error bars
    USER-PROVIDED             - a value the operator supplies directly
    VALIDATED EXPERIMENTAL DATA - real laboratory data imported by the user

See docs/ASSUMPTIONS.md for the full list of modelling assumptions and
their sources/limitations.

Package version and reproducibility metadata live in
``concrete_digital_twin.__version__`` and
``concrete_digital_twin.core.units.MODEL_VERSION``.
"""

__version__ = "0.1.0"
MATERIAL_DB_VERSION = "2026.08"
