"""plant.silos — cement/SCM/aggregate silo with level tracking and fill/draw."""

from __future__ import annotations

from dataclasses import dataclass, field

from ._equipment_base import Equipment


@dataclass
class Silo(Equipment):
    material_name: str = "cement"
    level_kg: float = 0.0
    min_stock_kg: float = 0.0
    reorder_level_kg: float = 0.0
    max_stock_kg: float | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        self.max_stock_kg = self.max_stock_kg or self.capacity
        if self.level_kg < 0 or self.level_kg > self.capacity:
            raise ValueError("level_kg must be within [0, capacity]")

    @property
    def level_pct(self) -> float:
        return 100.0 * self.level_kg / self.capacity

    @property
    def needs_reorder(self) -> bool:
        return self.level_kg <= self.reorder_level_kg

    def fill(self, mass_kg: float) -> float:
        """Add material; returns the mass actually accepted (may be less
        than requested if the silo is near capacity -- overflow is
        rejected, not silently discarded)."""
        if mass_kg < 0:
            raise ValueError("mass_kg cannot be negative")
        space = self.capacity - self.level_kg
        accepted = min(mass_kg, space)
        self.level_kg += accepted
        return accepted

    def draw(self, mass_kg: float) -> float:
        """Withdraw material; returns the mass actually withdrawn (may be
        less than requested if the silo runs dry -- a material shortage)."""
        if mass_kg < 0:
            raise ValueError("mass_kg cannot be negative")
        withdrawn = min(mass_kg, self.level_kg)
        self.level_kg -= withdrawn
        return withdrawn
