"""plant.mixers — physical mixer equipment (drum/pan/twin-shaft) reliability & power model."""

from __future__ import annotations

from dataclasses import dataclass

from ._equipment_base import Equipment


@dataclass
class MixerEquipment(Equipment):
    """Physical mixer asset. Capacity is in m3 per batch. The *process*
    mixing model (mixing time, uniformity) lives in production.mixing;
    this class tracks the physical machine (power, condition, failures)."""

    rated_power_kw: float = 75.0
    batches_completed: int = 0

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.rated_power_kw <= 0:
            raise ValueError("rated_power_kw must be positive")

    def draw_power_kw(self, load_fraction: float = 1.0) -> float:
        if not (0.0 <= load_fraction <= 1.2):
            raise ValueError("load_fraction must be within [0, 1.2]")
        self.power_kw = self.rated_power_kw * load_fraction * (0.85 + 0.15 * self.condition)
        return self.power_kw

    def complete_batch(self) -> None:
        self.batches_completed += 1
