"""plant.pumps — water/slurry/concrete pump equipment model."""

from __future__ import annotations

from dataclasses import dataclass

from ._equipment_base import Equipment


@dataclass
class Pump(Equipment):
    """Capacity in m3/h (or L/min for water dosing pumps, caller's choice
    of consistent unit)."""

    head_m: float = 20.0
    fluid: str = "water"

    def flow_rate(self, demand: float) -> float:
        """Actual delivered flow given a requested demand, capped by
        capacity and derated by condition/efficiency."""
        if demand < 0:
            raise ValueError("demand cannot be negative")
        if not self.is_operational:
            return 0.0
        max_flow = self.capacity * self.efficiency * (0.5 + 0.5 * self.condition)
        return min(demand, max_flow)
