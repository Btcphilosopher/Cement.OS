"""Physical plant equipment models: silos, mixers, pumps, kilns, storage."""
