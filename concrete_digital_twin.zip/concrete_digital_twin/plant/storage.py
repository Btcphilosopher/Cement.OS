"""plant.storage — generic stockpile / bin storage (aggregates, fuel) with inventory levels."""

from __future__ import annotations

from dataclasses import dataclass

from ._equipment_base import Equipment


@dataclass
class Stockpile(Equipment):
    material_name: str = "aggregate"
    level_kg: float = 0.0
    min_stock_kg: float = 0.0
    target_stock_kg: float = 0.0
    reorder_level_kg: float = 0.0

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.level_kg < 0 or self.level_kg > self.capacity:
            raise ValueError("level_kg must be within [0, capacity]")

    @property
    def level_pct(self) -> float:
        return 100.0 * self.level_kg / self.capacity

    @property
    def needs_reorder(self) -> bool:
        return self.level_kg <= self.reorder_level_kg

    def add(self, mass_kg: float) -> float:
        if mass_kg < 0:
            raise ValueError("mass_kg cannot be negative")
        accepted = min(mass_kg, self.capacity - self.level_kg)
        self.level_kg += accepted
        return accepted

    def remove(self, mass_kg: float) -> float:
        if mass_kg < 0:
            raise ValueError("mass_kg cannot be negative")
        removed = min(mass_kg, self.level_kg)
        self.level_kg -= removed
        return removed
