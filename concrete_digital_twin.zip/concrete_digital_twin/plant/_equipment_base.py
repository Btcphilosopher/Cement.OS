"""
plant._equipment_base
========================

Shared base class for all physical plant equipment (silos, mixers, pumps,
kilns, conveyors, crushers, screens, weigh hoppers, trucks): capacity,
efficiency, power draw, condition, and a simple reliability model
(MTBF/MTTR-based failure probability) used by section 36/37 (equipment
failure & maintenance).
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
import random


@dataclass
class Equipment:
    name: str
    capacity: float
    efficiency: float = 0.95  # 0-1
    power_kw: float = 0.0
    temperature_c: float = 20.0
    condition: float = 1.0  # 1.0 = as-new, 0.0 = failed/worn out
    mtbf_hours: float = 4000.0  # mean time between failures
    mttr_hours: float = 6.0  # mean time to repair
    age_hours: float = 0.0
    _failed: bool = field(default=False, repr=False)

    def __post_init__(self) -> None:
        if self.capacity <= 0:
            raise ValueError("capacity must be positive")
        if not (0.0 <= self.efficiency <= 1.0):
            raise ValueError("efficiency must be within [0,1]")
        if not (0.0 <= self.condition <= 1.0):
            raise ValueError("condition must be within [0,1]")
        if self.mtbf_hours <= 0 or self.mttr_hours <= 0:
            raise ValueError("mtbf_hours and mttr_hours must be positive")

    @property
    def is_operational(self) -> bool:
        return not self._failed and self.condition > 0.05

    def failure_probability_over(self, hours: float) -> float:
        """Exponential reliability model: P(failure within `hours`) given
        the equipment's MTBF, degraded by current condition (worse
        condition -> effectively shorter MTBF)."""
        if hours < 0:
            raise ValueError("hours cannot be negative")
        effective_mtbf = self.mtbf_hours * max(0.1, self.condition)
        rate = 1.0 / effective_mtbf
        return 1.0 - math.exp(-rate * hours)

    def step(self, hours: float, rng: random.Random | None = None) -> bool:
        """Advance the equipment clock by `hours`, ages it, and stochastically
        determines whether a failure occurs in this interval. Returns True if
        a failure occurred (the caller is responsible for modelling downtime
        of `mttr_hours` and resetting condition after repair)."""
        rng = rng or random
        self.age_hours += hours
        # Gradual wear: condition decays slowly with age, faster if already degraded.
        wear_rate = 1e-5 * (1.0 + (1.0 - self.condition))
        self.condition = max(0.0, self.condition - wear_rate * hours)

        if self._failed:
            return False
        p_fail = self.failure_probability_over(hours)
        if rng.random() < p_fail:
            self._failed = True
            return True
        return False

    def repair(self, restored_condition: float = 1.0) -> None:
        self._failed = False
        self.condition = min(1.0, max(self.condition, restored_condition))
