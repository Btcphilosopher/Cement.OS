"""plant.kilns — physical rotary kiln equipment wrapper with MTBF/MTTR reliability.

This wraps cement.kiln.RotaryKiln (the *process* model) with the physical
Equipment base (condition, failure probability, maintenance) so a kiln can
participate in plant-wide reliability/maintenance simulations (section 36/37).
"""

from __future__ import annotations

from dataclasses import dataclass

from ._equipment_base import Equipment
from ..cement.kiln import KilnInputs, KilnOutputs, RotaryKiln


@dataclass
class KilnEquipment(Equipment):
    """`capacity` is the design raw-meal feed rate, kg/h."""

    process_model: RotaryKiln | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.process_model is None:
            self.process_model = RotaryKiln()

    def run(self, inputs: KilnInputs) -> KilnOutputs | None:
        if not self.is_operational:
            return None
        if inputs.raw_meal_feed_kg_h > self.capacity:
            raise ValueError(f"feed {inputs.raw_meal_feed_kg_h:.0f} kg/h exceeds kiln design capacity {self.capacity:.0f} kg/h")
        derated_efficiency = inputs.thermal_efficiency * (0.7 + 0.3 * self.condition)
        derated_inputs = KilnInputs(
            raw_meal_feed_kg_h=inputs.raw_meal_feed_kg_h,
            caco3_fraction_of_raw_meal=inputs.caco3_fraction_of_raw_meal,
            fuel_type=inputs.fuel_type,
            fuel_feed_kg_h=inputs.fuel_feed_kg_h,
            thermal_efficiency=derated_efficiency,
            calcination_degree_target=inputs.calcination_degree_target,
            kiln_speed_rpm=inputs.kiln_speed_rpm,
            excess_air_ratio=inputs.excess_air_ratio,
            ambient_temp_c=inputs.ambient_temp_c,
        )
        return self.process_model.simulate(derated_inputs)
