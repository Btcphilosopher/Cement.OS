"""
economics.production_cost
============================

Rolls material, energy, labour, maintenance and transport cost up into
£/batch, £/truck, £/day, £/year figures (currency configurable).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ProductionCostInputs:
    material_cost_per_m3: float
    energy_cost_per_m3: float
    labour_cost_per_hour: float
    maintenance_cost_per_hour: float
    transport_cost_per_m3: float
    carbon_cost_per_tonne_co2e: float = 0.0
    carbon_kgco2e_per_m3: float = 0.0


def cost_per_m3(inputs: ProductionCostInputs) -> float:
    carbon_cost = inputs.carbon_kgco2e_per_m3 / 1000.0 * inputs.carbon_cost_per_tonne_co2e
    return inputs.material_cost_per_m3 + inputs.energy_cost_per_m3 + inputs.transport_cost_per_m3 + carbon_cost


def cost_per_batch(inputs: ProductionCostInputs, batch_volume_m3: float, batch_duration_hours: float) -> float:
    if batch_volume_m3 <= 0:
        raise ValueError("batch_volume_m3 must be positive")
    per_m3 = cost_per_m3(inputs)
    overhead = (inputs.labour_cost_per_hour + inputs.maintenance_cost_per_hour) * batch_duration_hours
    return per_m3 * batch_volume_m3 + overhead


def cost_per_truck(inputs: ProductionCostInputs, truck_capacity_m3: float, round_trip_hours: float) -> float:
    return cost_per_batch(inputs, truck_capacity_m3, round_trip_hours)


def cost_per_day(inputs: ProductionCostInputs, daily_volume_m3: float, operating_hours: float) -> float:
    per_m3 = cost_per_m3(inputs)
    overhead = (inputs.labour_cost_per_hour + inputs.maintenance_cost_per_hour) * operating_hours
    return per_m3 * daily_volume_m3 + overhead


def cost_per_year(inputs: ProductionCostInputs, daily_volume_m3: float, operating_hours_per_day: float, operating_days_per_year: float = 300) -> float:
    return cost_per_day(inputs, daily_volume_m3, operating_hours_per_day) * operating_days_per_year
