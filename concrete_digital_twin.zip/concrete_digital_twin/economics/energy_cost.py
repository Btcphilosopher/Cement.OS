"""economics.energy_cost — energy cost roll-ups from environment.energy streams."""

from __future__ import annotations

from dataclasses import dataclass

from ..environment.energy import EnergyStreams


@dataclass
class EnergyPrices:
    electricity_per_kwh: float = 0.22
    natural_gas_per_mj: float = 0.010
    coal_per_mj: float = 0.006
    alternative_fuel_per_mj: float = 0.002

    def __post_init__(self) -> None:
        for field_name in ("electricity_per_kwh", "natural_gas_per_mj", "coal_per_mj", "alternative_fuel_per_mj"):
            if getattr(self, field_name) < 0:
                raise ValueError(f"{field_name} cannot be negative")


def energy_cost(streams: EnergyStreams, prices: EnergyPrices = EnergyPrices()) -> float:
    return (
        streams.electricity_kwh * prices.electricity_per_kwh
        + streams.natural_gas_mj * prices.natural_gas_per_mj
        + streams.coal_mj * prices.coal_per_mj
        + streams.alternative_fuel_mj * prices.alternative_fuel_per_mj
    )
