"""
economics.pricing
====================

Customer-facing pricing: applies margin, currency conversion, and simple
volume-discount tiers on top of production cost.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Currency:
    symbol: str = "£"
    code: str = "GBP"
    fx_rate_to_gbp: float = 1.0  # for converting a report into another currency


@dataclass
class PricingPolicy:
    margin_pct: float = 15.0
    volume_discount_tiers: tuple[tuple[float, float], ...] = ((50.0, 2.0), (150.0, 5.0), (400.0, 8.0))

    def __post_init__(self) -> None:
        if self.margin_pct < 0:
            raise ValueError("margin_pct cannot be negative")


def price_per_m3(cost_per_m3: float, policy: PricingPolicy = PricingPolicy(), order_volume_m3: float = 0.0) -> float:
    price = cost_per_m3 * (1.0 + policy.margin_pct / 100.0)
    discount_pct = 0.0
    for threshold, discount in policy.volume_discount_tiers:
        if order_volume_m3 >= threshold:
            discount_pct = discount
    return price * (1.0 - discount_pct / 100.0)


def convert(value_gbp: float, currency: Currency) -> float:
    return value_gbp * currency.fx_rate_to_gbp
