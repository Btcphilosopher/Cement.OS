"""
economics.material_cost
==========================

Material-cost roll-up for a designed concrete mix (currency configurable
at the report/dashboard layer; internally everything is a plain float in
"currency units per tonne", matching Material.cost_per_tonne).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..mix_design.mix import MixDesignEngine, MixDesignResult


def mix_material_cost_per_m3(result: "MixDesignResult", engine: "MixDesignEngine") -> float:
    """Sum of (mass_tonnes * cost_per_tonne) across all mix components."""
    cost = (result.cement_kg / 1000.0) * engine.cement.cost_per_tonne
    if engine.scm is not None and result.scm_kg > 0:
        cost += (result.scm_kg / 1000.0) * engine.scm.cost_per_tonne
    cost += (result.fine_aggregate_kg / 1000.0) * engine.fine_aggregate.cost_per_tonne
    cost += (result.coarse_aggregate_kg / 1000.0) * engine.coarse_aggregate.cost_per_tonne
    for dose in engine.admixture_doses:
        binder_kg = result.cement_kg + result.scm_kg
        cost += dose.cost(binder_kg)
    # water is usually near-negligible but included for completeness
    water_cost_per_m3 = result.water_kg / 1000.0 * 1.5  # SIMULATED nominal water tariff, currency/tonne
    cost += water_cost_per_m3
    return cost


def material_cost_breakdown(result: "MixDesignResult", engine: "MixDesignEngine") -> dict[str, float]:
    breakdown = {
        "cement": (result.cement_kg / 1000.0) * engine.cement.cost_per_tonne,
        "scm": (result.scm_kg / 1000.0) * engine.scm.cost_per_tonne if (engine.scm and result.scm_kg > 0) else 0.0,
        "fine_aggregate": (result.fine_aggregate_kg / 1000.0) * engine.fine_aggregate.cost_per_tonne,
        "coarse_aggregate": (result.coarse_aggregate_kg / 1000.0) * engine.coarse_aggregate.cost_per_tonne,
        "admixture": sum(dose.cost(result.cement_kg + result.scm_kg) for dose in engine.admixture_doses),
        "water": result.water_kg / 1000.0 * 1.5,
    }
    return breakdown
